import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  AppSharedState,
  UserAccount,
  UserRole,
  CounselingBooking,
  EmergencySession,
  PositiveRoomSession,
  TestSubmission,
  SentimentAnalysisResult,
  ExportAuditLog,
} from '../types';
import { initialSharedState } from '../initialData';

interface AppContextType {
  state: AppSharedState;
  currentUser: UserAccount | null;
  setCurrentUser: (user: UserAccount | null) => void;
  isLoading: boolean;
  currentView: 'home' | 'dashboard' | 'positive_room' | 'test_taker' | 'article_detail' | 'urgent_chat' | 'booking_chat';
  setCurrentView: (view: any) => void;
  selectedArticleId: string | null;
  setSelectedArticleId: (id: string | null) => void;
  activeBookingId: string | null;
  setActiveBookingId: (id: string | null) => void;
  activeEmergencyId: string | null;
  setActiveEmergencyId: (id: string | null) => void;
  refreshState: () => Promise<void>;
  updateSharedState: (updates: Partial<AppSharedState>) => Promise<void>;
  addBooking: (booking: CounselingBooking) => Promise<void>;
  sendBookingMessage: (bookingId: string, text: string, sender: 'student' | 'counselor', senderName: string, anonymousCode?: string) => Promise<void>;
  createEmergencySession: (studentNickname: string) => Promise<EmergencySession>;
  sendEmergencyMessage: (sessionId: string, text: string, sender: 'student' | 'counselor', senderName: string, anonymousCode?: string) => Promise<void>;
  submitTest: (submission: TestSubmission) => Promise<void>;
  runAiHealthAnalysis: () => Promise<any>;
  sendVovakierChat: (
    message: string,
    sessionId?: string,
    chatHistory?: any[],
    studentNickname?: string
  ) => Promise<{ text: string; audioDataUrl?: string | null; messages?: any[]; session?: any }>;
  generateVietnameseSpeech: (text: string) => Promise<string | null>;
  sendPositiveRoomMessage: (sessionId: string, message: any) => Promise<void>;
  steerPositiveRoom: (sessionId: string, guidancePrompt?: string, liveNotes?: string, overrideResponse?: string) => Promise<void>;
  analyzeSessionSentiment: (targetId: string, targetType: 'counselor_booking' | 'emergency_session' | 'positive_room', messages?: any[], studentIdentifier?: string, customText?: string) => Promise<SentimentAnalysisResult | null>;
  batchAnalyzeSentiments: () => Promise<number>;
  exportSecureData: (options: { format: 'json' | 'csv'; subset: string; dateFrom?: string; dateTo?: string }) => Promise<{ success: boolean; filename?: string; recordCount?: number; dataString?: string; mimeType?: string; error?: string }>;
  // Admin Management Operations
  provisionUser: (userData: Partial<UserAccount>) => Promise<{ success: boolean; error?: string; user?: UserAccount }>;
  deleteUser: (id: string) => Promise<{ success: boolean; error?: string }>;
  updateUser: (id: string, updates: Partial<UserAccount>) => Promise<{ success: boolean; error?: string }>;
  createArticle: (article: any) => Promise<{ success: boolean; error?: string }>;
  updateArticle: (id: string, article: any) => Promise<{ success: boolean; error?: string }>;
  deleteArticle: (id: string) => Promise<{ success: boolean; error?: string }>;
  createTest: (test: any) => Promise<{ success: boolean; error?: string }>;
  deleteTest: (id: string) => Promise<{ success: boolean; error?: string }>;
  clearDatabaseTable: (tableName: string) => Promise<{ success: boolean; error?: string }>;
  deleteDatabaseRow: (tableName: string, rowId: string) => Promise<{ success: boolean; error?: string }>;
  addDatabaseRow: (tableName: string, rowData: any) => Promise<{ success: boolean; error?: string }>;
  restoreDatabase: (data: any) => Promise<{ success: boolean; error?: string }>;
  publishBroadcastAlert: (message: string, level?: 'info' | 'warning' | 'emergency', authorName?: string) => Promise<{ success: boolean; error?: string }>;
  dismissBroadcastAlert: () => Promise<{ success: boolean; error?: string }>;
  updateRealtimeSettings: (settings: any) => Promise<{ success: boolean; error?: string }>;
  updateAuthSettings: (settings: any) => Promise<{ success: boolean; error?: string }>;
  loginWithCredentials: (username: string, password?: string) => Promise<{ success: boolean; user?: UserAccount; error?: string }>;
  // Dynamic Website Builder & Theme System Operations
  publishWebsiteConfig: (dynamicWebsite: any, changeSummary?: string) => Promise<{ success: boolean; error?: string; newVersion?: any }>;
  rollbackWebsiteVersion: (versionId: string) => Promise<{ success: boolean; error?: string; restoredVersion?: any }>;
  updateWebsiteTheme: (theme: any) => Promise<{ success: boolean; error?: string }>;
  toggleLiveEditor: (active?: boolean) => Promise<{ success: boolean; active?: boolean; error?: string }>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AppSharedState>(initialSharedState);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [currentView, setCurrentView] = useState<any>('home');
  const [selectedArticleId, setSelectedArticleId] = useState<string | null>(null);
  const [activeBookingId, setActiveBookingId] = useState<string | null>(null);
  const [activeEmergencyId, setActiveEmergencyId] = useState<string | null>(null);

  // Fetch state from server with resilient caching and graceful retry
  const refreshState = useCallback(async () => {
    try {
      const res = await fetch('/api/state');
      if (res.ok) {
        const data = await res.json();
        if (data && typeof data === 'object') {
          setState((prev) => ({ ...prev, ...data }));
          try {
            localStorage.setItem('vovaki_state_cache', JSON.stringify(data));
          } catch {
            // Storage access restricted in some iframes
          }
        }
      }
    } catch {
      // Soft fallback on network hiccups or during initial server spin-up
      try {
        const cached = localStorage.getItem('vovaki_state_cache');
        if (cached) {
          const parsed = JSON.parse(cached);
          if (parsed && typeof parsed === 'object') {
            setState((prev) => ({ ...prev, ...parsed }));
          }
        }
      } catch {
        // Fallback to initialSharedState without throwing errors
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Poll state dynamically based on configured polling interval
  useEffect(() => {
    refreshState();
    const intervalMs = state.realtimeSettings?.pollingIntervalMs || 3000;
    const interval = setInterval(refreshState, intervalMs);
    return () => clearInterval(interval);
  }, [refreshState, state.realtimeSettings?.pollingIntervalMs]);

  // Update shared state
  const updateSharedState = async (updates: Partial<AppSharedState>) => {
    try {
      setState((prev) => ({ ...prev, ...updates }));
      await fetch('/api/state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
    } catch (err) {
      console.warn('Notice: Failed to update shared state to server:', err);
    }
  };

  const addBooking = async (booking: CounselingBooking) => {
    try {
      setState((prev) => ({
        ...prev,
        bookings: [booking, ...prev.bookings],
      }));
      await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(booking),
      });
    } catch (err) {
      console.warn('Notice: Failed to add booking:', err);
    }
  };

  const sendBookingMessage = async (
    bookingId: string,
    text: string,
    sender: 'student' | 'counselor',
    senderName: string,
    anonymousCode?: string
  ) => {
    const newMsg = {
      id: `msg-${Date.now()}`,
      sender,
      senderName,
      senderAnonymousCode: anonymousCode,
      text,
      timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
    };

    setState((prev) => {
      const updated = prev.bookings.map((b) => {
        if (b.id === bookingId) {
          return {
            ...b,
            status: b.status === 'pending' ? ('confirmed' as const) : b.status,
            messages: [...(b.messages || []), newMsg],
          };
        }
        return b;
      });
      return { ...prev, bookings: updated };
    });

    try {
      await fetch(`/api/bookings/${bookingId}/message`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newMsg),
      });
    } catch (err) {
      console.warn('Notice: Failed to send booking message:', err);
    }
  };

  const createEmergencySession = async (studentNickname: string): Promise<EmergencySession> => {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const anonymousCode = `HS-KC-${randomNum}`;
    const newSession: EmergencySession = {
      id: `emg-${Date.now()}`,
      studentId: currentUser?.id || `anon-${Date.now()}`,
      studentAnonymousCode: anonymousCode,
      studentNickname: studentNickname || `Học sinh ${anonymousCode}`,
      status: 'active',
      startedAt: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
      messages: [
        {
          id: `emg-init-${Date.now()}`,
          sender: 'system',
          senderName: 'Hệ thống VoVaKi',
          text: `Đã kết nối đường dây Tư vấn Khẩn cấp. Mã ẩn danh của bạn là [${anonymousCode}]. Giáo viên tư vấn tâm lý đang vào phòng...`,
          timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        },
      ],
    };

    setState((prev) => ({
      ...prev,
      emergencySessions: [newSession, ...prev.emergencySessions],
    }));

    try {
      await fetch('/api/emergency', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSession),
      });
    } catch (err) {
      console.warn('Notice: Failed to sync emergency session to server:', err);
    }

    return newSession;
  };

  const sendEmergencyMessage = async (
    sessionId: string,
    text: string,
    sender: 'student' | 'counselor',
    senderName: string,
    anonymousCode?: string
  ) => {
    const newMsg = {
      id: `emg-msg-${Date.now()}`,
      sender,
      senderName,
      senderAnonymousCode: anonymousCode,
      text,
      timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
    };

    setState((prev) => {
      const updated = prev.emergencySessions.map((s) => {
        if (s.id === sessionId) {
          return {
            ...s,
            messages: [...(s.messages || []), newMsg],
          };
        }
        return s;
      });
      return { ...prev, emergencySessions: updated };
    });

    try {
      await fetch(`/api/emergency/${sessionId}/message`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newMsg),
      });
    } catch (err) {
      console.warn('Notice: Failed to send emergency message:', err);
    }
  };

  const submitTest = async (submission: TestSubmission) => {
    try {
      const res = await fetch('/api/tests/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(submission),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.studentRecords) {
          setState((prev) => ({
            ...prev,
            testSubmissions: [submission, ...prev.testSubmissions],
            studentRecords: data.studentRecords,
          }));
        }
      }
    } catch (err) {
      console.warn('Notice: Failed to submit test to server:', err);
    }
  };

  const runAiHealthAnalysis = async () => {
    try {
      const res = await fetch('/api/gemini/analyze-health', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await res.json();
      if (data.analysis) {
        setState((prev) => ({
          ...prev,
          latestAiAnalysis: data.analysis,
        }));
        return data.analysis;
      }
    } catch (err) {
      console.warn('Notice: Failed to run AI health analysis:', err);
    }
    return null;
  };

  const sendVovakierChat = async (
    message: string,
    sessionId?: string,
    chatHistory?: any[],
    studentNickname?: string
  ): Promise<{ text: string; audioDataUrl?: string | null; messages?: any[]; session?: any }> => {
    try {
      const res = await fetch('/api/gemini/vovakier-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          sessionId,
          chatHistory,
          studentNickname,
          studentId: currentUser?.id,
        }),
      });
      const data = await res.json();
      if (data.session) {
        setState((prev) => ({
          ...prev,
          positiveRoomSessions: prev.positiveRoomSessions.map((s) =>
            s.id === data.session.id ? data.session : s
          ),
        }));
      }
      return {
        text: data.text || 'Vovakier luôn lắng nghe bạn.',
        audioDataUrl: data.audioDataUrl || null,
        messages: data.messages,
        session: data.session,
      };
    } catch (err) {
      console.warn('Notice: Failed to chat with Vovakier:', err);
      return {
        text: 'Vovakier luôn ở đây và lắng nghe bạn, hãy cùng mình hít thở thật sâu nhé.',
        audioDataUrl: null,
      };
    }
  };

  const generateVietnameseSpeech = async (text: string): Promise<string | null> => {
    try {
      const res = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      if (res.ok) {
        const data = await res.json();
        return data.audioDataUrl || null;
      }
    } catch (err) {
      console.warn('Notice: Failed to generate Vietnamese TTS:', err);
    }
    return null;
  };

  const sendPositiveRoomMessage = async (sessionId: string, message: any) => {
    try {
      setState((prev) => ({
        ...prev,
        positiveRoomSessions: prev.positiveRoomSessions.map((s) => {
          if (s.id === sessionId) {
            return {
              ...s,
              messages: [...s.messages, message],
            };
          }
          return s;
        }),
      }));
      await fetch(`/api/positive-room/${sessionId}/message`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });
    } catch (err) {
      console.warn('Notice: Failed to send positive room message:', err);
    }
  };

  const steerPositiveRoom = async (
    sessionId: string,
    guidancePrompt?: string,
    liveNotes?: string,
    overrideResponse?: string
  ) => {
    try {
      await fetch(`/api/positive-room/${sessionId}/steer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          counselorGuidancePrompt: guidancePrompt,
          counselorLiveNotes: liveNotes,
          overrideResponse,
        }),
      });
      refreshState();
    } catch (err) {
      console.warn('Notice: Failed to steer positive room:', err);
    }
  };

  const analyzeSessionSentiment = async (
    targetId: string,
    targetType: 'counselor_booking' | 'emergency_session' | 'positive_room',
    messages?: any[],
    studentIdentifier?: string,
    customText?: string
  ): Promise<SentimentAnalysisResult | null> => {
    try {
      const res = await fetch('/api/gemini/analyze-sentiment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetId,
          targetType,
          messages,
          studentIdentifier,
          customText,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.state) {
          setState(data.state);
        } else {
          refreshState();
        }
        return data.sentimentAnalysis;
      }
      return null;
    } catch (err) {
      console.warn('Notice: Failed to analyze session sentiment:', err);
      return null;
    }
  };

  const batchAnalyzeSentiments = async (): Promise<number> => {
    try {
      const res = await fetch('/api/gemini/batch-analyze-sentiments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (res.ok) {
        const data = await res.json();
        if (data.state) {
          setState(data.state);
        } else {
          refreshState();
        }
        return data.processedCount || 0;
      }
      return 0;
    } catch (err) {
      console.warn('Notice: Failed to batch analyze sentiments:', err);
      return 0;
    }
  };

  const exportSecureData = async (options: {
    format: 'json' | 'csv';
    subset: string;
    dateFrom?: string;
    dateTo?: string;
  }): Promise<{
    success: boolean;
    filename?: string;
    recordCount?: number;
    dataString?: string;
    mimeType?: string;
    error?: string;
  }> => {
    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (currentUser?.role) {
        headers['x-user-role'] = currentUser.role;
      }
      if (currentUser?.id) {
        headers['x-user-id'] = currentUser.id;
      }

      const res = await fetch('/api/admin/export', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          format: options.format,
          subset: options.subset,
          dateFrom: options.dateFrom,
          dateTo: options.dateTo,
          userRole: currentUser?.role,
          adminId: currentUser?.id,
          adminName: currentUser?.fullName || 'Quản trị viên Hệ thống',
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Trích xuất thất bại' };
      }

      if (data.state) {
        setState(data.state);
      } else {
        refreshState();
      }

      return {
        success: true,
        filename: data.filename,
        recordCount: data.recordCount,
        dataString: data.dataString,
        mimeType: data.mimeType,
      };
    } catch (err: any) {
      console.warn('Notice: Failed to export secure data:', err);
      return { success: false, error: err.message || 'Lỗi mạng khi trích xuất dữ liệu' };
    }
  };

  // --- Admin Account Operations ---
  const provisionUser = async (userData: Partial<UserAccount>) => {
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Cấp tài khoản thất bại' };
      }
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message || 'Lỗi kết nối máy chủ' };
    }
  };

  const deleteUser = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/users/${id}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Xóa tài khoản thất bại' };
      }
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Lỗi kết nối máy chủ' };
    }
  };

  const updateUser = async (id: string, updates: Partial<UserAccount>) => {
    try {
      const res = await fetch(`/api/admin/users/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Cập nhật tài khoản thất bại' };
      }
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Lỗi kết nối máy chủ' };
    }
  };

  // --- Admin Content CRUD ---
  const createArticle = async (article: any) => {
    try {
      const res = await fetch('/api/admin/articles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(article),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const updateArticle = async (id: string, article: any) => {
    try {
      const res = await fetch(`/api/admin/articles/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(article),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const deleteArticle = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/articles/${id}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const createTest = async (test: any) => {
    try {
      const res = await fetch('/api/admin/tests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(test),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const deleteTest = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/tests/${id}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  // --- Database Table Operations ---
  const clearDatabaseTable = async (tableName: string) => {
    try {
      const res = await fetch('/api/admin/database/clear-table', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableName }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const deleteDatabaseRow = async (tableName: string, rowId: string) => {
    try {
      const res = await fetch('/api/admin/database/delete-row', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableName, rowId }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const addDatabaseRow = async (tableName: string, rowData: any) => {
    try {
      const res = await fetch('/api/admin/database/add-row', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableName, rowData }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const restoreDatabase = async (data: any) => {
    try {
      const res = await fetch('/api/admin/database/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      if (resData.state) setState(resData.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  // --- Real-time Broadcast & Settings ---
  const publishBroadcastAlert = async (message: string, level: 'info' | 'warning' | 'emergency' = 'info', authorName?: string) => {
    try {
      const res = await fetch('/api/admin/realtime/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          level,
          active: true,
          authorName: authorName || currentUser?.fullName || 'Quản trị viên',
        }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const dismissBroadcastAlert = async () => {
    try {
      const res = await fetch('/api/admin/realtime/broadcast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: false }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const updateRealtimeSettings = async (settings: any) => {
    try {
      const res = await fetch('/api/admin/realtime/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const updateAuthSettings = async (settings: any) => {
    try {
      const res = await fetch('/api/admin/auth/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const loginWithCredentials = async (username: string, password?: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Đăng nhập thất bại' };
      }
      setCurrentUser(data.user);
      return { success: true, user: data.user };
    } catch (err: any) {
      return { success: false, error: err.message || 'Lỗi mạng khi đăng nhập' };
    }
  };

  // Dynamic Website Builder operations
  const publishWebsiteConfig = async (dynamicWebsite: any, changeSummary?: string) => {
    try {
      const res = await fetch('/api/admin/website-builder/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dynamicWebsite,
          changeSummary,
          authorName: currentUser?.fullName || 'Quản trị viên Hệ thống',
          authorRole: currentUser?.role === 'admin' ? 'Super Admin' : 'Admin',
        }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true, newVersion: data.newVersion };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const rollbackWebsiteVersion = async (versionId: string) => {
    try {
      const res = await fetch('/api/admin/website-builder/rollback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ versionId }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true, restoredVersion: data.restoredVersion };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const updateWebsiteTheme = async (theme: any) => {
    try {
      const res = await fetch('/api/admin/website-builder/theme', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(theme),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else refreshState();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const toggleLiveEditor = async (active?: boolean) => {
    try {
      const targetState = active !== undefined ? active : !state.dynamicWebsite?.liveEditorActive;
      const res = await fetch('/api/admin/website-builder/live-editor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: targetState }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      if (data.state) setState(data.state);
      else {
        setState((prev) => ({
          ...prev,
          dynamicWebsite: prev.dynamicWebsite ? { ...prev.dynamicWebsite, liveEditorActive: targetState } : undefined,
        }));
      }
      return { success: true, active: targetState };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  return (
    <AppContext.Provider
      value={{
        state,
        currentUser,
        setCurrentUser,
        isLoading,
        currentView,
        setCurrentView,
        selectedArticleId,
        setSelectedArticleId,
        activeBookingId,
        setActiveBookingId,
        activeEmergencyId,
        setActiveEmergencyId,
        refreshState,
        updateSharedState,
        addBooking,
        sendBookingMessage,
        createEmergencySession,
        sendEmergencyMessage,
        submitTest,
        runAiHealthAnalysis,
        sendVovakierChat,
        generateVietnameseSpeech,
        sendPositiveRoomMessage,
        steerPositiveRoom,
        analyzeSessionSentiment,
        batchAnalyzeSentiments,
        exportSecureData,
        provisionUser,
        deleteUser,
        updateUser,
        createArticle,
        updateArticle,
        deleteArticle,
        createTest,
        deleteTest,
        clearDatabaseTable,
        deleteDatabaseRow,
        addDatabaseRow,
        restoreDatabase,
        publishBroadcastAlert,
        dismissBroadcastAlert,
        updateRealtimeSettings,
        updateAuthSettings,
        loginWithCredentials,
        publishWebsiteConfig,
        rollbackWebsiteVersion,
        updateWebsiteTheme,
        toggleLiveEditor,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
