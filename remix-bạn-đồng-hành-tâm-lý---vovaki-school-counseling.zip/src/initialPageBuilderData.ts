import { DynamicWebsiteConfig, ThemeDesignSystem, HeaderConfig, FooterConfig, NavMenuItem, DynamicPage } from './types/pageBuilder';

export const initialTheme: ThemeDesignSystem = {
  primaryColor: '#059669', // Emerald
  secondaryColor: '#0284c7', // Sky blue
  accentColor: '#f59e0b', // Amber
  backgroundColor: '#ffffff',
  surfaceColor: '#ffffff',
  textColor: '#1c1917',
  mutedTextColor: '#78716c',
  fontFamily: 'Be Vietnam Pro',
  headingFontFamily: 'Be Vietnam Pro',
  fontSizeBase: '15px',
  buttonStyle: 'rounded-xl',
  cardRadius: 'rounded-2xl',
  cardShadow: 'shadow-xs',
  containerMaxWidth: 'max-w-7xl',
};

export const initialHeader: HeaderConfig = {
  logoText: 'VoVaKi School Counseling',
  logoSubtext: 'Phòng Tư Vấn Tâm Lý Học Đường',
  logoIconUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=120&q=80',
  logoPosition: 'left',
  navAlignment: 'center',
  heightPx: 72,
  backgroundColor: '#ffffff',
  textColor: '#1c1917',
  isSticky: true,
  showEmergencyHotline: true,
  showAuthButton: true,
  actionButtons: [
    {
      id: 'btn-pos',
      label: 'Phòng Tích Cực AI',
      type: 'positive_room',
      variant: 'accent',
    },
    {
      id: 'btn-login',
      label: 'Đăng nhập',
      type: 'login',
      variant: 'primary',
    },
  ],
};

export const initialMenu: NavMenuItem[] = [
  {
    id: 'm-home',
    label: 'Trang chủ',
    path: '/',
    targetType: 'page',
    order: 1,
  },
  {
    id: 'm-articles',
    label: 'Cẩm nang & Bài viết',
    path: '/articles',
    targetType: 'action',
    targetAction: 'dashboard',
    order: 2,
    children: [
      {
        id: 'm-art-stress',
        label: 'Giảm áp lực thi cử',
        path: '/articles/stress',
        targetType: 'action',
        targetAction: 'dashboard',
        order: 1,
      },
      {
        id: 'm-art-friend',
        label: 'Quan hệ bạn bè & bắt nạt',
        path: '/articles/friendship',
        targetType: 'action',
        targetAction: 'dashboard',
        order: 2,
      },
      {
        id: 'm-art-family',
        label: 'Thấu hiểu cha mẹ',
        path: '/articles/family',
        targetType: 'action',
        targetAction: 'dashboard',
        order: 3,
      },
    ],
  },
  {
    id: 'm-tests',
    label: 'Trắc nghiệm Tâm lý',
    path: '/tests',
    targetType: 'action',
    targetAction: 'tests',
    order: 3,
  },
  {
    id: 'm-counseling',
    label: 'Đặt lịch Tham vấn',
    path: '/counseling',
    targetType: 'action',
    targetAction: 'dashboard',
    order: 4,
  },
  {
    id: 'm-positive',
    label: 'Phòng Tích Cực (AI)',
    path: '/positive-room',
    targetType: 'action',
    targetAction: 'positive_room',
    order: 5,
  },
  {
    id: 'm-sos',
    label: 'SOS Khẩn cấp',
    path: '/sos',
    targetType: 'action',
    targetAction: 'emergency',
    order: 6,
  },
];

export const initialFooter: FooterConfig = {
  layout: '4-col',
  backgroundColor: '#1c1917', // Dark stone
  textColor: '#d6d3d1',
  logoUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=120&q=80',
  copyrightText: '© 2026 VoVaKi School Counseling. Bản quyền thuộc Phòng Tư vấn Tâm lý Học đường.',
  showBackToTop: true,
  columns: [
    {
      id: 'fcol-1',
      title: 'Về VoVaKi School Counseling',
      content: 'Không gian lắng nghe, thấu cảm và hỗ trợ tâm lý học đường toàn diện. Nơi mọi khó khăn tuổi học trò đều được đón nhận bằng sự ấm áp, bảo mật và đồng hành khoa học.',
      links: [],
    },
    {
      id: 'fcol-2',
      title: 'Kênh Liên lạc Hỗ trợ',
      content: '',
      links: [
        { id: 'fl-1', label: 'Hotline 24/7: 1900 6868', url: 'tel:19006868' },
        { id: 'fl-2', label: 'Phòng trực ban: 024 3825 8899', url: 'tel:02438258899' },
        { id: 'fl-3', label: 'Email: tuvan.tamly@vovaki.edu.vn', url: 'mailto:tuvan.tamly@vovaki.edu.vn' },
        { id: 'fl-4', label: 'Địa chỉ: Tầng 2, Tòa Tri Thức, THPT VoVaKi', url: '#' },
      ],
    },
    {
      id: 'fcol-3',
      title: 'Chức năng Trọng tâm',
      content: '',
      links: [
        { id: 'fl-5', label: 'Trắc nghiệm Tâm lý DASS-21', url: '#' },
        { id: 'fl-6', label: 'Trò chuyện cùng AI Vovakier', url: '#' },
        { id: 'fl-7', label: 'Đặt lịch tham vấn chuyên gia', url: '#' },
        { id: 'fl-8', label: 'Hòm thư ẩn danh chia sẻ', url: '#' },
      ],
    },
    {
      id: 'fcol-4',
      title: 'Cam kết Bảo mật',
      content: 'Mọi thông tin cá nhân và nội dung trao đổi của học sinh đều được mã hóa và bảo mật nghiêm ngặt theo chuẩn mực đạo đức tham vấn học đường quốc tế.',
      links: [
        { id: 'fl-9', label: 'Chính sách bảo mật dữ liệu', url: '#' },
        { id: 'fl-10', label: 'Quy trình hỗ trợ khẩn cấp', url: '#' },
      ],
    },
  ],
  socialLinks: [
    { id: 'soc-fb', platform: 'facebook', label: 'Facebook VoVaKi', url: 'https://facebook.com/vovakischoolcounseling' },
    { id: 'soc-zl', platform: 'zalo', label: 'Zalo Tư vấn', url: 'https://zalo.me' },
    { id: 'soc-em', platform: 'email', label: 'Email Liên hệ', url: 'mailto:tuvan.tamly@vovaki.edu.vn' },
  ],
};

export const initialPages: DynamicPage[] = [
  {
    id: 'page-home',
    slug: 'home',
    title: 'Trang chủ - Phòng Tư Vấn Tâm Lý',
    description: 'Trang chủ chính thức của hệ thống tư vấn tâm lý học đường VoVaKi',
    isPublished: true,
    createdAt: '2026-09-01',
    updatedAt: '2026-09-13',
    sections: [
      // Section 1: Hero Banner
      {
        id: 'sec-hero',
        name: 'Khối Banner & Giới thiệu',
        layout: '1-col',
        fullWidth: true,
        spacing: 'generous',
        paddingTop: 10,
        paddingBottom: 10,
        backgroundColor: '#1c1917',
        backgroundImageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1600&q=80',
        backgroundOverlay: 'dark',
        textColor: '#ffffff',
        isVisible: true,
        blocks: [
          {
            id: 'blk-hero-1',
            type: 'banner',
            title: 'Hero Banner',
            content: {
              badge: '🌿 VoVaKi School Counseling',
              text: 'Nơi Lắng Nghe, Thấu Cảm & Đồng Hành Cùng Tuổi Học Trò',
              subText: 'Không gian an toàn, tôn trọng và bảo mật tuyệt đối dành cho mọi học sinh, thầy cô và phụ huynh. Nơi bạn tự do giải tỏa căng thẳng và tìm lại sự bình yên trong học tập.',
              buttonText: 'Trò chuyện cùng AI Vovakier',
              buttonLink: 'positive_room',
              buttonVariant: 'primary',
              alignment: 'center',
            },
            style: {
              fontSize: '3xl',
              fontWeight: 'extrabold',
              textColor: '#ffffff',
              paddingY: 4,
              paddingX: 4,
              borderRadius: '2xl',
            },
            isVisible: true,
          },
        ],
      },

      // Section 2: Core Highlights / Features (3 columns)
      {
        id: 'sec-features',
        name: 'Khối Dịch vụ Nổi bật',
        layout: '3-col-equal',
        fullWidth: false,
        spacing: 'normal',
        paddingTop: 8,
        paddingBottom: 8,
        backgroundColor: '#f8fafc',
        isVisible: true,
        blocks: [
          {
            id: 'blk-feat-1',
            type: 'card',
            title: 'Phòng Tích Cực AI',
            content: {
              badge: 'Công nghệ AI 2026',
              text: 'Trợ lý Vovakier thấu cảm',
              subText: 'Lắng nghe giọng nói trực tiếp, phản hồi ấm áp, chống dội âm và hỗ trợ ngắt lời bằng khẩu lệnh "bỏ qua".',
              buttonText: 'Mở Phòng Tích Cực',
              buttonLink: 'positive_room',
              buttonVariant: 'primary',
              alignment: 'left',
              imageUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=400&q=80',
            },
            style: {
              borderRadius: '2xl',
              shadow: 'xs',
              border: true,
              borderColor: '#e2e8f0',
              backgroundColor: '#ffffff',
            },
            columnIndex: 0,
            isVisible: true,
          },
          {
            id: 'blk-feat-2',
            type: 'card',
            title: 'Trắc nghiệm Tâm lý',
            content: {
              badge: 'Khoa học & Chính xác',
              text: 'Bộ trắc nghiệm DASS-21 & Stress',
              subText: 'Tự đánh giá mức độ căng thẳng, lo âu và trầm cảm học đường với khuyến nghị bảo mật từ chuyên gia.',
              buttonText: 'Làm bài kiểm tra',
              buttonLink: 'tests',
              buttonVariant: 'secondary',
              alignment: 'left',
              imageUrl: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=400&q=80',
            },
            style: {
              borderRadius: '2xl',
              shadow: 'xs',
              border: true,
              borderColor: '#e2e8f0',
              backgroundColor: '#ffffff',
            },
            columnIndex: 1,
            isVisible: true,
          },
          {
            id: 'blk-feat-3',
            type: 'card',
            title: 'Đặt lịch Tham vấn Chuyên gia',
            content: {
              badge: 'Bảo mật 100%',
              text: 'Gặp gỡ ThS. Tâm lý học đường',
              subText: 'Đặt lịch trò chuyện 1-1 trực tuyến hoặc trực tiếp tại phòng tư vấn với mã ẩn danh hoàn toàn.',
              buttonText: 'Đăng ký tham vấn',
              buttonLink: 'counseling',
              buttonVariant: 'amber',
              alignment: 'left',
              imageUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
            },
            style: {
              borderRadius: '2xl',
              shadow: 'xs',
              border: true,
              borderColor: '#e2e8f0',
              backgroundColor: '#ffffff',
            },
            columnIndex: 2,
            isVisible: true,
          },
        ],
      },

      // Section 3: Dynamic Articles Module
      {
        id: 'sec-articles',
        name: 'Chuyên mục Cẩm nang & Bài viết Tâm lý',
        layout: '1-col',
        fullWidth: false,
        spacing: 'normal',
        paddingTop: 8,
        paddingBottom: 8,
        backgroundColor: '#ffffff',
        isVisible: true,
        blocks: [
          {
            id: 'blk-art-mod',
            type: 'articles_module',
            title: 'Bài viết Chuyên môn từ Tổ Tư Vấn',
            content: {
              text: 'Cẩm nang Tâm lý & Kỹ năng Sống Học đường',
              subText: 'Những bài viết chia sẻ phương pháp giải tỏa lo âu, thấu hiểu bản thân và cân bằng cuộc sống học đường',
            },
            style: {
              paddingY: 2,
              paddingX: 2,
            },
            isVisible: true,
          },
        ],
      },

      // Section 4: Emergency SOS Contact Widget (2-col-equal)
      {
        id: 'sec-sos',
        name: 'Khối Hỗ trợ Khẩn cấp & Hotline',
        layout: '2-col-equal',
        fullWidth: false,
        spacing: 'compact',
        paddingTop: 8,
        paddingBottom: 8,
        backgroundColor: '#fef2f2', // Light red
        isVisible: true,
        blocks: [
          {
            id: 'blk-sos-1',
            type: 'emergency_module',
            title: 'Kênh SOS Trực tiếp',
            content: {
              badge: 'Hỗ trợ 24/7',
              text: 'Bạn đang cảm thấy quá tải hoặc bế tắc?',
              subText: 'Hãy nhấn vào đây ngay lập tức. Đội ngũ giáo viên tư vấn và hotline hỗ trợ luôn túc trực để đồng hành cùng bạn trong mọi tình huống.',
              buttonText: 'Kích hoạt Phiên SOS Khẩn cấp',
              buttonLink: 'emergency',
              buttonVariant: 'danger',
            },
            style: {
              backgroundColor: '#ffffff',
              borderRadius: '2xl',
              shadow: 'md',
              border: true,
              borderColor: '#fecaca',
            },
            columnIndex: 0,
            isVisible: true,
          },
          {
            id: 'blk-sos-2',
            type: 'hotline_module',
            title: 'Đường dây nóng Trực tiếp',
            content: {
              badge: 'Miễn phí cước gọi',
              text: 'Hotline Tâm lý Học đường: 1900 6868',
              subText: 'Tư vấn viên trực tiếp 24 giờ mỗi ngày. Thông tin hoàn toàn được giữ bí mật, không lưu lịch sử công khai.',
              buttonText: 'Gọi ngay 1900 6868',
              buttonLink: 'tel:19006868',
              buttonVariant: 'primary',
            },
            style: {
              backgroundColor: '#ffffff',
              borderRadius: '2xl',
              shadow: 'md',
              border: true,
              borderColor: '#fed7aa',
            },
            columnIndex: 1,
            isVisible: true,
          },
        ],
      },
    ],
  },
  {
    id: 'page-about',
    slug: 'about',
    title: 'Giới thiệu Phòng Tư Vấn VoVaKi',
    description: 'Tìm hiểu về sứ mệnh, đội ngũ chuyên gia và tôn chỉ hoạt động của phòng tư vấn',
    isPublished: true,
    createdAt: '2026-09-02',
    updatedAt: '2026-09-13',
    sections: [
      {
        id: 'sec-abt-1',
        name: 'Giới thiệu chung',
        layout: '1-col',
        fullWidth: false,
        paddingTop: 8,
        paddingBottom: 8,
        backgroundColor: '#ffffff',
        isVisible: true,
        blocks: [
          {
            id: 'blk-abt-h',
            type: 'heading',
            title: 'Sứ mệnh & Giá trị cốt lõi',
            content: {
              text: 'Đồng hành cùng sức khỏe tinh thần thế hệ tương lai',
              subText: 'Phòng Tư vấn Tâm lý VoVaKi được thành lập nhằm tạo nên một điểm tựa tinh thần vững chắc cho học sinh THPT.',
              alignment: 'center',
            },
            style: {
              fontSize: '3xl',
              fontWeight: 'bold',
              paddingY: 2,
            },
            isVisible: true,
          },
          {
            id: 'blk-abt-p',
            type: 'paragraph',
            title: 'Nội dung chi tiết',
            content: {
              text: 'Chúng tôi tin rằng sức khỏe tinh thần quan trọng không kém gì thành tích học tập. Mỗi học sinh là một cá thể độc đáo với những ước mơ, trăn trở và khó khăn riêng. Tại VoVaKi, chúng tôi không đưa ra những bài học giáo điều mà cùng các em khám phá giải pháp thực tế, bồi dưỡng sự kiên cường và lòng yêu thương bản thân.',
              alignment: 'left',
            },
            style: {
              fontSize: 'base',
              paddingY: 2,
            },
            isVisible: true,
          },
        ],
      },
    ],
  },
];

export const initialDynamicWebsiteConfig: DynamicWebsiteConfig = {
  theme: initialTheme,
  header: initialHeader,
  footer: initialFooter,
  menu: initialMenu,
  pages: initialPages,
  activePageId: 'page-home',
  liveEditorActive: false,
  versions: [
    {
      id: 'ver-init-1',
      versionNumber: 1,
      createdAt: '2026-09-01 08:00',
      createdByName: 'Quản trị viên Hệ thống VoVaKi',
      createdByRole: 'Super Admin',
      changeSummary: 'Khởi tạo cấu trúc giao diện động ban đầu với Page Builder & Theme System',
      snapshot: {
        theme: initialTheme,
        header: initialHeader,
        footer: initialFooter,
        menu: initialMenu,
        pages: initialPages,
      },
    },
  ],
};
