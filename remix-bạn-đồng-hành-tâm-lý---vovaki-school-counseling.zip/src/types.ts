export type UserRole = 'admin' | 'counselor' | 'homeroom' | 'student';

export interface UserAccount {
  id: string;
  username: string;
  password?: string;
  fullName: string;
  role: UserRole;
  email?: string;
  phone?: string;
  classId?: string; // For students and homeroom teachers (e.g., '10A1', '11B2', '12C1')
  studentCode?: string;
  avatar?: string;
  isActive?: boolean;
  lastLogin?: string;
  createdAt: string;
}

export interface SiteSettings {
  siteName: string;
  bannerUrl: string;
  backdropUrl: string;
  primaryColor: string; // e.g. '#0d9488', '#2563eb', '#7c3aed', '#e11d48', '#d97706'
  fontFamily: string; // 'Be Vietnam Pro', 'Nunito', 'Merriweather'
  theme: 'light' | 'dark' | 'soft-warm';
  navButtonPosition: 'bottom-center' | 'bottom-right' | 'bottom-left';
  footerInfo: {
    phone: string;
    hotline: string;
    email: string;
    facebook: string;
    zalo: string;
    address: string;
  };
  positiveRoomAvatar: string;
  positiveRoomTheme: 'aurora' | 'sunset' | 'zen' | 'ocean';
  positiveRoomVoiceTone: 'warm' | 'gentle' | 'encouraging';
}

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  author: string;
  date: string;
  imageUrl: string;
  readTime: string;
}

export interface ChatMessage {
  id: string;
  sender: 'student' | 'counselor' | 'vovakier_ai' | 'system';
  senderName: string;
  senderAnonymousCode?: string;
  text: string;
  timestamp: string;
  isCounselorIntervention?: boolean;
}

export type SentimentCategory = 'positive' | 'negative' | 'neutral';

export type EmotionalState =
  | 'Tích cực & Lạc quan'
  | 'Bình yên & Cân bằng'
  | 'Căng thẳng & Áp lực'
  | 'Lo âu & Hoảng loạn'
  | 'Buồn bã & Bế tắc'
  | 'Cô đơn & Tách biệt'
  | 'Tức giận & Bất an'
  | 'Trung tính & Thăm dò'
  | 'Hy vọng & Tiếp thu';

export interface SentimentAnalysisResult {
  id: string;
  targetId: string;
  targetType: 'counselor_booking' | 'emergency_session' | 'positive_room' | 'custom_text';
  studentIdentifier: string; // Anonymous code or student nickname/code
  studentId?: string;
  sentiment: SentimentCategory;
  sentimentLabel: 'Tích cực' | 'Tiêu cực' | 'Trung tính';
  score: number; // Scale from -1.0 to 1.0
  normalizedScore: number; // 0 to 100 for easy UI gauges
  confidence: number; // 0 to 1.0 (e.g. 0.94)
  emotionalState: EmotionalState | string;
  emotionsBreakdown: {
    positive: number; // percentage 0 - 100
    negative: number;
    neutral: number;
  };
  urgencyLevel: 'Bình thường' | 'Cần chú ý' | 'Báo động khẩn cấp';
  keyPhrases: string[];
  distressSignals: string[];
  summary: string;
  clinicalRecommendations: string[];
  analyzedAt: string;
}

export interface CounselingBooking {
  id: string;
  studentId: string;
  studentAnonymousCode: string; // E.g. HS-8392
  nickname: string;
  date: string;
  timeSlot: string;
  type: 'counselor' | 'positive_room';
  topic: string;
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  counselorId?: string;
  messages: ChatMessage[];
  sentimentAnalysis?: SentimentAnalysisResult;
  createdAt: string;
}

export interface EmergencySession {
  id: string;
  studentId: string;
  studentAnonymousCode: string;
  studentNickname: string;
  status: 'active' | 'closed';
  startedAt: string;
  messages: ChatMessage[];
  counselorNotes?: string;
  sentimentAnalysis?: SentimentAnalysisResult;
}

export interface PositiveRoomSession {
  id: string;
  studentId: string;
  studentAnonymousCode: string;
  studentNickname: string;
  status: 'active' | 'paused' | 'ended';
  startedAt: string;
  messages: ChatMessage[];
  counselorGuidancePrompt?: string; // Counselor remote intervention
  counselorLiveNotes?: string;
  audioActive: boolean;
  sentimentAnalysis?: SentimentAnalysisResult;
}

export interface QuestionOption {
  text: string;
  score: number;
}

export interface TestQuestion {
  id: string;
  content: string;
  options: QuestionOption[];
}

export interface ScoreTier {
  label: 'Bình thường' | 'Cần lưu ý' | 'Cần đặc biệt lưu ý';
  minScore: number;
  maxScore: number;
  color: string;
  description: string;
  actionRecommendation: string;
}

export interface PsychologicalTest {
  id: string;
  month: string; // e.g. '2026-09'
  title: string;
  description: string;
  targetGrades: number[]; // e.g. [10, 11, 12]
  questions: TestQuestion[];
  scoreTiers: ScoreTier[];
  createdBy: string;
  createdAt: string;
  isActive: boolean;
}

export interface TestSubmission {
  id: string;
  testId: string;
  testTitle?: string;
  studentId: string;
  studentName: string;
  studentCode: string;
  classId: string;
  grade: number; // 10, 11, 12
  month: string;
  answers: Record<string, number>;
  totalScore: number;
  evaluation: 'Bình thường' | 'Cần lưu ý' | 'Cần đặc biệt lưu ý';
  advice?: string;
  submittedAt: string;
}

export interface StudentHealthRecord {
  id: string;
  studentId: string;
  studentName: string;
  studentCode: string;
  classId: string;
  grade: number; // 10, 11, 12
  latestScore: number;
  status: 'Bình thường' | 'Cần lưu ý' | 'Cần đặc biệt lưu ý';
  lastUpdatedMonth: string;
  scoreHistory: {
    month: string;
    score: number;
    evaluation: 'Bình thường' | 'Cần lưu ý' | 'Cần đặc biệt lưu ý';
  }[];
  counselorNotes: string;
  homeroomNotes: string;
  specialAttentionFlag: boolean;
}

export interface ClassHealthAccess {
  classId: string;
  grade: number;
  homeroomTeacherId: string;
  isUnlockedForHomeroom: boolean;
  unlockedAt?: string;
}

export interface AiHealthAnalysis {
  generatedAt: string;
  summary: string;
  potentialPhenomena: {
    title: string;
    riskLevel: 'Thấp' | 'Trung bình' | 'Cao';
    description: string;
    warningSigns: string[];
    prevention: string;
  }[];
  commonIssues: {
    issue: string;
    percentage: number;
    evidenceFromChats: string;
    affectedGroup: string;
  }[];
  depressionRiskStudents: {
    studentCode: string;
    classId: string;
    riskLevel: 'Cần đặc biệt lưu ý' | 'Cần lưu ý';
    indicators: string[];
    recommendedAction: string;
  }[];
  actionPlan: string[];
}

export interface ExportAuditLog {
  id: string;
  adminId: string;
  adminName: string;
  exportFormat: 'csv' | 'json';
  dataSubset: string;
  subsetName: string;
  recordCount: number;
  dateRange: {
    from?: string;
    to?: string;
  };
  timestamp: string;
  ipAddress?: string;
  status: 'success' | 'failed';
}

export interface RealtimeBroadcastAlert {
  id: string;
  message: string;
  level: 'info' | 'warning' | 'emergency';
  active: boolean;
  createdAt: string;
  authorName: string;
}

export interface RealtimeSettings {
  pollingIntervalMs: number; // e.g. 2000, 3000, 5000, 10000
  broadcastAlert?: RealtimeBroadcastAlert | null;
  serverStatus: 'connected' | 'syncing' | 'paused';
  lastPingMs: number;
  activeConnectionsCount: number;
}

export interface AuthSecuritySettings {
  minPasswordLength: number;
  requireSpecialChars: boolean;
  sessionTimeoutMinutes: number;
  allowStudentRegistration: boolean;
  forceAnonymousStudentMode: boolean;
  maxLoginAttempts: number;
}

export interface AuthLog {
  id: string;
  username: string;
  action: 'login' | 'logout' | 'create_user' | 'delete_user' | 'reset_password' | 'toggle_lock' | 'change_role';
  timestamp: string;
  ip: string;
  status: 'success' | 'failed';
  details?: string;
}

import { DynamicWebsiteConfig } from './types/pageBuilder';
export * from './types/pageBuilder';

export interface AppSharedState {
  users: UserAccount[];
  classes: string[];
  classAccess: ClassHealthAccess[];
  siteSettings: SiteSettings;
  articles: Article[];
  bookings: CounselingBooking[];
  emergencySessions: EmergencySession[];
  positiveRoomSessions: PositiveRoomSession[];
  psychologicalTests: PsychologicalTest[];
  testSubmissions: TestSubmission[];
  studentRecords: StudentHealthRecord[];
  sentimentAnalyses: SentimentAnalysisResult[];
  exportAuditLogs: ExportAuditLog[];
  realtimeSettings?: RealtimeSettings;
  authSettings?: AuthSecuritySettings;
  authLogs?: AuthLog[];
  latestAiAnalysis?: AiHealthAnalysis;
  dynamicWebsite?: DynamicWebsiteConfig;
}
