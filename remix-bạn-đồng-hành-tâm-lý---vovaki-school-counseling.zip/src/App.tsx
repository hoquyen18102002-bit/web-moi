import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { FooterNav } from './components/FooterNav';
import { LoginModal } from './components/LoginModal';
import { HomeArticles } from './components/HomeArticles';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { CounselorDashboard } from './components/counselor/CounselorDashboard';
import { HomeroomDashboard } from './components/homeroom/HomeroomDashboard';
import { StudentDashboard } from './components/student/StudentDashboard';
import { PositiveRoomModal } from './components/positiveRoom/PositiveRoomModal';
import { TestTakerModal } from './components/tests/TestTakerModal';
import { VirtualCounselingChat } from './components/chat/VirtualCounselingChat';
import { DynamicHeader } from './components/pageBuilder/DynamicHeader';
import { DynamicPageRenderer } from './components/pageBuilder/DynamicPageRenderer';
import { DynamicFooter } from './components/pageBuilder/DynamicFooter';

const MainLayout: React.FC = () => {
  const {
    state,
    currentUser,
    currentView,
    setCurrentView,
    activeBookingId,
    setActiveBookingId,
    activeEmergencyId,
    setActiveEmergencyId,
  } = useApp();

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isPositiveRoomOpen, setIsPositiveRoomOpen] = useState(false);
  const [activeTestId, setActiveTestId] = useState<string | null>(null);

  // Dynamic Font Family
  const getFontFamilyStyle = () => {
    switch (state.siteSettings.fontFamily) {
      case 'Nunito':
        return { fontFamily: "'Nunito', sans-serif" };
      case 'Merriweather':
        return { fontFamily: "'Merriweather', serif" };
      case 'Be Vietnam Pro':
      default:
        return { fontFamily: "'Be Vietnam Pro', sans-serif" };
    }
  };

  // Dynamic Theme Styling
  const getThemeClass = () => {
    switch (state.siteSettings.theme) {
      case 'dark':
        return 'bg-stone-900 text-stone-100';
      case 'soft-warm':
        return 'bg-[#faf8f5] text-stone-900';
      case 'light':
      default:
        return 'bg-stone-50/70 text-stone-900';
    }
  };

  // Render Dashboard according to Current User Role
  const renderDashboard = () => {
    if (!currentUser) {
      return (
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center shadow-xs space-y-4 max-w-xl mx-auto my-8">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
            <span className="text-2xl font-bold">🔒</span>
          </div>
          <h3 className="font-bold text-lg text-stone-900">
            Yêu cầu Đăng nhập để Sử dụng Chức năng
          </h3>
          <p className="text-xs text-stone-600 leading-relaxed">
            Hệ thống phân quyền độc lập theo 4 nhóm đối tượng: Quản trị viên, Giáo viên Tư vấn, Giáo viên Chủ nhiệm và Học sinh. Vui lòng đăng nhập với vai trò của bạn để truy cập.
          </p>
          <button
            type="button"
            onClick={() => setIsLoginModalOpen(true)}
            className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs"
          >
            Đăng nhập ngay
          </button>
        </div>
      );
    }

    switch (currentUser.role) {
      case 'admin':
        return <AdminDashboard />;
      case 'counselor':
        return (
          <CounselorDashboard
            onOpenVirtualChat={(bookingId) => setActiveBookingId(bookingId)}
            onOpenEmergencyChat={(sessionId) => setActiveEmergencyId(sessionId)}
            onOpenPositiveRoom={() => setIsPositiveRoomOpen(true)}
          />
        );
      case 'homeroom':
        return <HomeroomDashboard />;
      case 'student':
        return (
          <StudentDashboard
            onOpenPositiveRoom={() => setIsPositiveRoomOpen(true)}
            onOpenTestTaker={(testId) => setActiveTestId(testId)}
            onOpenVirtualChat={(bookingId) => setActiveBookingId(bookingId)}
            onOpenEmergencyChat={(sessionId) => setActiveEmergencyId(sessionId)}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div
      className={`min-h-screen flex flex-col selection:bg-emerald-200 selection:text-emerald-950 ${getThemeClass()}`}
      style={{
        ...getFontFamilyStyle(),
        backgroundImage: state.siteSettings.backdropUrl ? `url(${state.siteSettings.backdropUrl})` : undefined,
        backgroundSize: 'cover',
        backgroundAttachment: 'fixed',
      }}
    >
      {/* Top Navigation - Dynamic or Fallback */}
      {state.dynamicWebsite ? (
        <DynamicHeader
          header={state.dynamicWebsite.header}
          menu={state.dynamicWebsite.menu}
          theme={state.dynamicWebsite.theme}
          onOpenLogin={() => setIsLoginModalOpen(true)}
        />
      ) : (
        <Navbar onOpenLogin={() => setIsLoginModalOpen(true)} />
      )}

      {/* Main Content Area */}
      <main className={`flex-1 w-full mx-auto ${currentView === 'home' ? '' : 'max-w-7xl px-4 sm:px-6 py-8'}`}>
        {currentView === 'home' ? (
          state.dynamicWebsite ? (
            <DynamicPageRenderer
              page={
                state.dynamicWebsite.pages.find(
                  (p) => p.id === (state.dynamicWebsite?.activePageId || 'page-home')
                ) || state.dynamicWebsite.pages[0]
              }
              theme={state.dynamicWebsite.theme}
              isLiveEditing={false}
              onOpenPositiveRoom={() => setIsPositiveRoomOpen(true)}
              onOpenTestTaker={(testId) => setActiveTestId(testId)}
              onOpenLogin={() => setIsLoginModalOpen(true)}
            />
          ) : (
            <HomeArticles onOpenLogin={() => setIsLoginModalOpen(true)} />
          )
        ) : (
          renderDashboard()
        )}
      </main>

      {/* Footer & Floating Navigation Bar */}
      {state.dynamicWebsite ? (
        <DynamicFooter
          footer={state.dynamicWebsite.footer}
          theme={state.dynamicWebsite.theme}
          onOpenLogin={() => setIsLoginModalOpen(true)}
        />
      ) : (
        <FooterNav onOpenLogin={() => setIsLoginModalOpen(true)} />
      )}

      {/* Modal Dialogs */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
      />

      <PositiveRoomModal
        isOpen={isPositiveRoomOpen}
        onClose={() => setIsPositiveRoomOpen(false)}
      />

      {activeTestId && (
        <TestTakerModal
          testId={activeTestId}
          onClose={() => setActiveTestId(null)}
        />
      )}

      {activeBookingId && (
        <VirtualCounselingChat
          type="booking"
          targetId={activeBookingId}
          onClose={() => setActiveBookingId(null)}
        />
      )}

      {activeEmergencyId && (
        <VirtualCounselingChat
          type="emergency"
          targetId={activeEmergencyId}
          onClose={() => setActiveEmergencyId(null)}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
