// Dynamic Website Architecture & Page Builder Types

export type BlockType =
  | 'heading'
  | 'paragraph'
  | 'image'
  | 'video'
  | 'banner'
  | 'button'
  | 'form'
  | 'table'
  | 'chart'
  | 'list'
  | 'card'
  | 'widget'
  | 'menu'
  | 'footer'
  | 'articles_module'
  | 'tests_module'
  | 'emergency_module'
  | 'hotline_module'
  | 'positive_room_teaser';

export type SectionLayout = '1-col' | '2-col-equal' | '2-col-1-2' | '2-col-2-1' | '3-col-equal' | '4-col-equal';

export interface PageBlock {
  id: string;
  type: BlockType;
  title?: string;
  content: {
    text?: string;
    subText?: string;
    badge?: string;
    imageUrl?: string;
    videoUrl?: string;
    buttonText?: string;
    buttonLink?: string;
    buttonVariant?: 'primary' | 'secondary' | 'outline' | 'danger' | 'amber';
    alignment?: 'left' | 'center' | 'right';
    // For lists or cards
    items?: Array<{
      id: string;
      title: string;
      description?: string;
      icon?: string;
      badge?: string;
      link?: string;
    }>;
    // For tables
    headers?: string[];
    rows?: string[][];
    // For charts
    chartType?: 'bar' | 'pie' | 'line';
    chartData?: Array<{ label: string; value: number; color?: string }>;
    // Custom widget configuration
    widgetKey?: string;
    formFields?: Array<{ name: string; label: string; type: string; placeholder?: string }>;
  };
  style: {
    textColor?: string;
    backgroundColor?: string;
    fontSize?: 'xs' | 'sm' | 'base' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl';
    fontWeight?: 'normal' | 'medium' | 'semibold' | 'bold' | 'extrabold';
    paddingY?: number; // rem or px scale
    paddingX?: number;
    marginTop?: number;
    marginBottom?: number;
    borderRadius?: 'none' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | 'full';
    shadow?: 'none' | 'xs' | 'sm' | 'md' | 'lg' | 'xl';
    border?: boolean;
    borderColor?: string;
  };
  columnSpan?: number; // 1 to 12
  columnIndex?: number; // 0, 1, 2...
  isVisible: boolean;
}

export interface PageSection {
  id: string;
  name: string;
  layout: SectionLayout;
  fullWidth?: boolean;
  minHeight?: string; // e.g. 'auto', '300px', '500px', '80vh'
  spacing?: 'compact' | 'normal' | 'generous';
  paddingTop?: number; // e.g. 4, 8, 12, 16
  paddingBottom?: number;
  marginTop?: number;
  marginBottom?: number;
  backgroundColor?: string;
  backgroundImageUrl?: string;
  backgroundOverlay?: 'none' | 'dark' | 'light' | 'gradient';
  textColor?: string;
  isVisible: boolean;
  blocks: PageBlock[];
}

export interface DynamicPage {
  id: string; // e.g. 'home', 'about', 'services', 'counseling-guide', 'contact'
  slug: string;
  title: string;
  description?: string;
  isPublished: boolean;
  sections: PageSection[];
  createdAt: string;
  updatedAt: string;
}

export interface NavMenuItem {
  id: string;
  label: string;
  path: string;
  targetType: 'page' | 'external' | 'action'; // 'page': slug, 'action': login, positive_room, tests, etc.
  targetAction?: 'login' | 'dashboard' | 'positive_room' | 'emergency' | 'tests';
  isOpenNewTab?: boolean;
  order: number;
  children?: NavMenuItem[];
}

export interface HeaderConfig {
  logoText: string;
  logoSubtext?: string;
  logoIconUrl?: string;
  logoPosition: 'left' | 'center' | 'right';
  navAlignment: 'left' | 'center' | 'right';
  heightPx: number; // e.g. 64, 72, 80
  backgroundColor: string;
  textColor: string;
  isSticky: boolean;
  showEmergencyHotline: boolean;
  showAuthButton: boolean;
  actionButtons: Array<{
    id: string;
    label: string;
    type: 'login' | 'positive_room' | 'emergency' | 'link';
    url?: string;
    variant: 'primary' | 'secondary' | 'accent' | 'danger';
  }>;
}

export interface FooterColumn {
  id: string;
  title: string;
  content: string;
  links: Array<{
    id: string;
    label: string;
    url: string;
  }>;
}

export interface FooterConfig {
  layout: '3-col' | '4-col' | 'minimal';
  backgroundColor: string;
  textColor: string;
  logoUrl?: string;
  copyrightText: string;
  columns: FooterColumn[];
  socialLinks: Array<{
    id: string;
    platform: 'facebook' | 'zalo' | 'youtube' | 'website' | 'email';
    label: string;
    url: string;
  }>;
  showBackToTop: boolean;
}

export interface ThemeDesignSystem {
  primaryColor: string; // e.g. #059669
  secondaryColor: string; // e.g. #0284c7
  accentColor: string; // e.g. #f59e0b
  backgroundColor: string; // e.g. #ffffff or #faf8f5
  surfaceColor: string; // cards, modals: #ffffff
  textColor: string; // #1c1917
  mutedTextColor: string; // #78716c
  fontFamily: 'Be Vietnam Pro' | 'Nunito' | 'Merriweather' | 'Inter' | 'Roboto';
  headingFontFamily?: 'Be Vietnam Pro' | 'Nunito' | 'Merriweather' | 'Playfair Display';
  fontSizeBase: '14px' | '15px' | '16px' | '18px';
  buttonStyle: 'rounded-md' | 'rounded-xl' | 'rounded-2xl' | 'rounded-full';
  cardRadius: 'rounded-lg' | 'rounded-2xl' | 'rounded-3xl';
  cardShadow: 'shadow-none' | 'shadow-xs' | 'shadow-md' | 'shadow-xl';
  containerMaxWidth: 'max-w-5xl' | 'max-w-6xl' | 'max-w-7xl' | 'max-w-full';
}

export interface WebsiteVersion {
  id: string;
  versionNumber: number;
  createdAt: string;
  createdByName: string;
  createdByRole: string;
  changeSummary: string;
  snapshot: {
    theme: ThemeDesignSystem;
    header: HeaderConfig;
    footer: FooterConfig;
    menu: NavMenuItem[];
    pages: DynamicPage[];
  };
}

export interface DynamicWebsiteConfig {
  theme: ThemeDesignSystem;
  header: HeaderConfig;
  footer: FooterConfig;
  menu: NavMenuItem[];
  pages: DynamicPage[];
  activePageId: string;
  versions: WebsiteVersion[];
  liveEditorActive?: boolean;
}
