import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Calendar,
  AlertTriangle,
  Sparkles,
  ClipboardList,
  FolderHeart,
  Bot,
  MessageSquare,
  Lock,
  Unlock,
  Plus,
  Trash2,
  CheckCircle,
  Eye,
  Sliders,
  Send,
  Volume2,
  FileText,
  UserPlus,
  Brain,
  Activity,
  CheckCircle2,
  RefreshCw,
  BookOpen,
} from 'lucide-react';
import { PsychologicalTest, TestQuestion, ScoreTier, StudentHealthRecord, SentimentAnalysisResult } from '../../types';
import { CounselorArticleManager } from './CounselorArticleManager';

export const CounselorDashboard: React.FC<{
  onOpenVirtualChat: (bookingId: string) => void;
  onOpenEmergencyChat: (sessionId: string) => void;
  onOpenPositiveRoom: () => void;
}> = ({ onOpenVirtualChat, onOpenEmergencyChat, onOpenPositiveRoom }) => {
  const {
    state,
    updateSharedState,
    runAiHealthAnalysis,
    steerPositiveRoom,
    refreshState,
    analyzeSessionSentiment,
  } = useApp();

  const [activeTab, setActiveTab] = useState<
    'bookings' | 'emergency' | 'positive_room_monitor' | 'test_management' | 'health_records' | 'ai_analysis' | 'articles'
  >('bookings');

  // Filter states
  const [selectedGrade, setSelectedGrade] = useState<number>(0); // 0 = all
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // AI Analysis state
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Sentiment Analysis UI state
  const [analyzingTargetId, setAnalyzingTargetId] = useState<string | null>(null);
  const [sentimentModalData, setSentimentModalData] = useState<SentimentAnalysisResult | null>(null);

  // Positive Room live supervision state
  const [selectedSessionId, setSelectedSessionId] = useState<string>(
    state.positiveRoomSessions[0]?.id || ''
  );
  const [guidanceInput, setGuidanceInput] = useState('');
  const [overrideInput, setOverrideInput] = useState('');
  const [liveNotesInput, setLiveNotesInput] = useState('');
  const [steerSuccessMsg, setSteerSuccessMsg] = useState('');

  // Remote UI customization for positive room
  const [remoteAvatar, setRemoteAvatar] = useState(state.siteSettings.positiveRoomAvatar);
  const [remoteTheme, setRemoteTheme] = useState(state.siteSettings.positiveRoomTheme);
  const [remoteVoiceTone, setRemoteVoiceTone] = useState(state.siteSettings.positiveRoomVoiceTone);

  // Test creation/editing state
  const [showCreateTestModal, setShowCreateTestModal] = useState(false);
  const [newTestMonth, setNewTestMonth] = useState('2026-10');
  const [newTestTitle, setNewTestTitle] = useState('Khảo sát Sức khỏe Tâm lý & Tương tác Bạn bè Tháng 10');
  const [newTestDesc, setNewTestDesc] = useState('Đánh giá cảm xúc, mức độ gắn kết học đường và dấu hiệu căng thẳng.');
  const [questionsList, setQuestionsList] = useState<TestQuestion[]>([
    {
      id: 'nq1',
      content: 'Em cảm thấy áp lực lớn từ bài tập hoặc kỳ vọng của gia đình:',
      options: [
        { text: 'Hoàn toàn không', score: 0 },
        { text: 'Thỉnh thoảng', score: 1 },
        { text: 'Thường xuyên', score: 2 },
        { text: 'Hầu như mỗi ngày', score: 3 },
      ],
    },
    {
      id: 'nq2',
      content: 'Em khó tập trung trong giờ học hoặc cảm thấy chán nản:',
      options: [
        { text: 'Không gặp khó khăn', score: 0 },
        { text: 'Vài ngày trong tuần', score: 1 },
        { text: 'Hơn một nửa số ngày', score: 2 },
        { text: 'Gần như liên tục', score: 3 },
      ],
    },
  ]);
  const [scoreTiers, setScoreTiers] = useState<ScoreTier[]>([
    {
      label: 'Bình thường',
      minScore: 0,
      maxScore: 3,
      color: 'emerald',
      description: 'Tâm lý ổn định, sinh hoạt điều độ.',
      actionRecommendation: 'Duy trì lối sống lành mạnh và kết nối bạn bè.',
    },
    {
      label: 'Cần lưu ý',
      minScore: 4,
      maxScore: 6,
      color: 'amber',
      description: 'Có biểu hiện căng thẳng cảm xúc nhẹ.',
      actionRecommendation: 'Khuyến khích trò chuyện cùng AI Vovakier hoặc GVCN.',
    },
    {
      label: 'Cần đặc biệt lưu ý',
      minScore: 7,
      maxScore: 12,
      color: 'rose',
      description: 'Nguy cơ lo âu hoặc trầm cảm cần can thiệp.',
      actionRecommendation: 'GV Tư vấn chủ động tham vấn riêng 1-1.',
    },
  ]);

  // Student Health Records: Add Student Modal
  const [showAddStudentRecordModal, setShowAddStudentRecordModal] = useState(false);
  const [newRecordStudentName, setNewRecordStudentName] = useState('');
  const [newRecordStudentCode, setNewRecordStudentCode] = useState('');
  const [newRecordClassId, setNewRecordClassId] = useState('10A1');
  const [newRecordGrade, setNewRecordGrade] = useState(10);
  const [newRecordStatus, setNewRecordStatus] = useState<'Bình thường' | 'Cần lưu ý' | 'Cần đặc biệt lưu ý'>('Bình thường');
  const [newRecordNotes, setNewRecordNotes] = useState('');

  // Class addition
  const [newClassName, setNewClassName] = useState('');

  // Toggle class access for Homeroom Teachers
  const handleToggleClassAccess = (classId: string) => {
    const updatedAccess = state.classAccess.map((ca) => {
      if (ca.classId === classId) {
        return {
          ...ca,
          isUnlockedForHomeroom: !ca.isUnlockedForHomeroom,
          unlockedAt: !ca.isUnlockedForHomeroom ? new Date().toISOString().split('T')[0] : undefined,
        };
      }
      return ca;
    });
    updateSharedState({ classAccess: updatedAccess });
  };

  // Add new class
  const handleAddClass = () => {
    if (!newClassName.trim()) return;
    const cleanName = newClassName.trim().toUpperCase();
    if (!state.classes.includes(cleanName)) {
      const gradeNum = parseInt(cleanName.substring(0, 2)) || 10;
      updateSharedState({
        classes: [...state.classes, cleanName],
        classAccess: [
          ...state.classAccess,
          {
            classId: cleanName,
            grade: gradeNum,
            homeroomTeacherId: '',
            isUnlockedForHomeroom: false,
          },
        ],
      });
    }
    setNewClassName('');
  };

  // Delete class
  const handleDeleteClass = (clsName: string) => {
    if (confirm(`Bạn có chắc muốn xóa lớp ${clsName} và các hồ sơ liên quan?`)) {
      updateSharedState({
        classes: state.classes.filter((c) => c !== clsName),
        classAccess: state.classAccess.filter((ca) => ca.classId !== clsName),
        studentRecords: state.studentRecords.filter((r) => r.classId !== clsName),
      });
    }
  };

  // Add student record manually
  const handleAddStudentRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRecordStudentName || !newRecordStudentCode) return;

    const newRec: StudentHealthRecord = {
      id: `rec-${Date.now()}`,
      studentId: `std-${Date.now()}`,
      studentName: newRecordStudentName.trim(),
      studentCode: newRecordStudentCode.trim(),
      classId: newRecordClassId,
      grade: newRecordGrade,
      latestScore: 0,
      status: newRecordStatus,
      lastUpdatedMonth: '2026-09',
      scoreHistory: [],
      counselorNotes: newRecordNotes.trim(),
      homeroomNotes: '',
      specialAttentionFlag: newRecordStatus === 'Cần đặc biệt lưu ý',
    };

    updateSharedState({
      studentRecords: [newRec, ...state.studentRecords],
    });

    setShowAddStudentRecordModal(false);
    setNewRecordStudentName('');
    setNewRecordStudentCode('');
    setNewRecordNotes('');
  };

  // Delete student record
  const handleDeleteStudentRecord = (recId: string) => {
    if (confirm('Bạn có chắc chắn muốn xóa hồ sơ học sinh này khỏi cơ sở dữ liệu?')) {
      updateSharedState({
        studentRecords: state.studentRecords.filter((r) => r.id !== recId),
      });
    }
  };

  // Trigger Counselor guidance or override to Positive Room
  const handleApplySteer = async () => {
    if (!selectedSessionId) return;
    await steerPositiveRoom(selectedSessionId, guidanceInput, liveNotesInput, overrideInput);
    setSteerSuccessMsg('Đã can thiệp & định hướng câu trả lời của AI thành công!');
    setOverrideInput('');
    setTimeout(() => setSteerSuccessMsg(''), 3000);
  };

  // Save remote appearance for positive room
  const handleSaveRemotePositiveRoomUI = () => {
    updateSharedState({
      siteSettings: {
        ...state.siteSettings,
        positiveRoomAvatar: remoteAvatar,
        positiveRoomTheme: remoteTheme,
        positiveRoomVoiceTone: remoteVoiceTone,
      },
    });
    setSteerSuccessMsg('Đã cập nhật giao diện & giọng điệu Phòng tích cực từ xa!');
    setTimeout(() => setSteerSuccessMsg(''), 3000);
  };

  // Run AI Health Analysis
  const handleRunAiAnalysis = async () => {
    setIsAnalyzing(true);
    await runAiHealthAnalysis();
    setIsAnalyzing(false);
  };

  // Trigger Sentiment Analysis for a session
  const handleTriggerSentimentAnalysis = async (
    targetId: string,
    targetType: 'counselor_booking' | 'emergency_session' | 'positive_room',
    messages?: any[],
    studentIdentifier?: string,
    customText?: string
  ) => {
    setAnalyzingTargetId(targetId);
    try {
      const res = await analyzeSessionSentiment(targetId, targetType, messages, studentIdentifier, customText);
      if (res) {
        setSentimentModalData(res);
      }
    } catch (err) {
      console.warn('Sentiment analysis notice:', err);
    } finally {
      setAnalyzingTargetId(null);
    }
  };

  // Save new psychological test
  const handleSaveNewTest = () => {
    const newTest: PsychologicalTest = {
      id: `test-${newTestMonth}-${Date.now()}`,
      month: newTestMonth,
      title: newTestTitle,
      description: newTestDesc,
      targetGrades: [10, 11, 12],
      questions: questionsList,
      scoreTiers,
      createdBy: 'ThS. Nguyễn Mai Phương (Tư vấn Tâm lý)',
      createdAt: new Date().toISOString().split('T')[0],
      isActive: true,
    };

    updateSharedState({
      psychologicalTests: [newTest, ...state.psychologicalTests],
    });
    setShowCreateTestModal(false);
  };

  // Filtered records
  const filteredRecords = state.studentRecords.filter((r) => {
    if (selectedGrade !== 0 && r.grade !== selectedGrade) return false;
    if (selectedClass !== 'all' && r.classId !== selectedClass) return false;
    if (statusFilter !== 'all' && r.status !== statusFilter) return false;
    return true;
  });

  const activeSupervisionSession = state.positiveRoomSessions.find((s) => s.id === selectedSessionId) || state.positiveRoomSessions[0];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
              Giáo viên Tư vấn Tâm lý Học đường
            </span>
            <span className="text-xs text-stone-500">ThS. Nguyễn Mai Phương</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-stone-900 mt-1">
            Không gian Quản lý Tham vấn & Sức khỏe Tinh thần
          </h2>
          <p className="text-xs text-stone-600 mt-0.5">
            Nhận đặt lịch ẩn danh, trực tư vấn khẩn cấp, giám sát AI Phòng tích cực, quản lý hồ sơ và phân tích dữ liệu toàn trường
          </p>
        </div>

        {/* Emergency Alert Badge */}
        {state.emergencySessions.some((s) => s.status === 'active') && (
          <div className="px-4 py-2 rounded-xl bg-red-100 border border-red-300 text-red-800 text-xs font-bold flex items-center gap-2 animate-pulse">
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            <span>Có {state.emergencySessions.filter((s) => s.status === 'active').length} phiên tư vấn khẩn cấp đang chờ!</span>
          </div>
        )}
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-stone-200 pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('bookings')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'bookings'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Nhận đặt lịch ({state.bookings.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('emergency')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'emergency'
              ? 'bg-red-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>Tư vấn khẩn cấp ({state.emergencySessions.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('positive_room_monitor')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'positive_room_monitor'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Giám sát Phòng tích cực - Vovakier</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('test_management')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'test_management'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          <span>Cập nhật bài test tâm lý</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('health_records')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'health_records'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <FolderHeart className="w-4 h-4" />
          <span>Hồ sơ sức khỏe tâm lý ({state.studentRecords.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('ai_analysis')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'ai_analysis'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <Bot className="w-4 h-4" />
          <span>AI Phân tích HS Toàn trường</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('articles')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'articles'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Cập nhật Tin tức & Cẩm nang ({state.articles.length})</span>
        </button>
      </div>

      {/* TAB 1: BOOKINGS */}
      {activeTab === 'bookings' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-stone-200 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-stone-900">Danh sách Đặt lịch Tư vấn từ Học sinh</h3>
              <p className="text-xs text-stone-500">
                Mỗi học sinh được bảo mật tuyệt đối với một mã số ẩn danh riêng biệt trong suốt quá trình trao đổi
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 bg-emerald-50 text-emerald-800 rounded-lg border border-emerald-200">
              Tổng cộng: {state.bookings.length} lịch hẹn
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {state.bookings.map((booking) => (
              <div
                key={booking.id}
                className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold px-2.5 py-1 rounded-md bg-stone-100 text-stone-800 font-mono">
                      Mã ẩn danh: {booking.studentAnonymousCode}
                    </span>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${
                        booking.status === 'confirmed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : booking.status === 'pending'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-stone-100 text-stone-700'
                      }`}
                    >
                      {booking.status === 'confirmed' ? 'Đã xác nhận' : 'Chờ vào phòng'}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-bold text-base text-stone-900">
                      Biệt danh: {booking.nickname}
                    </h4>
                    <p className="text-xs text-stone-500 mt-0.5 flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5" />
                      {booking.date} • {booking.timeSlot}
                    </p>
                  </div>

                  <div className="p-3 bg-stone-50 rounded-xl text-xs text-stone-700">
                    <span className="font-bold text-stone-900 block mb-1">Chủ đề chia sẻ:</span>
                    {booking.topic}
                  </div>

                  {/* AI Sentiment Analysis Block for Booking */}
                  {(() => {
                    const analysis = booking.sentimentAnalysis || state.sentimentAnalyses?.find(s => s.targetId === booking.id);
                    if (analysis) {
                      return (
                        <div className="p-2.5 rounded-xl bg-indigo-50/70 border border-indigo-200 space-y-1.5 text-xs">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1.5">
                              <Brain className="w-3.5 h-3.5 text-indigo-600" />
                              <span className="font-bold text-indigo-950">Phân tích AI:</span>
                              <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                                analysis.sentiment === 'positive'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : analysis.sentiment === 'negative'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-stone-200 text-stone-700'
                              }`}>
                                {analysis.sentiment === 'positive' ? 'Tích cực' : analysis.sentiment === 'negative' ? 'Tiêu cực' : 'Trung tính'}
                              </span>
                            </div>
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              analysis.urgencyLevel === 'Báo động khẩn cấp'
                                ? 'bg-rose-600 text-white animate-pulse'
                                : analysis.urgencyLevel === 'Cần chú ý'
                                ? 'bg-amber-500 text-white'
                                : 'bg-emerald-600 text-white'
                            }`}>
                              {analysis.urgencyLevel}
                            </span>
                          </div>
                          <p className="text-[11px] text-stone-700 font-medium">
                            <span className="font-semibold text-indigo-900">{analysis.emotionalState}:</span> {analysis.summary}
                          </p>
                          <div className="flex items-center justify-between pt-1">
                            <button
                              type="button"
                              onClick={() => setSentimentModalData(analysis)}
                              className="text-[11px] text-indigo-700 hover:underline font-bold"
                            >
                              Xem khuyến nghị →
                            </button>
                            <button
                              type="button"
                              disabled={analyzingTargetId === booking.id}
                              onClick={() => handleTriggerSentimentAnalysis(booking.id, 'counselor_booking', booking.messages, booking.studentAnonymousCode, booking.topic)}
                              className="text-[10px] text-stone-500 hover:text-indigo-600 flex items-center gap-1"
                            >
                              {analyzingTargetId === booking.id ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                              Phân tích lại
                            </button>
                          </div>
                        </div>
                      );
                    }
                    return (
                      <button
                        type="button"
                        disabled={analyzingTargetId === booking.id}
                        onClick={() => handleTriggerSentimentAnalysis(booking.id, 'counselor_booking', booking.messages, booking.studentAnonymousCode, booking.topic)}
                        className="w-full py-1.5 px-3 rounded-lg border border-indigo-200 bg-indigo-50/50 hover:bg-indigo-100 text-indigo-800 text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors"
                      >
                        {analyzingTargetId === booking.id ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                            Đang phân tích cảm xúc...
                          </>
                        ) : (
                          <>
                            <Brain className="w-3.5 h-3.5 text-indigo-600" />
                            Phân tích Cảm xúc & Tâm lý AI
                          </>
                        )}
                      </button>
                    );
                  })()}

                  <div className="text-[11px] text-stone-400">
                    Lịch sử tin nhắn: {booking.messages?.length || 0} tin nhắn lưu trữ
                  </div>
                </div>

                <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                  <span className="text-[11px] text-stone-400">
                    Đăng ký: {booking.createdAt}
                  </span>
                  <button
                    type="button"
                    onClick={() => onOpenVirtualChat(booking.id)}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition-transform active:scale-95"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Vào buổi tư vấn ảo ẩn danh</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: EMERGENCY COUNSELING */}
      {activeTab === 'emergency' && (
        <div className="space-y-4">
          <div className="bg-red-50 border border-red-200 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1">
              <h3 className="font-bold text-base text-red-950 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                Hộp thoại Trực tuyến Khẩn cấp từ Học sinh
              </h3>
              <p className="text-xs text-red-700">
                Khi học sinh bấm 'Trao đổi khẩn cấp với giáo viên', hệ thống lập tức kết nối phiên trực tuyến trực tiếp với giáo viên trực.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {state.emergencySessions.map((emg) => {
              const emgAnalysis = emg.sentimentAnalysis || state.sentimentAnalyses?.find(s => s.targetId === emg.id);
              return (
                <div
                  key={emg.id}
                  className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                >
                  <div className="space-y-2 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded font-mono font-bold text-xs bg-red-100 text-red-800">
                        {emg.studentAnonymousCode}
                      </span>
                      <span className="text-sm font-bold text-stone-900">
                        {emg.studentNickname}
                      </span>
                      <span className="text-xs text-stone-400">
                        • Bắt đầu: {emg.startedAt}
                      </span>
                      {emgAnalysis && (
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          emgAnalysis.sentiment === 'negative' ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          Tâm lý: {emgAnalysis.emotionalState} ({emgAnalysis.sentimentScore}/100)
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-stone-600">
                      Tin nhắn mới nhất:{' '}
                      <em>
                        "{emg.messages[emg.messages.length - 1]?.text || 'Chưa có tin nhắn'}"
                      </em>
                    </p>

                    {emgAnalysis && (
                      <div className="p-2.5 bg-amber-50/80 border border-amber-200 rounded-xl text-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-amber-950 flex items-center gap-1">
                            <Brain className="w-3.5 h-3.5 text-amber-700" />
                            Phân tích cảm xúc: {emgAnalysis.summary}
                          </span>
                          <span className={`px-2 py-0.2 rounded-full font-bold text-[10px] ${
                            emgAnalysis.urgencyLevel === 'Báo động khẩn cấp' ? 'bg-red-600 text-white animate-pulse' : 'bg-amber-500 text-white'
                          }`}>
                            {emgAnalysis.urgencyLevel}
                          </span>
                        </div>
                        {emgAnalysis.distressSignals && emgAnalysis.distressSignals.length > 0 && (
                          <div className="text-[11px] text-red-700 flex flex-wrap gap-1">
                            <span className="font-bold">Dấu hiệu:</span>
                            {emgAnalysis.distressSignals.map((d, i) => (
                              <span key={i} className="px-1.5 py-0.5 rounded bg-red-100 font-medium">{d}</span>
                            ))}
                          </div>
                        )}
                        <button
                          type="button"
                          onClick={() => setSentimentModalData(emgAnalysis)}
                          className="text-[11px] text-amber-800 font-bold hover:underline"
                        >
                          Xem báo cáo chi tiết & hướng dẫn hỗ trợ →
                        </button>
                      </div>
                    )}

                    {emg.counselorNotes && (
                      <p className="text-xs text-emerald-800 bg-emerald-50 px-2 py-1 rounded inline-block">
                        Ghi chú: {emg.counselorNotes}
                      </p>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-2 shrink-0">
                    <button
                      type="button"
                      disabled={analyzingTargetId === emg.id}
                      onClick={() => handleTriggerSentimentAnalysis(emg.id, 'emergency_session', emg.messages, emg.studentAnonymousCode)}
                      className="px-3 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold flex items-center gap-1.5 border border-indigo-200"
                    >
                      {analyzingTargetId === emg.id ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Brain className="w-3.5 h-3.5" />}
                      Phân tích AI
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenEmergencyChat(emg.id)}
                      className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-2 shadow-xs active:scale-95"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Vào trò chuyện trực tiếp ngay</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: POSITIVE ROOM LIVE SUPERVISION & STEERING */}
      {activeTab === 'positive_room_monitor' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-emerald-600" />
                  Giám sát Trực tuyến "Phòng Tích cực - Vovakier" theo Thời gian thực
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Theo dõi học sinh đang trò chuyện bằng giọng nói với AI, định hướng câu trả lời từ xa và can thiệp kịp thời
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onOpenPositiveRoom}
                  className="px-3.5 py-2 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 text-xs font-semibold flex items-center gap-1.5"
                >
                  <Eye className="w-4 h-4 text-emerald-600" />
                  <span>Xem giao diện phía Học sinh</span>
                </button>
              </div>
            </div>

            {steerSuccessMsg && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-semibold flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                {steerSuccessMsg}
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-2">
              {/* Left Column: Live chat monitor stream */}
              <div className="lg:col-span-2 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-700">
                    Cuộc trò chuyện đang diễn ra:
                  </span>
                  <select
                    value={selectedSessionId}
                    onChange={(e) => setSelectedSessionId(e.target.value)}
                    className="text-xs px-2.5 py-1 rounded-lg border border-stone-300 font-medium"
                  >
                    {state.positiveRoomSessions.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.studentAnonymousCode} ({s.studentNickname}) - Bắt đầu {s.startedAt}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Live Positive Room Sentiment Bar */}
                {(() => {
                  const posAnalysis = activeSupervisionSession?.sentimentAnalysis || state.sentimentAnalyses?.find(s => s.targetId === activeSupervisionSession?.id);
                  return (
                    <div className="p-3 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-xl text-xs space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <Brain className="w-4 h-4 text-emerald-700" />
                          <span className="font-bold text-emerald-950">Chỉ số Cảm xúc Học sinh hiện tại:</span>
                          {posAnalysis ? (
                            <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                              posAnalysis.sentiment === 'positive'
                                ? 'bg-emerald-200 text-emerald-900'
                                : posAnalysis.sentiment === 'negative'
                                ? 'bg-rose-100 text-rose-800'
                                : 'bg-stone-200 text-stone-800'
                            }`}>
                              {posAnalysis.emotionalState} ({posAnalysis.sentimentScore}/100)
                            </span>
                          ) : (
                            <span className="text-[11px] text-stone-500 italic">Chưa phân tích cho phiên này</span>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {posAnalysis && (
                            <button
                              type="button"
                              onClick={() => setSentimentModalData(posAnalysis)}
                              className="text-[11px] text-emerald-800 font-bold hover:underline"
                            >
                              Xem báo cáo AI →
                            </button>
                          )}
                          <button
                            type="button"
                            disabled={analyzingTargetId === activeSupervisionSession?.id}
                            onClick={() => {
                              if (activeSupervisionSession) {
                                handleTriggerSentimentAnalysis(
                                  activeSupervisionSession.id,
                                  'positive_room',
                                  activeSupervisionSession.messages,
                                  activeSupervisionSession.studentAnonymousCode
                                );
                              }
                            }}
                            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] flex items-center gap-1 shadow-xs transition-colors"
                          >
                            {analyzingTargetId === activeSupervisionSession?.id ? (
                              <RefreshCw className="w-3 h-3 animate-spin" />
                            ) : (
                              <Sparkles className="w-3 h-3" />
                            )}
                            {posAnalysis ? 'Phân tích lại' : '⚡ Phân tích cảm xúc'}
                          </button>
                        </div>
                      </div>
                      {posAnalysis && (
                        <p className="text-[11px] text-emerald-900 font-medium leading-relaxed">
                          {posAnalysis.summary}
                        </p>
                      )}
                    </div>
                  );
                })()}

                <div className="bg-stone-50 rounded-2xl border border-stone-200 p-4 h-80 overflow-y-auto space-y-3 font-normal text-xs">
                  {activeSupervisionSession?.messages.map((m) => (
                    <div
                      key={m.id}
                      className={`p-3 rounded-xl max-w-[85%] ${
                        m.sender === 'student'
                          ? 'ml-auto bg-stone-900 text-white rounded-br-xs'
                          : m.isCounselorIntervention
                          ? 'mr-auto bg-purple-100 text-purple-900 border border-purple-300 rounded-bl-xs'
                          : 'mr-auto bg-emerald-100 text-emerald-950 rounded-bl-xs'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-3 text-[10px] opacity-70 mb-1">
                        <span className="font-bold">{m.senderName}</span>
                        <span>{m.timestamp}</span>
                      </div>
                      <p className="leading-relaxed whitespace-pre-line">{m.text}</p>
                    </div>
                  ))}
                </div>

                {/* Counselor Intervention Inputs */}
                <div className="p-4 rounded-xl bg-purple-50/70 border border-purple-200 space-y-3">
                  <h4 className="text-xs font-bold text-purple-900 flex items-center gap-1.5">
                    <Sliders className="w-4 h-4 text-purple-600" />
                    Chỉ đạo & Can thiệp vào Câu trả lời của AI:
                  </h4>

                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      1. Định hướng phản hồi cho AI (Guidance Prompt):
                    </label>
                    <input
                      type="text"
                      value={guidanceInput}
                      onChange={(e) => setGuidanceInput(e.target.value)}
                      placeholder="Ví dụ: Khuyên học sinh thở chậm 3 nhịp, nhắc em đi ngủ trước 23h..."
                      className="w-full px-3 py-2 rounded-lg border border-purple-200 text-xs bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      2. Gửi câu trả lời trực tiếp (Thay lời AI trả lời học sinh ngay):
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={overrideInput}
                        onChange={(e) => setOverrideInput(e.target.value)}
                        placeholder="Nội dung giáo viên trực tiếp can thiệp gửi tới học sinh..."
                        className="flex-1 px-3 py-2 rounded-lg border border-purple-200 text-xs bg-white"
                      />
                      <button
                        type="button"
                        onClick={handleApplySteer}
                        className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shrink-0 flex items-center gap-1"
                      >
                        <Send className="w-3.5 h-3.5" />
                        Gửi can thiệp
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column: Remote Appearance & Sound Settings */}
              <div className="space-y-4 bg-stone-50 p-4 rounded-2xl border border-stone-200 text-xs">
                <h4 className="font-bold text-stone-900 flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-emerald-600" />
                  Cấu hình Từ xa Giao diện & Âm thanh AI
                </h4>

                <div className="space-y-2">
                  <label className="block font-semibold text-stone-700">
                    Ảnh hiển thị đại diện Vovakier (Avatar):
                  </label>
                  <div className="flex items-center gap-3">
                    <img
                      src={remoteAvatar}
                      alt="Avatar"
                      className="w-12 h-12 rounded-full object-cover border-2 border-emerald-500"
                    />
                    <input
                      type="text"
                      value={remoteAvatar}
                      onChange={(e) => setRemoteAvatar(e.target.value)}
                      className="flex-1 px-2.5 py-1.5 rounded-lg border border-stone-300 text-[11px] bg-white"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block font-semibold text-stone-700">
                    Không gian cảnh nền Phòng tích cực:
                  </label>
                  <select
                    value={remoteTheme}
                    onChange={(e) => setRemoteTheme(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 bg-white"
                  >
                    <option value="aurora">Ánh cực quang dịu êm (Aurora Calm)</option>
                    <option value="sunset">Hoàng hôn ấm áp (Sunset Warmth)</option>
                    <option value="zen">Khu vườn Zen tĩnh lặng (Zen Garden)</option>
                    <option value="ocean">Đại dương bao la (Ocean Blue)</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="block font-semibold text-stone-700">
                    Giọng điệu phản hồi của AI:
                  </label>
                  <select
                    value={remoteVoiceTone}
                    onChange={(e) => setRemoteVoiceTone(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 bg-white"
                  >
                    <option value="gentle">Dịu dàng, vỗ về (Gentle & Soothing)</option>
                    <option value="warm">Ấm áp, ân cần (Warm & Friendly)</option>
                    <option value="encouraging">Động viên, khích lệ (Encouraging)</option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleSaveRemotePositiveRoomUI}
                  className="w-full py-2 rounded-xl bg-stone-900 hover:bg-black text-white font-bold text-xs shadow-xs"
                >
                  Áp dụng cấu hình từ xa
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: PSYCHOLOGICAL TEST MANAGEMENT */}
      {activeTab === 'test_management' && (
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-base text-stone-900">
                Cập nhật & Quản lý Bài test Sức khỏe Tâm lý theo Tháng
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                Thiết lập câu hỏi, mức điểm đánh giá cụ thể và thang phân loại (Bình thường - Cần lưu ý - Cần đặc biệt lưu ý)
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowCreateTestModal(true)}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-4 h-4" />
              Tạo bài test tháng mới
            </button>
          </div>

          <div className="space-y-4">
            {state.psychologicalTests.map((test) => (
              <div
                key={test.id}
                className="bg-white rounded-2xl border border-stone-200 p-6 shadow-xs space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-stone-100 pb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        Tháng {test.month}
                      </span>
                      <span className="text-xs text-stone-400">
                        Người tạo: {test.createdBy}
                      </span>
                    </div>
                    <h4 className="text-base font-bold text-stone-900 mt-1">
                      {test.title}
                    </h4>
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded bg-stone-100 text-stone-700">
                    Dành cho Khối 10, 11, 12
                  </span>
                </div>

                <p className="text-xs text-stone-600">{test.description}</p>

                {/* Question count & Rubric tiers */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {test.scoreTiers.map((tier) => (
                    <div
                      key={tier.label}
                      className={`p-3 rounded-xl border text-xs ${
                        tier.label === 'Bình thường'
                          ? 'border-emerald-200 bg-emerald-50/50 text-emerald-950'
                          : tier.label === 'Cần lưu ý'
                          ? 'border-amber-200 bg-amber-50/50 text-amber-950'
                          : 'border-rose-200 bg-rose-50/50 text-rose-950'
                      }`}
                    >
                      <div className="font-bold flex items-center justify-between">
                        <span>{tier.label}</span>
                        <span className="font-mono">{tier.minScore} - {tier.maxScore} điểm</span>
                      </div>
                      <p className="text-[11px] mt-1 opacity-80">{tier.description}</p>
                      <div className="text-[10px] mt-1.5 font-medium underline">
                        Đề xuất: {tier.actionRecommendation}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="text-xs text-stone-500 flex items-center justify-between pt-2">
                  <span>Tổng số câu hỏi: <strong>{test.questions.length} câu</strong></span>
                  <span>Đã có <strong>{state.testSubmissions.filter((s) => s.testId === test.id).length} lượt hoàn thành</strong></span>
                </div>
              </div>
            ))}
          </div>

          {/* Submissions Statistics Table */}
          <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs space-y-3 p-5">
            <h4 className="font-bold text-sm text-stone-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-600" />
              Thống kê Kết quả Bài test (Tên - Lớp - Mức điểm - Đánh giá)
            </h4>
            <p className="text-xs text-stone-500">
              Dữ liệu tự động liên kết trực tiếp đến "Hồ sơ sức khỏe của học sinh"
            </p>

            <div className="overflow-x-auto pt-2">
              <table className="w-full text-left text-xs text-stone-700">
                <thead className="bg-stone-50 text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                  <tr>
                    <th className="px-3 py-2.5">Họ và Tên</th>
                    <th className="px-3 py-2.5">Mã HS</th>
                    <th className="px-3 py-2.5">Lớp</th>
                    <th className="px-3 py-2.5">Tháng</th>
                    <th className="px-3 py-2.5">Mức điểm</th>
                    <th className="px-3 py-2.5">Đánh giá</th>
                    <th className="px-3 py-2.5">Thời gian nộp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {state.testSubmissions.map((sub) => (
                    <tr key={sub.id} className="hover:bg-stone-50">
                      <td className="px-3 py-2.5 font-bold text-stone-900">{sub.studentName}</td>
                      <td className="px-3 py-2.5 font-mono text-stone-500">{sub.studentCode}</td>
                      <td className="px-3 py-2.5 font-semibold text-stone-800">{sub.classId}</td>
                      <td className="px-3 py-2.5 text-stone-500">{sub.month}</td>
                      <td className="px-3 py-2.5 font-mono font-bold text-stone-900">{sub.totalScore}</td>
                      <td className="px-3 py-2.5">
                        <span
                          className={`px-2 py-0.5 rounded-full font-bold text-[11px] ${
                            sub.evaluation === 'Bình thường'
                              ? 'bg-emerald-100 text-emerald-800'
                              : sub.evaluation === 'Cần lưu ý'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {sub.evaluation}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-stone-400">{sub.submittedAt}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: STUDENT HEALTH RECORDS (10, 11, 12) & CLASS ACCESS CONTROL */}
      {activeTab === 'health_records' && (
        <div className="space-y-6">
          {/* Class Access Management: Lock/Unlock for Homeroom Teachers */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-emerald-600" />
                  Quyền Mở / Khóa Hồ sơ Sức khỏe Tâm lý cho Giáo viên Chủ nhiệm
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  Kiểm soát quyền truy cập của GVCN theo từng lớp học để đảm bảo tính bảo mật chuyên môn
                </p>
              </div>

              {/* Add class control */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Thêm lớp mới (VD: 10A4)"
                  value={newClassName}
                  onChange={(e) => setNewClassName(e.target.value)}
                  className="px-3 py-1.5 rounded-lg border border-stone-300 text-xs w-36 uppercase font-bold"
                />
                <button
                  type="button"
                  onClick={handleAddClass}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Thêm lớp
                </button>
              </div>
            </div>

            {/* Class Cards with Lock/Unlock switch */}
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
              {state.classAccess.map((ca) => (
                <div
                  key={ca.classId}
                  className={`p-3 rounded-xl border flex flex-col justify-between space-y-2 text-center transition-all ${
                    ca.isUnlockedForHomeroom
                      ? 'border-emerald-300 bg-emerald-50/60'
                      : 'border-stone-200 bg-stone-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-stone-900">{ca.classId}</span>
                    <button
                      type="button"
                      onClick={() => handleDeleteClass(ca.classId)}
                      className="text-stone-300 hover:text-red-600 text-[11px]"
                      title="Xóa lớp"
                    >
                      ✕
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleToggleClassAccess(ca.classId)}
                    className={`py-1 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-all ${
                      ca.isUnlockedForHomeroom
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
                    }`}
                  >
                    {ca.isUnlockedForHomeroom ? (
                      <>
                        <Unlock className="w-3 h-3" />
                        Đang Mở
                      </>
                    ) : (
                      <>
                        <Lock className="w-3 h-3" />
                        Đang Khóa
                      </>
                    )}
                  </button>
                  <span className="text-[10px] text-stone-400">
                    Khối {ca.grade}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Student Health Records Filter & Table */}
          <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="font-bold text-base text-stone-900">
                  Hồ sơ Sức khỏe Tâm lý Học sinh (Khối 10, 11, 12)
                </h3>
                <p className="text-xs text-stone-500">
                  Lưu trữ mức điểm tâm lý, trạng thái và ghi chú phối hợp giữa GV Tư vấn và GV Chủ nhiệm
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowAddStudentRecordModal(true)}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs"
              >
                <UserPlus className="w-4 h-4" />
                Thêm học sinh vào hồ sơ
              </button>
            </div>

            {/* Filter controls */}
            <div className="flex flex-wrap items-center gap-2.5 pt-2 border-t border-stone-100 text-xs">
              <span className="font-bold text-stone-700">Lọc theo:</span>
              <select
                value={selectedGrade}
                onChange={(e) => setSelectedGrade(Number(e.target.value))}
                className="px-3 py-1.5 rounded-lg border border-stone-300 bg-white"
              >
                <option value={0}>Tất cả khối</option>
                <option value={10}>Khối 10</option>
                <option value={11}>Khối 11</option>
                <option value={12}>Khối 12</option>
              </select>

              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="px-3 py-1.5 rounded-lg border border-stone-300 bg-white"
              >
                <option value="all">Tất cả các lớp</option>
                {state.classes.map((c) => (
                  <option key={c} value={c}>Lớp {c}</option>
                ))}
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-1.5 rounded-lg border border-stone-300 bg-white"
              >
                <option value="all">Tất cả trạng thái</option>
                <option value="Bình thường">Bình thường</option>
                <option value="Cần lưu ý">Cần lưu ý</option>
                <option value="Cần đặc biệt lưu ý">Cần đặc biệt lưu ý</option>
              </select>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-stone-700">
                <thead className="bg-stone-50 border-b border-stone-200 text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                  <tr>
                    <th className="px-4 py-3">Học sinh</th>
                    <th className="px-4 py-3">Lớp & Khối</th>
                    <th className="px-4 py-3">Điểm gần nhất</th>
                    <th className="px-4 py-3">Trạng thái tâm lý</th>
                    <th className="px-4 py-3">Ghi chú Chuyên môn (GV Tư vấn)</th>
                    <th className="px-4 py-3">Ghi chú GV Chủ nhiệm</th>
                    <th className="px-4 py-3 text-right">Xóa</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {filteredRecords.map((r) => (
                    <tr key={r.id} className="hover:bg-stone-50">
                      <td className="px-4 py-3 font-bold text-stone-900">
                        <div>{r.studentName}</div>
                        <span className="font-mono text-[10px] text-stone-400 font-normal">
                          {r.studentCode}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 bg-stone-100 rounded font-semibold text-stone-800">
                          {r.classId}
                        </span>
                        <span className="text-[10px] text-stone-400 ml-1">K{r.grade}</span>
                      </td>
                      <td className="px-4 py-3 font-mono font-bold text-stone-900">
                        {r.latestScore}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2.5 py-1 rounded-full font-bold text-[11px] ${
                            r.status === 'Bình thường'
                              ? 'bg-emerald-100 text-emerald-800'
                              : r.status === 'Cần lưu ý'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {r.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-stone-700 max-w-xs">
                        <input
                          type="text"
                          defaultValue={r.counselorNotes}
                          onBlur={(e) => {
                            const updated = state.studentRecords.map((item) =>
                              item.id === r.id ? { ...item, counselorNotes: e.target.value } : item
                            );
                            updateSharedState({ studentRecords: updated });
                          }}
                          placeholder="Nhập ghi chú tư vấn..."
                          className="w-full px-2 py-1 rounded border border-transparent hover:border-stone-300 focus:border-emerald-500 bg-transparent"
                        />
                      </td>
                      <td className="px-4 py-3 text-stone-500 max-w-xs italic text-[11px]">
                        {r.homeroomNotes || 'Chưa có nhận xét của GVCN'}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          type="button"
                          onClick={() => handleDeleteStudentRecord(r.id)}
                          className="p-1 text-stone-300 hover:text-red-600"
                          title="Xóa hồ sơ"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: AI HEALTH ANALYSIS (GEMINI) */}
      {activeTab === 'ai_analysis' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-indigo-900 to-purple-900 text-white rounded-2xl p-6 shadow-md flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-white/20 text-indigo-200 border border-white/20">
                Gemini AI School Mental Health Analytics
              </span>
              <h3 className="text-xl font-extrabold tracking-tight">
                Phân tích Sức khỏe Tâm lý Học sinh Toàn trường
              </h3>
              <p className="text-xs text-indigo-200 max-w-2xl">
                Tự động quét hồ sơ bài test, phân tích nội dung cuộc trò chuyện ẩn danh, cảnh báo mức độ trầm cảm và đề xuất hành động can thiệp.
              </p>
            </div>

            <button
              type="button"
              onClick={handleRunAiAnalysis}
              disabled={isAnalyzing}
              className="px-6 py-3 rounded-xl bg-white text-indigo-950 font-bold text-xs shadow-lg hover:bg-indigo-50 transition-all flex items-center gap-2 active:scale-95 disabled:opacity-50"
            >
              <Bot className="w-4 h-4 text-indigo-600" />
              <span>{isAnalyzing ? 'Đang phân tích dữ liệu...' : 'Yêu cầu AI phân tích ngay'}</span>
            </button>
          </div>

          {state.latestAiAnalysis ? (
            <div className="space-y-6">
              {/* Overview summary */}
              <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-2">
                <div className="flex items-center justify-between text-xs text-stone-400">
                  <span className="font-bold text-stone-700">TỔNG QUAN ĐÁNH GIÁ:</span>
                  <span>Thời điểm tạo: {state.latestAiAnalysis.generatedAt}</span>
                </div>
                <p className="text-sm font-medium text-stone-800 leading-relaxed">
                  {state.latestAiAnalysis.summary}
                </p>
              </div>

              {/* 1. Potential Phenomena Warnings */}
              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
                <h4 className="font-bold text-base text-stone-900 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-600" />
                  1. Các hiện tượng tâm lý học sinh có thể gặp (Cảnh báo xu hướng)
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {state.latestAiAnalysis.potentialPhenomena.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl border border-stone-200 bg-stone-50 space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-sm text-stone-900">{item.title}</span>
                        <span
                          className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                            item.riskLevel === 'Cao'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          Nguy cơ: {item.riskLevel}
                        </span>
                      </div>
                      <p className="text-stone-600 leading-relaxed">{item.description}</p>
                      <div>
                        <span className="font-bold text-stone-800">Dấu hiệu nhận biết:</span>
                        <ul className="list-disc list-inside text-stone-500 pl-1 mt-0.5">
                          {item.warningSigns.map((s, sIdx) => (
                            <li key={sIdx}>{s}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="pt-1 text-emerald-700 font-medium">
                        <strong>Biện pháp:</strong> {item.prevention}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 2. Common Psychological Issues */}
              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
                <h4 className="font-bold text-base text-stone-900 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-emerald-600" />
                  2. Các vấn đề tâm lý học sinh hay gặp (Dựa trên dữ liệu cuộc trò chuyện)
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  {state.latestAiAnalysis.commonIssues.map((issue, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/40 space-y-2"
                    >
                      <div className="flex items-center justify-between font-bold text-stone-900 text-sm">
                        <span>{issue.issue}</span>
                        <span className="text-emerald-700">{issue.percentage}%</span>
                      </div>
                      <p className="text-stone-600 leading-relaxed">
                        <strong>Bằng chứng từ trò chuyện:</strong> {issue.evidenceFromChats}
                      </p>
                      <div className="text-[11px] text-stone-500">
                        Đối tượng ảnh hưởng: <strong>{issue.affectedGroup}</strong>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 3. Depression Risk Warning */}
              <div className="bg-white p-6 rounded-2xl border border-red-200 shadow-xs space-y-4">
                <h4 className="font-bold text-base text-red-900 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                  3. Cảnh báo mức độ trầm cảm ở từng học sinh (Dữ liệu của GV Tư vấn)
                </h4>
                <p className="text-xs text-stone-600">
                  Danh sách học sinh có chỉ số lo âu, trầm cảm cao cần được phối hợp can thiệp khẩn cấp:
                </p>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-stone-700">
                    <thead className="bg-red-50 text-[11px] font-bold text-red-900 uppercase">
                      <tr>
                        <th className="px-3 py-2.5">Mã học sinh</th>
                        <th className="px-3 py-2.5">Lớp</th>
                        <th className="px-3 py-2.5">Mức độ cảnh báo</th>
                        <th className="px-3 py-2.5">Chỉ số nhận diện</th>
                        <th className="px-3 py-2.5">Đề xuất can thiệp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {state.latestAiAnalysis.depressionRiskStudents.map((student, idx) => (
                        <tr key={idx} className="hover:bg-red-50/30">
                          <td className="px-3 py-2.5 font-mono font-bold text-stone-900">
                            {student.studentCode}
                          </td>
                          <td className="px-3 py-2.5 font-semibold text-stone-700">{student.classId}</td>
                          <td className="px-3 py-2.5">
                            <span className="px-2 py-0.5 rounded-full font-bold text-[10px] bg-red-100 text-red-800">
                              {student.riskLevel}
                            </span>
                          </td>
                          <td className="px-3 py-2.5 text-stone-600">
                            {student.indicators.join(' • ')}
                          </td>
                          <td className="px-3 py-2.5 font-medium text-emerald-800">
                            {student.recommendedAction}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 4. Action Plan */}
              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-3">
                <h4 className="font-bold text-sm text-stone-900">
                  4. Kế hoạch Hành động Đề xuất cho Nhà trường
                </h4>
                <ul className="space-y-2 text-xs text-stone-700">
                  {state.latestAiAnalysis.actionPlan.map((act, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{act}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center text-stone-500 text-xs space-y-3">
              <Bot className="w-12 h-12 text-stone-300 mx-auto" />
              <p>Chưa có báo cáo phân tích nào. Hãy bấm "Yêu cầu AI phân tích ngay" ở trên để khởi chạy mô hình Gemini.</p>
            </div>
          )}
        </div>
      )}

      {/* TAB 7: ARTICLES & NEWS MANAGEMENT */}
      {activeTab === 'articles' && (
        <CounselorArticleManager />
      )}

      {/* Modal: Create Psychological Test */}
      {showCreateTestModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-stone-200 p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-bold text-base text-stone-900">Tạo & Tải lên Bài test Tâm lý theo Tháng</h3>
              <button
                type="button"
                onClick={() => setShowCreateTestModal(false)}
                className="text-stone-400 hover:text-stone-700 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Tháng khảo sát (YYYY-MM):</label>
                  <input
                    type="text"
                    value={newTestMonth}
                    onChange={(e) => setNewTestMonth(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Tên bài khảo sát:</label>
                  <input
                    type="text"
                    value={newTestTitle}
                    onChange={(e) => setNewTestTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Mô tả mục đích bài test:</label>
                <textarea
                  rows={2}
                  value={newTestDesc}
                  onChange={(e) => setNewTestDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300"
                />
              </div>

              <div className="border-t border-stone-100 pt-3">
                <h4 className="font-bold text-stone-900 mb-2">
                  Thang điểm đánh giá do Giáo viên tự thiết lập:
                </h4>
                <div className="space-y-2">
                  {scoreTiers.map((tier, idx) => (
                    <div key={tier.label} className="p-2.5 rounded-lg border border-stone-200 bg-stone-50 flex items-center gap-3">
                      <span className="font-bold w-36 text-stone-800">{tier.label}:</span>
                      <div className="flex items-center gap-1">
                        <span>Từ:</span>
                        <input
                          type="number"
                          value={tier.minScore}
                          onChange={(e) => {
                            const updated = [...scoreTiers];
                            updated[idx].minScore = Number(e.target.value);
                            setScoreTiers(updated);
                          }}
                          className="w-14 px-2 py-1 rounded border border-stone-300 bg-white"
                        />
                      </div>
                      <div className="flex items-center gap-1">
                        <span>Đến:</span>
                        <input
                          type="number"
                          value={tier.maxScore}
                          onChange={(e) => {
                            const updated = [...scoreTiers];
                            updated[idx].maxScore = Number(e.target.value);
                            setScoreTiers(updated);
                          }}
                          className="w-14 px-2 py-1 rounded border border-stone-300 bg-white"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-stone-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateTestModal(false)}
                  className="px-4 py-2 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="button"
                  onClick={handleSaveNewTest}
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                >
                  Lưu & Xuất bản bài test
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add Student Health Record */}
      {showAddStudentRecordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-stone-200 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-bold text-base text-stone-900">Thêm Học sinh vào Hồ sơ Sức khỏe</h3>
              <button
                type="button"
                onClick={() => setShowAddStudentRecordModal(false)}
                className="text-stone-400 hover:text-stone-700 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddStudentRecord} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Họ và Tên Học sinh:</label>
                <input
                  type="text"
                  required
                  value={newRecordStudentName}
                  onChange={(e) => setNewRecordStudentName(e.target.value)}
                  placeholder="Ví dụ: Hoàng Minh Tuấn"
                  className="w-full px-3 py-2 rounded-lg border border-stone-300"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Mã học sinh:</label>
                <input
                  type="text"
                  required
                  value={newRecordStudentCode}
                  onChange={(e) => setNewRecordStudentCode(e.target.value)}
                  placeholder="Ví dụ: VVK-10099"
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Lớp:</label>
                  <select
                    value={newRecordClassId}
                    onChange={(e) => setNewRecordClassId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 font-semibold"
                  >
                    {state.classes.map((cls) => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Khối:</label>
                  <select
                    value={newRecordGrade}
                    onChange={(e) => setNewRecordGrade(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300"
                  >
                    <option value={10}>Khối 10</option>
                    <option value={11}>Khối 11</option>
                    <option value={12}>Khối 12</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Đánh giá ban đầu:</label>
                <select
                  value={newRecordStatus}
                  onChange={(e) => setNewRecordStatus(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 font-semibold"
                >
                  <option value="Bình thường">Bình thường</option>
                  <option value="Cần lưu ý">Cần lưu ý</option>
                  <option value="Cần đặc biệt lưu ý">Cần đặc biệt lưu ý</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Ghi chú chuyên môn của GV Tư vấn:</label>
                <textarea
                  rows={2}
                  value={newRecordNotes}
                  onChange={(e) => setNewRecordNotes(e.target.value)}
                  placeholder="Ghi nhận biểu hiện hành vi, khó khăn cảm xúc..."
                  className="w-full px-3 py-2 rounded-lg border border-stone-300"
                />
              </div>

              <div className="pt-3 border-t border-stone-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddStudentRecordModal(false)}
                  className="px-4 py-2 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                >
                  Thêm vào hồ sơ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* AI Sentiment Analysis Detail Modal */}
      {sentimentModalData && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-stone-200 space-y-5 animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-700">
                    <Brain className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-stone-900">
                      Báo cáo Đánh giá Cảm xúc & Tâm lý AI
                    </h3>
                    <p className="text-xs text-stone-500">
                      Đối tượng: <span className="font-mono font-bold text-stone-800">{sentimentModalData.studentIdentifier}</span> • {sentimentModalData.timestamp}
                    </p>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSentimentModalData(null)}
                className="w-8 h-8 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-500 font-bold flex items-center justify-center text-sm"
              >
                ✕
              </button>
            </div>

            {/* Score and Emotional State Highlights */}
            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200 text-center">
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Xu hướng</span>
                <span className={`text-xs font-bold px-2 py-0.5 rounded-full inline-block mt-1 ${
                  sentimentModalData.sentiment === 'positive'
                    ? 'bg-emerald-100 text-emerald-800'
                    : sentimentModalData.sentiment === 'negative'
                    ? 'bg-rose-100 text-rose-800'
                    : 'bg-stone-200 text-stone-700'
                }`}>
                  {sentimentModalData.sentiment === 'positive' ? 'Tích cực' : sentimentModalData.sentiment === 'negative' ? 'Tiêu cực' : 'Trung tính'}
                </span>
              </div>

              <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200 text-center">
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Điểm cảm xúc</span>
                <span className="text-base font-extrabold text-stone-900 block mt-0.5">
                  {sentimentModalData.sentimentScore}/100
                </span>
              </div>

              <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200 text-center">
                <span className="text-[10px] font-bold uppercase text-stone-400 block">Mức độ khẩn cấp</span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full inline-block mt-1 ${
                  sentimentModalData.urgencyLevel === 'Báo động khẩn cấp'
                    ? 'bg-red-600 text-white animate-pulse'
                    : sentimentModalData.urgencyLevel === 'Cần chú ý'
                    ? 'bg-amber-500 text-white'
                    : 'bg-emerald-600 text-white'
                }`}>
                  {sentimentModalData.urgencyLevel}
                </span>
              </div>
            </div>

            {/* Summary */}
            <div className="space-y-1.5 bg-indigo-50/50 p-3.5 rounded-2xl border border-indigo-100">
              <span className="text-xs font-bold text-indigo-950 block">Trạng thái tâm lý chủ đạo:</span>
              <p className="text-xs text-indigo-900 font-semibold">{sentimentModalData.emotionalState}</p>
              <p className="text-xs text-stone-700 leading-relaxed pt-1">{sentimentModalData.summary}</p>
            </div>

            {/* Distress Signals */}
            {sentimentModalData.distressSignals && sentimentModalData.distressSignals.length > 0 && (
              <div className="space-y-2">
                <span className="text-xs font-bold text-rose-950 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-600" />
                  Dấu hiệu nguy cơ / Bất an phát hiện được:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {sentimentModalData.distressSignals.map((sig, i) => (
                    <span key={i} className="px-2.5 py-1 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold">
                      {sig}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Key Phrases */}
            {sentimentModalData.keyPhrases && sentimentModalData.keyPhrases.length > 0 && (
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-stone-700 block">Từ khóa & Cụm từ biểu đạt:</span>
                <div className="flex flex-wrap gap-1.5">
                  {sentimentModalData.keyPhrases.map((phrase, i) => (
                    <span key={i} className="px-2 py-0.5 rounded-md bg-stone-100 text-stone-700 text-xs">
                      "{phrase}"
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Recommendations */}
            <div className="space-y-2 bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200">
              <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-700" />
                Khuyến nghị can thiệp chuyên môn từ AI:
              </span>
              <ul className="space-y-1.5 text-xs text-emerald-900">
                {sentimentModalData.recommendations.map((rec, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setSentimentModalData(null)}
                className="px-5 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold"
              >
                Đóng báo cáo
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
