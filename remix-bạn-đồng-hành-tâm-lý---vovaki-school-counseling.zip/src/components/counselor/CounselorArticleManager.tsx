import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Article } from '../../types';
import {
  BookOpen,
  Plus,
  Edit,
  Trash2,
  Eye,
  Clock,
  User,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Upload,
  Search,
  Filter,
  ArrowRight,
  ExternalLink,
  X,
  HeartHandshake,
} from 'lucide-react';

const PRESET_IMAGES = [
  {
    label: 'Căng thẳng thi cử & Học tập',
    url: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Lắng nghe & Thấu hiểu cảm xúc',
    url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Tình bạn & Kết nối trường học',
    url: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Bình an & Chánh niệm Zen',
    url: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Khám phá & Phát triển bản thân',
    url: 'https://images.unsplash.com/photo-1517486808906-6ca8b3f04846?auto=format&fit=crop&w=1200&q=80',
  },
  {
    label: 'Gia đình & Thầy cô đồng hành',
    url: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80',
  },
];

const CATEGORIES = [
  'Tất cả',
  'Áp lực thi cử & Học tập',
  'Cảm xúc & Tâm lý lứa tuổi',
  'Mối quan hệ bạn bè & Xung đột',
  'Giao tiếp gia đình & Thầy cô',
  'Chăm sóc sức khỏe tinh thần',
  'Kỹ năng sống & Tự tin',
];

export const CounselorArticleManager: React.FC = () => {
  const { state, createArticle, updateArticle, deleteArticle, currentUser, setCurrentView } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Tất cả');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingArticleId, setEditingArticleId] = useState<string | null>(null);
  const [previewingArticle, setPreviewingArticle] = useState<Article | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState(currentUser?.fullName || 'ThS. Nguyễn Mai Phương (Tư vấn Tâm lý)');
  const [category, setCategory] = useState('Áp lực thi cử & Học tập');
  const [imageUrl, setImageUrl] = useState(PRESET_IMAGES[0].url);
  const [readTime, setReadTime] = useState('5 phút');
  const [excerpt, setExcerpt] = useState('');
  const [content, setContent] = useState('');
  const [modalTab, setModalTab] = useState<'form' | 'preview'>('form');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleOpenCreateModal = () => {
    setEditingArticleId(null);
    setTitle('');
    setAuthor(currentUser?.fullName || 'ThS. Nguyễn Mai Phương (Tư vấn Tâm lý)');
    setCategory('Áp lực thi cử & Học tập');
    setImageUrl(PRESET_IMAGES[Math.floor(Math.random() * PRESET_IMAGES.length)].url);
    setReadTime('5 phút');
    setExcerpt('');
    setContent('');
    setModalTab('form');
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (article: Article) => {
    setEditingArticleId(article.id);
    setTitle(article.title);
    setAuthor(article.author || 'Tổ Tư vấn Tâm lý');
    setCategory(article.category || 'Tâm lý học đường');
    setImageUrl(article.imageUrl || PRESET_IMAGES[0].url);
    setReadTime(article.readTime || '5 phút');
    setExcerpt(article.excerpt || '');
    setContent(article.content || '');
    setModalTab('form');
    setIsModalOpen(true);
  };

  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Vui lòng chọn tệp hình ảnh hợp lệ (PNG, JPG, WEBP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setImageUrl(reader.result);
        showToast('Đã tải ảnh lên thành công');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('Vui lòng nhập Tên bài viết.');
      return;
    }
    if (!content.trim()) {
      alert('Vui lòng nhập Nội dung bài viết.');
      return;
    }
    if (!author.trim()) {
      alert('Vui lòng nhập Tên người đăng bài.');
      return;
    }

    setIsSaving(true);
    const autoExcerpt = excerpt.trim() || content.trim().substring(0, 160) + '...';

    const articleData = {
      title: title.trim(),
      author: author.trim(),
      category: category.trim(),
      imageUrl: imageUrl.trim() || PRESET_IMAGES[0].url,
      readTime: readTime.trim() || '5 phút',
      excerpt: autoExcerpt,
      content: content.trim(),
    };

    if (editingArticleId) {
      const res = await updateArticle(editingArticleId, articleData);
      if (res.success) {
        showToast('Đã cập nhật bài viết thành công! Bài viết hiển thị ngay ở Trang chủ.');
        setIsModalOpen(false);
      } else {
        alert('Lỗi cập nhật bài viết: ' + res.error);
      }
    } else {
      const res = await createArticle(articleData);
      if (res.success) {
        showToast('Đã xuất bản bài viết thành công lên Trang chủ!');
        setIsModalOpen(false);
      } else {
        alert('Lỗi thêm bài viết: ' + res.error);
      }
    }
    setIsSaving(false);
  };

  const handleDeleteArticle = async (id: string, articleTitle: string) => {
    if (!window.confirm(`Bạn có chắc chắn muốn xóa bài viết "${articleTitle}" khỏi trang chủ?`)) {
      return;
    }
    const res = await deleteArticle(id);
    if (res.success) {
      showToast('Đã xóa bài viết khỏi Trang chủ');
    } else {
      alert('Lỗi khi xóa bài viết: ' + res.error);
    }
  };

  // Filter articles
  const filteredArticles = state.articles.filter((art) => {
    const matchSearch =
      art.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.author.toLowerCase().includes(searchQuery.toLowerCase());
    const matchCategory =
      selectedCategory === 'Tất cả' || art.category === selectedCategory;
    return matchSearch && matchCategory;
  });

  return (
    <div className="space-y-6">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-stone-700 text-xs sm:text-sm font-semibold flex items-center gap-2 animate-slide-up">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-100 text-emerald-700">
              <BookOpen className="w-5 h-5" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 font-mono">
              Quản lý Cẩm nang & Tin tức
            </span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight">
            Cập Nhật Bài Viết & Tin Tức Trang Chủ
          </h3>
          <p className="text-xs sm:text-sm text-stone-600 max-w-2xl leading-relaxed">
            GV Tư vấn tâm lý có toàn quyền biên soạn, đăng tải và chỉnh sửa các bài viết tâm lý học đường. 
            Mọi cập nhật sẽ ngay lập tức được hiển thị trực tiếp trên Trang chủ cho học sinh, phụ huynh và toàn bộ cộng đồng trường học.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={handleOpenCreateModal}
            className="px-5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Viết Bài Mới (Đăng lên Trang chủ)</span>
          </button>
        </div>
      </div>

      {/* Search & Category Filter Bar */}
      <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2 flex-1 min-w-[240px] max-w-md bg-stone-50 px-3 py-2 rounded-xl border border-stone-200">
          <Search className="w-4 h-4 text-stone-400 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm kiếm theo tiêu đề, tác giả hoặc nội dung..."
            className="w-full bg-transparent text-xs sm:text-sm text-stone-800 placeholder-stone-400 outline-hidden font-medium"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="text-stone-400 hover:text-stone-600 text-xs font-bold"
            >
              ✕
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 max-w-full">
          <Filter className="w-3.5 h-3.5 text-stone-400 shrink-0 hidden sm:block" />
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-stone-100 hover:bg-stone-200 text-stone-600'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Articles Grid */}
      {filteredArticles.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-dashed border-stone-300 space-y-4">
          <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
            <BookOpen className="w-8 h-8" />
          </div>
          <h4 className="text-base font-bold text-stone-800">Không tìm thấy bài viết nào</h4>
          <p className="text-xs text-stone-500 max-w-sm mx-auto">
            {searchQuery || selectedCategory !== 'Tất cả'
              ? 'Không có bài viết phù hợp với bộ lọc tìm kiếm. Vui lòng thử từ khóa khác.'
              : 'Chưa có bài viết nào được đăng. Hãy tạo bài viết đầu tiên để học sinh trên trang chủ có thể theo dõi.'}
          </p>
          <button
            type="button"
            onClick={handleOpenCreateModal}
            className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Viết bài ngay</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.map((article) => (
            <div
              key={article.id}
              className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col group"
            >
              {/* Card Image */}
              <div className="relative h-48 overflow-hidden bg-stone-100">
                <img
                  src={article.imageUrl}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <span className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-xs text-white text-[11px] font-bold px-2.5 py-1 rounded-lg">
                  {article.category}
                </span>
                <span className="absolute bottom-3 right-3 bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Hiển thị Trang chủ</span>
                </span>
              </div>

              {/* Card Content */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-stone-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {article.readTime}
                    </span>
                    <span>{article.date}</span>
                  </div>

                  <h4 className="font-bold text-base text-stone-900 group-hover:text-emerald-700 transition-colors line-clamp-2 leading-snug">
                    {article.title}
                  </h4>

                  <div className="flex items-center gap-1.5 text-xs font-semibold text-stone-600">
                    <User className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span className="truncate">{article.author}</span>
                  </div>

                  <p className="text-xs text-stone-500 line-clamp-3 leading-relaxed pt-1">
                    {article.excerpt}
                  </p>
                </div>

                {/* Card Action Buttons */}
                <div className="pt-3 border-t border-stone-100 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => setPreviewingArticle(article)}
                    className="p-2 rounded-xl text-stone-600 hover:text-emerald-700 hover:bg-emerald-50 text-xs font-bold flex items-center gap-1 transition-colors"
                    title="Xem chi tiết cách bài viết hiển thị trên trang chủ"
                  >
                    <Eye className="w-4 h-4" />
                    <span>Xem thử</span>
                  </button>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleOpenEditModal(article)}
                      className="p-2 rounded-xl text-stone-600 hover:text-emerald-700 hover:bg-emerald-50 text-xs font-bold transition-colors"
                      title="Chỉnh sửa bài viết"
                    >
                      <Edit className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDeleteArticle(article.id, article.title)}
                      className="p-2 rounded-xl text-stone-400 hover:text-red-600 hover:bg-red-50 text-xs font-bold transition-colors"
                      title="Xóa bài viết"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ================= MODAL: CREATE / EDIT ARTICLE ================= */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto animate-fade-in">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden shadow-2xl border border-stone-200">
            {/* Modal Header */}
            <div className="p-5 sm:p-6 border-b border-stone-100 flex items-center justify-between bg-stone-50">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-emerald-100 text-emerald-700">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-stone-900">
                    {editingArticleId ? 'Chỉnh Sửa Bài Viết Trang Chủ' : 'Viết Bài Mới Cho Trang Chủ'}
                  </h3>
                  <p className="text-xs text-stone-500">
                    Thông tin sẽ cập nhật trực tiếp lên hệ thống và lưu trữ an toàn trên máy chủ
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Form / Preview toggle */}
                <div className="bg-stone-200 p-1 rounded-xl flex items-center text-xs font-bold">
                  <button
                    type="button"
                    onClick={() => setModalTab('form')}
                    className={`px-3 py-1 rounded-lg transition-all ${
                      modalTab === 'form' ? 'bg-white text-emerald-700 shadow-xs' : 'text-stone-600'
                    }`}
                  >
                    Soạn thảo
                  </button>
                  <button
                    type="button"
                    onClick={() => setModalTab('preview')}
                    className={`px-3 py-1 rounded-lg transition-all ${
                      modalTab === 'preview' ? 'bg-white text-emerald-700 shadow-xs' : 'text-stone-600'
                    }`}
                  >
                    Xem trước
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-200 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto flex-1 space-y-5">
              {modalTab === 'form' ? (
                <form onSubmit={handleSaveArticle} id="articleForm" className="space-y-4">
                  {/* 1. Tên bài viết */}
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Tên bài viết (Tiêu đề) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Ví dụ: 5 Kỹ thuật thở giúp học sinh giải tỏa lo âu trước giờ thi vào 10"
                      className="w-full px-4 py-2.5 rounded-xl border border-stone-300 text-xs sm:text-sm font-semibold focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>

                  {/* 2. Tác giả & Chuyên mục & Thời gian đọc */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-stone-700 mb-1">
                        Tên người đăng bài (Tác giả) <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={author}
                        onChange={(e) => setAuthor(e.target.value)}
                        placeholder="ThS. Nguyễn Mai Phương"
                        className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs font-medium focus:ring-2 focus:ring-emerald-500 outline-hidden"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-stone-700 mb-1">
                        Chuyên mục bài viết
                      </label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs font-semibold focus:ring-2 focus:ring-emerald-500 outline-hidden bg-white"
                      >
                        {CATEGORIES.filter((c) => c !== 'Tất cả').map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-stone-700 mb-1">
                        Thời gian đọc ước tính
                      </label>
                      <input
                        type="text"
                        value={readTime}
                        onChange={(e) => setReadTime(e.target.value)}
                        placeholder="5 phút"
                        className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs font-medium focus:ring-2 focus:ring-emerald-500 outline-hidden"
                      />
                    </div>
                  </div>

                  {/* 3. Hình ảnh bài viết */}
                  <div className="space-y-2 p-4 rounded-2xl bg-stone-50 border border-stone-200">
                    <label className="block text-xs font-bold text-stone-700">
                      Hình ảnh đại diện bài viết <span className="text-red-500">*</span>
                    </label>

                    <div className="flex flex-wrap items-center gap-3">
                      <div className="w-24 h-16 rounded-xl overflow-hidden bg-stone-200 border border-stone-300 shrink-0">
                        <img
                          src={imageUrl || PRESET_IMAGES[0].url}
                          alt="Preview"
                          className="w-full h-full object-cover"
                        />
                      </div>

                      <div className="flex-1 min-w-[200px] space-y-1.5">
                        <input
                          type="text"
                          value={imageUrl}
                          onChange={(e) => setImageUrl(e.target.value)}
                          placeholder="Dán đường link ảnh (URL)..."
                          className="w-full px-3 py-1.5 rounded-xl border border-stone-300 text-xs font-mono bg-white"
                        />
                        <div className="flex items-center gap-2">
                          <label className="px-3 py-1.5 rounded-xl bg-white border border-stone-300 hover:bg-stone-100 text-[11px] font-bold text-stone-700 cursor-pointer inline-flex items-center gap-1 shadow-2xs">
                            <Upload className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Tải ảnh từ máy tính</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={handleImageFileUpload}
                            />
                          </label>
                          <span className="text-[10px] text-stone-400">hoặc chọn mẫu dưới</span>
                        </div>
                      </div>
                    </div>

                    {/* Presets Gallery */}
                    <div className="pt-2">
                      <span className="text-[10px] font-bold text-stone-500 uppercase tracking-wider block mb-1.5">
                        Kho ảnh mẫu tâm lý học đường:
                      </span>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                        {PRESET_IMAGES.map((preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setImageUrl(preset.url)}
                            className={`p-1 rounded-xl border text-left flex items-center gap-2 transition-all ${
                              imageUrl === preset.url
                                ? 'border-emerald-600 bg-emerald-50 ring-2 ring-emerald-300'
                                : 'border-stone-200 hover:border-stone-300 bg-white'
                            }`}
                          >
                            <img
                              src={preset.url}
                              alt={preset.label}
                              className="w-10 h-8 rounded-lg object-cover"
                            />
                            <span className="text-[10px] font-semibold text-stone-700 truncate">
                              {preset.label}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* 4. Tóm tắt ngắn (Excerpt) */}
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Tóm tắt ngắn (Hiển thị ngoài danh mục Trang chủ)
                    </label>
                    <textarea
                      rows={2}
                      value={excerpt}
                      onChange={(e) => setExcerpt(e.target.value)}
                      placeholder="1-2 câu tóm tắt nội dung chính để học sinh dễ nắm bắt thông điệp..."
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs font-medium focus:ring-2 focus:ring-emerald-500 outline-hidden leading-relaxed"
                    />
                  </div>

                  {/* 5. Nội dung bài viết */}
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Nội dung bài viết chi tiết <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      rows={9}
                      required
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      placeholder="Viết nội dung bài viết cẩm nang tại đây... Bạn có thể chia thành nhiều đoạn, gạch đầu dòng các bài tập thực hành hoặc lời khuyên tâm lý..."
                      className="w-full px-4 py-3 rounded-2xl border border-stone-300 text-xs sm:text-sm font-medium focus:ring-2 focus:ring-emerald-500 outline-hidden leading-relaxed"
                    />
                  </div>
                </form>
              ) : (
                /* LIVE PREVIEW IN MODAL */
                <div className="space-y-6">
                  <div className="relative h-64 rounded-3xl overflow-hidden bg-stone-900 shadow-md">
                    <img
                      src={imageUrl || PRESET_IMAGES[0].url}
                      alt={title || 'Tiêu đề'}
                      className="w-full h-full object-cover opacity-85"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent" />
                    <div className="absolute bottom-6 left-6 right-6 text-white space-y-2">
                      <span className="px-3 py-1 rounded-md bg-emerald-600 text-xs font-bold inline-block">
                        {category}
                      </span>
                      <h2 className="text-xl sm:text-2xl font-extrabold leading-snug">
                        {title || 'Tiêu đề bài viết chưa nhập'}
                      </h2>
                      <div className="flex items-center gap-3 text-xs text-stone-300">
                        <span className="flex items-center gap-1 font-medium">
                          <User className="w-3.5 h-3.5" />
                          {author || 'Người đăng bài'}
                        </span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {readTime || '5 phút'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {excerpt && (
                    <div className="p-4 rounded-2xl bg-emerald-50 border-l-4 border-emerald-600 text-xs sm:text-sm font-medium text-emerald-950 leading-relaxed italic">
                      "{excerpt}"
                    </div>
                  )}

                  <div className="text-xs sm:text-sm text-stone-700 leading-relaxed whitespace-pre-line space-y-3">
                    {content || (
                      <p className="text-stone-400 italic">
                        Chưa có nội dung bài viết. Hãy chuyển về tab 'Soạn thảo' để nhập nội dung.
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-5 border-t border-stone-100 flex items-center justify-between bg-stone-50">
              <span className="text-xs text-stone-500">
                {editingArticleId ? 'Đang cập nhật bài viết' : 'Bài viết mới sẽ được ghim lên đầu Trang chủ'}
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-200 text-xs font-bold transition-colors"
                >
                  Hủy bỏ
                </button>

                <button
                  type="submit"
                  form="articleForm"
                  disabled={isSaving}
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isSaving ? 'Đang lưu...' : 'Lưu & Xuất bản Lên Trang Chủ'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: ARTICLE READER PREVIEW ================= */}
      {previewingArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white rounded-3xl max-w-3xl w-full max-h-[88vh] flex flex-col overflow-hidden shadow-2xl border border-stone-200">
            <div className="relative h-64 shrink-0 bg-stone-900">
              <img
                src={previewingArticle.imageUrl}
                alt={previewingArticle.title}
                className="w-full h-full object-cover opacity-80"
              />
              <button
                type="button"
                onClick={() => setPreviewingArticle(null)}
                className="absolute top-4 right-4 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute bottom-6 left-6 right-6 text-white space-y-2">
                <span className="px-3 py-1 rounded-md bg-emerald-600 text-xs font-bold inline-block">
                  {previewingArticle.category}
                </span>
                <h2 className="text-xl sm:text-2xl font-extrabold leading-snug">
                  {previewingArticle.title}
                </h2>
                <div className="flex items-center gap-3 text-xs text-stone-300">
                  <span className="flex items-center gap-1 font-semibold">
                    <User className="w-3.5 h-3.5" />
                    {previewingArticle.author}
                  </span>
                  <span>•</span>
                  <span>{previewingArticle.date}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    {previewingArticle.readTime}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-6 sm:p-8 overflow-y-auto space-y-4 text-xs sm:text-sm text-stone-700 leading-relaxed">
              {previewingArticle.excerpt && (
                <div className="p-4 rounded-2xl bg-emerald-50 border-l-4 border-emerald-600 text-emerald-950 font-medium italic">
                  "{previewingArticle.excerpt}"
                </div>
              )}

              <div className="whitespace-pre-line space-y-4">
                {previewingArticle.content}
              </div>

              <div className="pt-6 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
                <div className="flex items-center gap-1.5 text-emerald-700 font-bold">
                  <HeartHandshake className="w-4 h-4" />
                  <span>Phòng Tư vấn Tâm lý Học đường VoVaKi</span>
                </div>
                <button
                  type="button"
                  onClick={() => setPreviewingArticle(null)}
                  className="px-4 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-bold"
                >
                  Đóng cửa sổ
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
