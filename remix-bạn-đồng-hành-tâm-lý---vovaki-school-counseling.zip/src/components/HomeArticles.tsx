import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Article } from '../types';
import { BookOpen, Clock, User, ArrowRight, X, ShieldAlert, Sparkles, LogIn } from 'lucide-react';

export const HomeArticles: React.FC<{ onOpenLogin: () => void }> = ({ onOpenLogin }) => {
  const { state, currentUser, setCurrentView } = useApp();
  const [readingArticle, setReadingArticle] = useState<Article | null>(null);

  return (
    <div className="space-y-10 pb-16">
      {/* Hero Banner Section */}
      <section className="relative overflow-hidden rounded-3xl bg-stone-900 text-white shadow-xl">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-30 mix-blend-luminosity"
          style={{
            backgroundImage: `url(${state.siteSettings.bannerUrl || 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1600&q=80'})`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-stone-950 via-stone-900/80 to-transparent" />

        <div className="relative max-w-4xl px-6 sm:px-10 py-12 sm:py-16 space-y-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Phòng Tư vấn Tâm lý Học đường VoVaKi</span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
            {state.siteSettings.siteName}
          </h2>

          <p className="text-stone-300 text-sm sm:text-base leading-relaxed max-w-2xl">
            Không gian an toàn, tôn trọng và bảo mật tuyệt đối dành cho mọi học sinh, giáo viên và phụ huynh. Nơi bạn được lắng nghe mà không hề bị phán xét.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            {!currentUser ? (
              <button
                type="button"
                onClick={onOpenLogin}
                className="px-6 py-3 rounded-xl font-bold text-sm text-white shadow-lg transition-transform active:scale-95 flex items-center gap-2"
                style={{ backgroundColor: state.siteSettings.primaryColor }}
              >
                <LogIn className="w-4 h-4" />
                <span>Đăng nhập để sử dụng các chức năng</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setCurrentView('dashboard')}
                className="px-6 py-3 rounded-xl font-bold text-sm text-white shadow-lg transition-transform active:scale-95 flex items-center gap-2"
                style={{ backgroundColor: state.siteSettings.primaryColor }}
              >
                <User className="w-4 h-4" />
                <span>Vào khu vực làm việc ({currentUser.fullName})</span>
              </button>
            )}

            <span className="text-xs text-stone-400 px-2 py-1 bg-black/40 rounded-lg border border-stone-700/60">
              * Yêu cầu đăng nhập để truy cập chức năng theo vai trò
            </span>
          </div>
        </div>
      </section>

      {/* Main Articles Listing */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold text-stone-900 tracking-tight flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-emerald-600" />
              Chuyên mục Bài viết Tâm lý Học đường
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Những bài viết chuyên sâu từ Tổ Tư vấn Tâm lý giúp học sinh thấu hiểu cảm xúc và vượt qua căng thẳng
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {state.articles.map((article) => (
            <article
              key={article.id}
              className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col group cursor-pointer"
              onClick={() => setReadingArticle(article)}
            >
              <div className="relative h-48 overflow-hidden bg-stone-100">
                <img
                  src={article.imageUrl}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <span className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-xs text-white text-[11px] font-semibold px-2.5 py-1 rounded-md">
                  {article.category}
                </span>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-3 text-xs text-stone-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {article.readTime}
                    </span>
                    <span>•</span>
                    <span>{article.date}</span>
                  </div>

                  <h4 className="font-bold text-base text-stone-900 group-hover:text-emerald-700 transition-colors leading-snug line-clamp-2">
                    {article.title}
                  </h4>

                  <p className="text-xs text-stone-600 leading-relaxed line-clamp-3">
                    {article.excerpt}
                  </p>
                </div>

                <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs">
                  <span className="text-stone-500 font-medium truncate max-w-[170px]">
                    {article.author}
                  </span>
                  <span
                    className="font-semibold flex items-center gap-1 group-hover:translate-x-1 transition-transform"
                    style={{ color: state.siteSettings.primaryColor }}
                  >
                    Đọc tiếp <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Login Prompt Box if not authenticated */}
      {!currentUser && (
        <section className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-left">
            <h4 className="font-bold text-base text-stone-900">
              Bạn cần hỗ trợ tư vấn tâm lý hoặc thực hiện bài kiểm tra định kỳ?
            </h4>
            <p className="text-xs text-stone-600">
              Vui lòng bấm nút <strong>Đăng nhập</strong> phía trên để truy cập chức năng đặt lịch ẩn danh, tham gia Phòng tích cực Vovakier hoặc quản lý hồ sơ sức khỏe.
            </p>
          </div>
          <button
            type="button"
            onClick={onOpenLogin}
            className="px-5 py-2.5 rounded-xl font-bold text-xs text-white shadow-xs hover:brightness-105 shrink-0"
            style={{ backgroundColor: state.siteSettings.primaryColor }}
          >
            Đăng nhập ngay
          </button>
        </section>
      )}

      {/* Article Detail Modal */}
      {readingArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-stone-200 overflow-hidden max-h-[90vh] flex flex-col">
            <div className="relative h-56 bg-stone-900 shrink-0">
              <img
                src={readingArticle.imageUrl}
                alt={readingArticle.title}
                className="w-full h-full object-cover opacity-80"
              />
              <button
                type="button"
                onClick={() => setReadingArticle(null)}
                className="absolute top-3 right-3 p-1.5 rounded-full bg-black/60 text-white hover:bg-black/80"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute bottom-3 left-4 right-4">
                <span className="text-[11px] font-semibold bg-emerald-600 text-white px-2.5 py-0.5 rounded">
                  {readingArticle.category}
                </span>
                <h3 className="text-lg sm:text-xl font-bold text-white mt-1.5 leading-snug drop-shadow-sm">
                  {readingArticle.title}
                </h3>
              </div>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-sm text-stone-700 leading-relaxed">
              <div className="flex items-center justify-between text-xs text-stone-500 pb-3 border-b border-stone-100">
                <span>Tác giả: <strong>{readingArticle.author}</strong></span>
                <span>Ngày đăng: {readingArticle.date} • {readingArticle.readTime}</span>
              </div>

              <div className="whitespace-pre-line text-xs sm:text-sm text-stone-800 space-y-3 font-normal leading-relaxed">
                {readingArticle.content}
              </div>
            </div>

            <div className="p-4 border-t border-stone-200 bg-stone-50 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setReadingArticle(null)}
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-stone-200 hover:bg-stone-300 text-stone-800"
              >
                Đóng bài viết
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
