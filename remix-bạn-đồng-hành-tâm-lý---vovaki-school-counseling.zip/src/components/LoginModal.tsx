import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';
import { X, ShieldCheck, HeartHandshake, GraduationCap, Sparkles, KeyRound } from 'lucide-react';

export const LoginModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { state, setCurrentUser, setCurrentView, loginWithCredentials } = useApp();
  const [activeTab, setActiveTab] = useState<'quick' | 'form'>('quick');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleQuickLogin = (role: UserRole, specificUsername?: string) => {
    setErrorMsg('');
    const user = state.users.find((u) => {
      if (specificUsername) return u.username === specificUsername;
      return u.role === role;
    });

    if (user) {
      if (user.isActive === false) {
        setErrorMsg(`Tài khoản "${user.username}" đang bị Quản trị viên khóa. Vui lòng liên hệ nhà trường.`);
        return;
      }
      setCurrentUser(user);
      setCurrentView('dashboard');
      onClose();
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setIsSubmitting(true);

    try {
      const res = await loginWithCredentials(username, password);
      if (res.success && res.user) {
        setCurrentView('dashboard');
        onClose();
      } else {
        setErrorMsg(res.error || 'Tên đăng nhập hoặc mật khẩu không chính xác.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Lỗi mạng khi đăng nhập');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-stone-900 text-white flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base">Đăng nhập vào Hệ thống</h3>
            <p className="text-xs text-stone-400 mt-0.5">
              Chọn vai trò hoặc đăng nhập bằng tài khoản được cấp
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-stone-800 text-stone-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab selector */}
        <div className="flex border-b border-stone-200 bg-stone-50 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('quick')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors ${
              activeTab === 'quick'
                ? 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Đăng nhập nhanh (Thử nghiệm 4 vai trò)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('form')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors ${
              activeTab === 'form'
                ? 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Tài khoản cá nhân
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {activeTab === 'quick' ? (
            <div className="space-y-3">
              <p className="text-xs text-stone-600">
                Hệ thống hỗ trợ 4 nhóm phân quyền chính theo yêu cầu nhà trường. Hãy chọn một tài khoản mẫu để trải nghiệm giao diện tương ứng:
              </p>

              {/* 1. Admin */}
              <div
                onClick={() => handleQuickLogin('admin')}
                className="p-3.5 rounded-xl border border-purple-200 bg-purple-50/50 hover:bg-purple-100/70 hover:border-purple-300 transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-purple-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-stone-900 group-hover:text-purple-900">
                      1. Quản trị viên (Admin)
                    </h4>
                    <p className="text-xs text-stone-600">
                      Cấp tài khoản, phân quyền, đổi giao diện/theme, trích xuất dữ liệu, cấu hình web
                    </p>
                  </div>
                </div>
                <span className="text-xs font-semibold text-purple-700 bg-purple-100 px-2.5 py-1 rounded-md">
                  Vào vai
                </span>
              </div>

              {/* 2. Counselor */}
              <div
                onClick={() => handleQuickLogin('counselor')}
                className="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/50 hover:bg-emerald-100/70 hover:border-emerald-300 transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                    <HeartHandshake className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-stone-900 group-hover:text-emerald-900">
                      2. Giáo viên Tư vấn Tâm lý
                    </h4>
                    <p className="text-xs text-stone-600">
                      Nhận đặt lịch ảo, tư vấn khẩn cấp, giám sát Phòng tích cực Vovakier, bài test & hồ sơ sức khỏe
                    </p>
                  </div>
                </div>
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-md">
                  Vào vai
                </span>
              </div>

              {/* 3. Homeroom Teacher */}
              <div
                onClick={() => handleQuickLogin('homeroom', 'gv_chunhiem10')}
                className="p-3.5 rounded-xl border border-blue-200 bg-blue-50/50 hover:bg-blue-100/70 hover:border-blue-300 transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                    <GraduationCap className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-stone-900 group-hover:text-blue-900">
                      3. Giáo viên Chủ nhiệm (Thầy Bảo - 10A1)
                    </h4>
                    <p className="text-xs text-stone-600">
                      Xem hồ sơ sức khỏe tâm lý lớp khi được mở khóa, ghi chú theo dõi học sinh
                    </p>
                  </div>
                </div>
                <span className="text-xs font-semibold text-blue-700 bg-blue-100 px-2.5 py-1 rounded-md">
                  Vào vai
                </span>
              </div>

              {/* 4. Student */}
              <div
                onClick={() => handleQuickLogin('student', 'hs_nam')}
                className="p-3.5 rounded-xl border border-amber-200 bg-amber-50/50 hover:bg-amber-100/70 hover:border-amber-300 transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-stone-900 group-hover:text-amber-900">
                      4. Học sinh (Nguyễn Hoài Nam - 10A1)
                    </h4>
                    <p className="text-xs text-stone-600">
                      Đặt lịch ẩn danh, tư vấn khẩn cấp, làm bài test tâm lý, trò chuyện giọng nói AI Vovakier
                    </p>
                  </div>
                </div>
                <span className="text-xs font-semibold text-amber-700 bg-amber-100 px-2.5 py-1 rounded-md">
                  Vào vai
                </span>
              </div>
            </div>
          ) : (
            <form onSubmit={handleFormSubmit} className="space-y-4">
              {errorMsg && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-red-700 text-xs">
                  {errorMsg}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Tên tài khoản hoặc Mã số học sinh:
                </label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => {
                    setUsername(e.target.value);
                    setErrorMsg('');
                  }}
                  placeholder="Ví dụ: admin, gv_tuvan, gv_chunhiem10, hs_nam..."
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Mật khẩu:
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Nhập mật khẩu (hoặc để trống ở bản demo)"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm transition-all shadow-xs flex items-center justify-center gap-2"
                >
                  <KeyRound className="w-4 h-4" />
                  Xác nhận đăng nhập
                </button>
              </div>

              <div className="p-3 bg-stone-50 rounded-lg text-xs text-stone-500 space-y-1">
                <p className="font-semibold text-stone-700">Tài khoản demo có sẵn:</p>
                <p>• Admin: <code>admin</code></p>
                <p>• GV Tư vấn: <code>gv_tuvan</code></p>
                <p>• GV Chủ nhiệm: <code>gv_chunhiem10</code> hoặc <code>gv_chunhiem11</code></p>
                <p>• Học sinh: <code>hs_nam</code>, <code>hs_linh</code>, <code>hs_an</code></p>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
