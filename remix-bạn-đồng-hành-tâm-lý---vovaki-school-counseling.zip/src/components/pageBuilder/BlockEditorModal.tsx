import React, { useState } from 'react';
import { PageBlock, BlockType } from '../../types/pageBuilder';
import { X, Check, Trash2, Eye, EyeOff, Sparkles, Image, Type, Layout, Grid } from 'lucide-react';

interface BlockEditorModalProps {
  block: PageBlock;
  onSave: (updatedBlock: PageBlock) => void;
  onClose: () => void;
  onDelete?: (blockId: string) => void;
}

export const BlockEditorModal: React.FC<BlockEditorModalProps> = ({
  block,
  onSave,
  onClose,
  onDelete,
}) => {
  const [formData, setFormData] = useState<PageBlock>(JSON.parse(JSON.stringify(block)));
  const [activeTab, setActiveTab] = useState<'content' | 'style' | 'advanced'>('content');

  const handleChangeType = (newType: BlockType) => {
    setFormData((prev) => ({
      ...prev,
      type: newType,
    }));
  };

  const handleContentChange = (field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      content: {
        ...prev.content,
        [field]: value,
      },
    }));
  };

  const handleStyleChange = (field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      style: {
        ...prev.style,
        [field]: value,
      },
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl border border-stone-200">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-purple-100 text-purple-700 font-bold text-xs">
              Block Editor
            </span>
            <div>
              <h3 className="font-bold text-stone-900 text-base">
                Chỉnh sửa Khối ({formData.type})
              </h3>
              <p className="text-xs text-stone-500 font-mono">ID: {formData.id}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-stone-200 text-stone-400 hover:text-stone-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 border-b border-stone-200 flex items-center gap-4 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('content')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'content'
                ? 'border-purple-600 text-purple-700'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Nội dung khối (Content)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('style')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'style'
                ? 'border-purple-600 text-purple-700'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Giao diện & Màu sắc (Style)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('advanced')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'advanced'
                ? 'border-purple-600 text-purple-700'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Loại khối & Nâng cao
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm">
          {activeTab === 'content' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Tiêu đề / Nội dung chính
                </label>
                <input
                  type="text"
                  value={formData.content.text || ''}
                  onChange={(e) => handleContentChange('text', e.target.value)}
                  placeholder="Nhập tiêu đề hoặc nội dung chính..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-purple-500 outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Mô tả phụ / Đoạn văn (Subtext / Paragraph)
                </label>
                <textarea
                  rows={3}
                  value={formData.content.subText || ''}
                  onChange={(e) => handleContentChange('subText', e.target.value)}
                  placeholder="Nhập đoạn mô tả phụ chi tiết..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-purple-500 outline-hidden"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Nhãn huy hiệu (Badge)
                  </label>
                  <input
                    type="text"
                    value={formData.content.badge || ''}
                    onChange={(e) => handleContentChange('badge', e.target.value)}
                    placeholder="VD: Mới nhất, Hỗ trợ 24/7..."
                    className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-purple-500 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Căn lề (Alignment)
                  </label>
                  <select
                    value={formData.content.alignment || 'left'}
                    onChange={(e) => handleContentChange('alignment', e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-purple-500 outline-hidden"
                  >
                    <option value="left">Căn trái (Left)</option>
                    <option value="center">Căn giữa (Center)</option>
                    <option value="right">Căn phải (Right)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  URL Hình ảnh (Image URL)
                </label>
                <input
                  type="text"
                  value={formData.content.imageUrl || ''}
                  onChange={(e) => handleContentChange('imageUrl', e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-purple-500 outline-hidden"
                />
              </div>

              {/* Action Button Settings */}
              <div className="pt-3 border-t border-stone-100 grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Chữ trên nút (Button Text)
                  </label>
                  <input
                    type="text"
                    value={formData.content.buttonText || ''}
                    onChange={(e) => handleContentChange('buttonText', e.target.value)}
                    placeholder="VD: Xem ngay, Bắt đầu..."
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-purple-500 outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Liên kết / Hành động
                  </label>
                  <select
                    value={formData.content.buttonLink || ''}
                    onChange={(e) => handleContentChange('buttonLink', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-purple-500 outline-hidden"
                  >
                    <option value="">-- Không có liên kết --</option>
                    <option value="positive_room">Phòng Tích Cực AI</option>
                    <option value="emergency">SOS Khẩn cấp</option>
                    <option value="tests">Trắc nghiệm Tâm lý</option>
                    <option value="counseling">Đặt lịch tham vấn</option>
                    <option value="home">Về Trang chủ</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Kiểu nút (Variant)
                  </label>
                  <select
                    value={formData.content.buttonVariant || 'primary'}
                    onChange={(e) => handleContentChange('buttonVariant', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-purple-500 outline-hidden"
                  >
                    <option value="primary">Màu thương hiệu (Primary)</option>
                    <option value="secondary">Xanh dương (Secondary)</option>
                    <option value="amber">Vàng cam (Amber)</option>
                    <option value="danger">Đỏ khẩn cấp (Danger)</option>
                    <option value="outline">Đường viền (Outline)</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'style' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Màu nền khối (Background Color)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={formData.style.backgroundColor || '#ffffff'}
                      onChange={(e) => handleStyleChange('backgroundColor', e.target.value)}
                      className="w-9 h-9 rounded-lg border cursor-pointer"
                    />
                    <input
                      type="text"
                      value={formData.style.backgroundColor || ''}
                      onChange={(e) => handleStyleChange('backgroundColor', e.target.value)}
                      placeholder="#ffffff hoặc transparent"
                      className="flex-1 px-3 py-1.5 rounded-xl border border-stone-300 text-xs font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Màu chữ (Text Color)
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={formData.style.textColor || '#1c1917'}
                      onChange={(e) => handleStyleChange('textColor', e.target.value)}
                      className="w-9 h-9 rounded-lg border cursor-pointer"
                    />
                    <input
                      type="text"
                      value={formData.style.textColor || ''}
                      onChange={(e) => handleStyleChange('textColor', e.target.value)}
                      placeholder="#1c1917"
                      className="flex-1 px-3 py-1.5 rounded-xl border border-stone-300 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Kích cỡ chữ (Font Size)
                  </label>
                  <select
                    value={formData.style.fontSize || 'base'}
                    onChange={(e) => handleStyleChange('fontSize', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs"
                  >
                    <option value="xs">Rất nhỏ (xs)</option>
                    <option value="sm">Nhỏ (sm)</option>
                    <option value="base">Tiêu chuẩn (base)</option>
                    <option value="lg">Lớn (lg)</option>
                    <option value="xl">Rất lớn (xl)</option>
                    <option value="2xl">Tiêu đề 2XL</option>
                    <option value="3xl">Tiêu đề 3XL</option>
                    <option value="4xl">Tiêu đề 4XL</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Độ bo góc (Border Radius)
                  </label>
                  <select
                    value={formData.style.borderRadius || 'xl'}
                    onChange={(e) => handleStyleChange('borderRadius', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs"
                  >
                    <option value="none">Vuông (none)</option>
                    <option value="sm">Bo nhẹ (sm)</option>
                    <option value="md">Trung bình (md)</option>
                    <option value="xl">Bo tròn lớn (xl)</option>
                    <option value="2xl">Bo tròn 2XL</option>
                    <option value="full">Hình viên thuốc (full)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Đổ bóng (Shadow)
                  </label>
                  <select
                    value={formData.style.shadow || 'xs'}
                    onChange={(e) => handleStyleChange('shadow', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs"
                  >
                    <option value="none">Không đổ bóng</option>
                    <option value="xs">Bóng mờ nhẹ (xs)</option>
                    <option value="md">Bóng trung bình (md)</option>
                    <option value="xl">Bóng đậm nổi bật (xl)</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'advanced' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Đổi kiểu khối chức năng (Block Type)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { type: 'heading', label: 'Tiêu đề (Heading)' },
                    { type: 'paragraph', label: 'Đoạn văn (Paragraph)' },
                    { type: 'banner', label: 'Banner nổi bật' },
                    { type: 'card', label: 'Thẻ nội dung (Card)' },
                    { type: 'image', label: 'Hình ảnh đơn' },
                    { type: 'button', label: 'Nút bấm kêu gọi' },
                    { type: 'articles_module', label: 'Mô đun Bài viết' },
                    { type: 'emergency_module', label: 'Mô đun SOS' },
                    { type: 'hotline_module', label: 'Mô đun Hotline' },
                  ].map((item) => (
                    <button
                      key={item.type}
                      type="button"
                      onClick={() => handleChangeType(item.type as BlockType)}
                      className={`p-2.5 rounded-xl border text-left text-xs font-semibold transition-all ${
                        formData.type === item.type
                          ? 'border-purple-600 bg-purple-50 text-purple-900 shadow-xs'
                          : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-stone-100">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isVisible}
                    onChange={(e) => setFormData((prev) => ({ ...prev, isVisible: e.target.checked }))}
                    className="w-4 h-4 text-purple-600 rounded"
                  />
                  <span className="text-xs font-bold text-stone-800">
                    Hiển thị khối này trên website (Visible)
                  </span>
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between">
          <div>
            {onDelete && (
              <button
                type="button"
                onClick={() => onDelete(formData.id)}
                className="px-3 py-2 rounded-xl text-xs font-bold text-red-600 hover:bg-red-50 flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span>Xóa khối này</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-200 transition-colors"
            >
              Hủy
            </button>
            <button
              type="button"
              onClick={() => onSave(formData)}
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Check className="w-4 h-4" />
              <span>Lưu thay đổi Block</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
