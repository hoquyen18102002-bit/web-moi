import React from 'react';
import { PageSection, PageBlock, ThemeDesignSystem } from '../../types/pageBuilder';
import { DynamicBlockRenderer } from './DynamicBlockRenderer';
import { MoveUp, MoveDown, Trash2, Plus, Edit3 } from 'lucide-react';

interface DynamicSectionRendererProps {
  section: PageSection;
  theme: ThemeDesignSystem;
  isLiveEditing?: boolean;
  onEditSection?: (section: PageSection) => void;
  onDeleteSection?: (sectionId: string) => void;
  onMoveSection?: (sectionId: string, direction: 'up' | 'down') => void;
  onAddBlockToSection?: (sectionId: string) => void;
  onEditBlock?: (block: PageBlock) => void;
  onDeleteBlock?: (blockId: string) => void;
  onMoveBlock?: (blockId: string, direction: 'up' | 'down') => void;
  onDuplicateBlock?: (blockId: string) => void;
}

export const DynamicSectionRenderer: React.FC<DynamicSectionRendererProps> = ({
  section,
  theme,
  isLiveEditing,
  onEditSection,
  onDeleteSection,
  onMoveSection,
  onAddBlockToSection,
  onEditBlock,
  onDeleteBlock,
  onMoveBlock,
  onDuplicateBlock,
}) => {
  if (!section.isVisible && !isLiveEditing) {
    return null;
  }

  // Determine grid template according to layout
  const getLayoutClasses = () => {
    switch (section.layout) {
      case '2-col-equal':
        return 'grid grid-cols-1 md:grid-cols-2 gap-6';
      case '2-col-1-2':
        return 'grid grid-cols-1 md:grid-cols-3 gap-6'; // col 0: span 1, col 1: span 2
      case '2-col-2-1':
        return 'grid grid-cols-1 md:grid-cols-3 gap-6'; // col 0: span 2, col 1: span 1
      case '3-col-equal':
        return 'grid grid-cols-1 md:grid-cols-3 gap-6';
      case '4-col-equal':
        return 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6';
      case '1-col':
      default:
        return 'space-y-6';
    }
  };

  const getColSpanClass = (index: number) => {
    if (section.layout === '2-col-1-2') {
      return index === 0 ? 'md:col-span-1' : 'md:col-span-2';
    }
    if (section.layout === '2-col-2-1') {
      return index === 0 ? 'md:col-span-2' : 'md:col-span-1';
    }
    return '';
  };

  return (
    <section
      id={section.id}
      className={`relative transition-all overflow-hidden ${
        isLiveEditing ? 'border-2 border-dashed border-sky-400/40 hover:border-sky-500 rounded-3xl p-4 my-4' : ''
      }`}
      style={{
        backgroundColor: section.backgroundColor || 'transparent',
        backgroundImage: section.backgroundImageUrl ? `url(${section.backgroundImageUrl})` : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        paddingTop: `${(section.paddingTop || 6) * 4}px`,
        paddingBottom: `${(section.paddingBottom || 6) * 4}px`,
        minHeight: section.minHeight || 'auto',
      }}
    >
      {/* Background Overlay if specified */}
      {section.backgroundImageUrl && section.backgroundOverlay && section.backgroundOverlay !== 'none' && (
        <div
          className={`absolute inset-0 pointer-events-none ${
            section.backgroundOverlay === 'dark'
              ? 'bg-black/65'
              : section.backgroundOverlay === 'light'
              ? 'bg-white/80'
              : 'bg-gradient-to-r from-stone-950 via-stone-900/80 to-transparent'
          }`}
        />
      )}

      {/* Live Editor Section Bar */}
      {isLiveEditing && (
        <div className="absolute top-2 left-2 z-20 bg-sky-950/90 backdrop-blur-xs text-sky-200 text-xs px-3 py-1.5 rounded-xl flex items-center gap-2 border border-sky-800 shadow-md">
          <span className="font-bold">{section.name || 'Section'}</span>
          <span className="text-[10px] bg-sky-900 px-1.5 py-0.5 rounded font-mono">{section.layout}</span>

          {onEditSection && (
            <button
              type="button"
              onClick={() => onEditSection(section)}
              className="p-1 hover:bg-sky-800 rounded text-sky-300"
              title="Cài đặt Section"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          )}
          {onMoveSection && (
            <>
              <button
                type="button"
                onClick={() => onMoveSection(section.id, 'up')}
                className="p-1 hover:bg-sky-800 rounded text-sky-300"
                title="Di chuyển section lên"
              >
                <MoveUp className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onMoveSection(section.id, 'down')}
                className="p-1 hover:bg-sky-800 rounded text-sky-300"
                title="Di chuyển section xuống"
              >
                <MoveDown className="w-3.5 h-3.5" />
              </button>
            </>
          )}
          {onAddBlockToSection && (
            <button
              type="button"
              onClick={() => onAddBlockToSection(section.id)}
              className="p-1 hover:bg-sky-800 rounded text-emerald-400 font-bold flex items-center gap-1"
              title="Thêm block vào section này"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Thêm Block</span>
            </button>
          )}
          {onDeleteSection && (
            <button
              type="button"
              onClick={() => onDeleteSection(section.id)}
              className="p-1 hover:bg-sky-800 rounded text-red-400"
              title="Xóa section này"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* Main Inner Container */}
      <div
        className={`relative z-10 mx-auto px-4 sm:px-6 ${
          section.fullWidth ? 'w-full max-w-full' : theme.containerMaxWidth || 'max-w-7xl'
        }`}
      >
        <div className={getLayoutClasses()}>
          {section.blocks.map((block, idx) => (
            <div key={block.id} className={getColSpanClass(idx)}>
              <DynamicBlockRenderer
                block={block}
                theme={theme}
                isLiveEditing={isLiveEditing}
                onEditBlock={onEditBlock}
                onDeleteBlock={onDeleteBlock}
                onMoveBlock={onMoveBlock}
                onDuplicateBlock={onDuplicateBlock}
              />
            </div>
          ))}

          {section.blocks.length === 0 && isLiveEditing && (
            <div className="col-span-full py-12 text-center border-2 border-dashed border-stone-300 rounded-2xl bg-stone-50/50">
              <p className="text-sm text-stone-500 font-medium">Section này chưa có khối nội dung nào.</p>
              {onAddBlockToSection && (
                <button
                  type="button"
                  onClick={() => onAddBlockToSection(section.id)}
                  className="mt-3 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold inline-flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Thêm Block mới ngay</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
