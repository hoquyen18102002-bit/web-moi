import React from 'react';
import { useApp } from '../../context/AppContext';
import { HeaderConfig, NavMenuItem, ThemeDesignSystem } from '../../types/pageBuilder';
import {
  PhoneCall,
  Radio,
  X,
  Sparkles,
  LogIn,
  User,
  LogOut,
  ChevronDown,
  LayoutDashboard,
  HeartHandshake,
  ShieldAlert,
  Menu,
} from 'lucide-react';

interface DynamicHeaderProps {
  header: HeaderConfig;
  menu: NavMenuItem[];
  theme: ThemeDesignSystem;
  onOpenLogin: () => void;
  isLiveEditing?: boolean;
}

export const DynamicHeader: React.FC<DynamicHeaderProps> = ({
  header,
  menu,
  theme,
  onOpenLogin,
  isLiveEditing,
}) => {
  const { state, currentUser, setCurrentUser, currentView, setCurrentView, dismissBroadcastAlert } = useApp();
  const broadcast = state.realtimeSettings?.broadcastAlert;
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('home');
  };

  const handleMenuClick = (item: NavMenuItem) => {
    setMobileMenuOpen(false);
    if (item.targetType === 'action') {
      if (item.targetAction === 'positive_room') setCurrentView('positive_room');
      else if (item.targetAction === 'emergency') setCurrentView('urgent_chat');
      else if (item.targetAction === 'tests') setCurrentView('dashboard');
      else if (item.targetAction === 'dashboard') setCurrentView(currentUser ? 'dashboard' : 'home');
      else if (item.targetAction === 'login') onOpenLogin();
      else setCurrentView('home');
    } else {
      // In a dynamic routing context, switch active page or return to home
      setCurrentView('home');
    }
  };

  return (
    <header className={`z-40 ${header.isSticky ? 'sticky top-0' : 'relative'} border-b border-stone-200 shadow-xs transition-colors`}>
      {/* Top informational announcement banner */}
      <div className="bg-stone-900 text-stone-200 px-4 py-1.5 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-4">
            {header.showEmergencyHotline && (
              <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                <PhoneCall className="w-3.5 h-3.5" />
                Hotline 24/7: {state.siteSettings.footerInfo.hotline}
              </span>
            )}
            <span className="hidden sm:inline text-stone-400">|</span>
            <span className="hidden sm:inline text-stone-300">
              Phòng tham vấn: {state.siteSettings.footerInfo.phone}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-stone-300 text-xs hidden md:inline">
              Môi trường lắng nghe bảo mật & ẩn danh cho học sinh
            </span>
            {currentUser && (
              <span className="text-xs bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800/60 font-mono">
                Đã đăng nhập: {currentUser.fullName} ({currentUser.role})
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Real-time School-wide Broadcast Alert Banner */}
      {broadcast && broadcast.active && (
        <div
          className={`px-4 py-2.5 text-xs text-white transition-all shadow-xs flex items-center justify-between gap-3 ${
            broadcast.level === 'emergency'
              ? 'bg-red-600 border-b border-red-700'
              : broadcast.level === 'warning'
              ? 'bg-amber-600 border-b border-amber-700'
              : 'bg-emerald-600 border-b border-emerald-700'
          }`}
        >
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-black/20 font-bold uppercase tracking-wider text-[10px] shrink-0">
                <Radio className="w-3 h-3 animate-pulse" />
                {broadcast.level === 'emergency'
                  ? 'Phát sóng Khẩn cấp'
                  : broadcast.level === 'warning'
                  ? 'Cảnh báo Trực tiếp'
                  : 'Thông báo Real-time'}
              </span>
              <p className="font-medium truncate text-xs sm:text-sm">
                {broadcast.message}
              </p>
              <span className="text-[10px] opacity-80 hidden md:inline shrink-0">
                ({broadcast.createdAt} - bởi {broadcast.authorName})
              </span>
            </div>

            {currentUser?.role === 'admin' && (
              <button
                type="button"
                onClick={() => dismissBroadcastAlert()}
                className="px-2.5 py-1 rounded bg-black/20 hover:bg-black/40 text-[11px] font-semibold flex items-center gap-1 shrink-0 transition-colors"
                title="Quản trị viên tắt thông báo này"
              >
                <X className="w-3.5 h-3.5" />
                <span>Gỡ thông báo</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Main Dynamic Header Bar */}
      <div
        className="px-4 sm:px-6 transition-colors backdrop-blur-md"
        style={{
          backgroundColor: header.backgroundColor || '#ffffff',
          color: header.textColor || '#1c1917',
          minHeight: `${header.heightPx || 72}px`,
        }}
      >
        <div className="max-w-7xl mx-auto h-full flex items-center justify-between gap-4 py-2">
          {/* Logo & Brand Identity */}
          <div
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => setCurrentView('home')}
          >
            {header.logoIconUrl ? (
              <img
                src={header.logoIconUrl}
                alt="Logo"
                className="w-10 h-10 rounded-xl object-cover border border-stone-200 shadow-xs group-hover:scale-105 transition-transform"
              />
            ) : (
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold shadow-xs group-hover:scale-105 transition-transform"
                style={{ backgroundColor: theme.primaryColor }}
              >
                <HeartHandshake className="w-6 h-6" />
              </div>
            )}

            <div>
              <h1 className="text-base sm:text-lg font-extrabold tracking-tight leading-none group-hover:text-emerald-600 transition-colors">
                {header.logoText || state.siteSettings.siteName}
              </h1>
              {header.logoSubtext && (
                <p className="text-[11px] text-stone-500 font-medium mt-0.5">
                  {header.logoSubtext}
                </p>
              )}
            </div>
          </div>

          {/* Dynamic Navigation Menu Items (Desktop) */}
          <nav className="hidden lg:flex items-center gap-1">
            {menu.map((item) => (
              <div key={item.id} className="relative group/menu">
                <button
                  type="button"
                  onClick={() => handleMenuClick(item)}
                  className="px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold text-stone-700 hover:text-stone-950 hover:bg-stone-100 transition-colors flex items-center gap-1"
                >
                  <span>{item.label}</span>
                  {item.children && item.children.length > 0 && (
                    <ChevronDown className="w-3.5 h-3.5 text-stone-400 group-hover/menu:rotate-180 transition-transform" />
                  )}
                </button>

                {/* Submenu dropdown */}
                {item.children && item.children.length > 0 && (
                  <div className="absolute top-full left-0 mt-1 w-56 bg-white rounded-xl shadow-xl border border-stone-200 py-1.5 opacity-0 invisible group-hover/menu:opacity-100 group-hover/menu:visible transition-all duration-150 z-50">
                    {item.children.map((sub) => (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => handleMenuClick(sub)}
                        className="w-full text-left px-4 py-2 text-xs text-stone-700 hover:bg-emerald-50 hover:text-emerald-800 transition-colors font-medium flex items-center justify-between"
                      >
                        <span>{sub.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2">
            {/* Quick Positive Room shortcut */}
            <button
              type="button"
              onClick={() => setCurrentView('positive_room')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-200/80 shadow-xs transition-all active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Phòng Tích Cực AI</span>
            </button>

            {/* Quick SOS Shortcut */}
            <button
              type="button"
              onClick={() => setCurrentView('urgent_chat')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold text-xs bg-red-600 hover:bg-red-700 text-white shadow-xs transition-all active:scale-95"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">SOS</span>
            </button>

            {/* User Account Controls */}
            {header.showAuthButton && (
              <>
                {currentUser ? (
                  <div className="flex items-center gap-2 pl-2 border-l border-stone-200">
                    <button
                      type="button"
                      onClick={() => setCurrentView('dashboard')}
                      className="px-3 py-1.5 rounded-xl text-xs font-bold text-white shadow-xs flex items-center gap-1.5 transition-all"
                      style={{ backgroundColor: theme.primaryColor }}
                    >
                      <LayoutDashboard className="w-3.5 h-3.5" />
                      <span className="hidden md:inline">Dashboard ({currentUser.role})</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleLogout}
                      className="p-1.5 rounded-xl text-stone-500 hover:text-stone-900 hover:bg-stone-100 transition-colors"
                      title="Đăng xuất"
                    >
                      <LogOut className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={onOpenLogin}
                    className="px-3.5 py-1.5 rounded-xl font-bold text-xs text-white shadow-xs flex items-center gap-1.5 transition-all"
                    style={{ backgroundColor: theme.primaryColor }}
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Đăng nhập</span>
                  </button>
                )}
              </>
            )}

            {/* Mobile hamburger menu toggle */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-stone-600 hover:bg-stone-100 transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-stone-200 space-y-2 animate-fade-in">
            {menu.map((item) => (
              <div key={item.id} className="space-y-1">
                <button
                  type="button"
                  onClick={() => handleMenuClick(item)}
                  className="w-full text-left px-3 py-2 rounded-lg text-sm font-semibold text-stone-800 hover:bg-stone-100"
                >
                  {item.label}
                </button>
                {item.children && (
                  <div className="pl-4 space-y-1 border-l-2 border-stone-200 ml-3">
                    {item.children.map((sub) => (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => handleMenuClick(sub)}
                        className="w-full text-left py-1 text-xs text-stone-600 hover:text-emerald-600"
                      >
                        {sub.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </header>
  );
};
