import React, { useState } from 'react';
import { PageSection, SectionLayout } from '../../types/pageBuilder';
import { X, Check, Trash2, Layout, Image } from 'lucide-react';

interface SectionEditorModalProps {
  section: PageSection;
  onSave: (updatedSection: PageSection) => void;
  onClose: () => void;
  onDelete?: (sectionId: string) => void;
}

export const SectionEditorModal: React.FC<SectionEditorModalProps> = ({
  section,
  onSave,
  onClose,
  onDelete,
}) => {
  const [formData, setFormData] = useState<PageSection>(JSON.parse(JSON.stringify(section)));

  const handleLayoutSelect = (layout: SectionLayout) => {
    setFormData((prev) => ({
      ...prev,
      layout,
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fade-in">
      <div className="bg-white rounded-3xl max-w-xl w-full max-h-[85vh] flex flex-col overflow-hidden shadow-2xl border border-stone-200">
        <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-sky-100 text-sky-700 font-bold text-xs">
              Section Editor
            </span>
            <div>
              <h3 className="font-bold text-stone-900 text-base">
                Cài đặt Section (Phần bố cục)
              </h3>
              <p className="text-xs text-stone-500 font-mono">ID: {formData.id}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-stone-200 text-stone-400 hover:text-stone-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-5 text-xs sm:text-sm">
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Tên gợi nhớ Section
            </label>
            <input
              type="text"
              value={formData.name || ''}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="VD: Hero Banner, Danh sách dịch vụ..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs outline-hidden focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* Bố cục cột (Column Layout Grid) */}
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1.5">
              Bố cục phân chia cột (Layout)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { id: '1-col', label: '1 Cột tràn dòng (100%)' },
                { id: '2-col-equal', label: '2 Cột đều nhau (50% - 50%)' },
                { id: '2-col-1-2', label: '2 Cột (33% - 66%)' },
                { id: '2-col-2-1', label: '2 Cột (66% - 33%)' },
                { id: '3-col-equal', label: '3 Cột đều nhau (33% x 3)' },
                { id: '4-col-equal', label: '4 Cột đều nhau (25% x 4)' },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleLayoutSelect(item.id as SectionLayout)}
                  className={`p-2.5 rounded-xl border text-left text-xs font-semibold transition-all ${
                    formData.layout === item.id
                      ? 'border-sky-600 bg-sky-50 text-sky-950 shadow-xs'
                      : 'border-stone-200 hover:bg-stone-50 text-stone-700'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Màu nền Section
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={formData.backgroundColor || '#ffffff'}
                  onChange={(e) => setFormData({ ...formData, backgroundColor: e.target.value })}
                  className="w-9 h-9 rounded-lg border cursor-pointer"
                />
                <input
                  type="text"
                  value={formData.backgroundColor || ''}
                  onChange={(e) => setFormData({ ...formData, backgroundColor: e.target.value })}
                  placeholder="#ffffff hoặc transparent"
                  className="flex-1 px-3 py-1.5 rounded-xl border border-stone-300 text-xs font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Lớp phủ màu (Overlay)
              </label>
              <select
                value={formData.backgroundOverlay || 'none'}
                onChange={(e) => setFormData({ ...formData, backgroundOverlay: e.target.value as any })}
                className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs"
              >
                <option value="none">Không có lớp phủ</option>
                <option value="dark">Lớp phủ tối (Dark overlay)</option>
                <option value="light">Lớp phủ sáng (Light overlay)</option>
                <option value="gradient">Gradient mờ dần</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Ảnh nền (Background Image URL)
            </label>
            <input
              type="text"
              value={formData.backgroundImageUrl || ''}
              onChange={(e) => setFormData({ ...formData, backgroundImageUrl: e.target.value })}
              placeholder="https://images.unsplash.com/..."
              className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-xs font-mono"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Khoảng đệm trên (Padding Top)
              </label>
              <input
                type="number"
                min="0"
                max="32"
                value={formData.paddingTop ?? 6}
                onChange={(e) => setFormData({ ...formData, paddingTop: Number(e.target.value) })}
                className="w-full px-3 py-1.5 rounded-xl border border-stone-300 text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Khoảng đệm dưới (Padding Bottom)
              </label>
              <input
                type="number"
                min="0"
                max="32"
                value={formData.paddingBottom ?? 6}
                onChange={(e) => setFormData({ ...formData, paddingBottom: Number(e.target.value) })}
                className="w-full px-3 py-1.5 rounded-xl border border-stone-300 text-xs"
              />
            </div>
          </div>

          <div className="flex items-center gap-4 pt-3 border-t border-stone-100">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.fullWidth || false}
                onChange={(e) => setFormData({ ...formData, fullWidth: e.target.checked })}
                className="w-4 h-4 text-sky-600 rounded"
              />
              <span className="text-xs font-semibold text-stone-800">
                Toàn màn hình 100% (Full width)
              </span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.isVisible}
                onChange={(e) => setFormData({ ...formData, isVisible: e.target.checked })}
                className="w-4 h-4 text-sky-600 rounded"
              />
              <span className="text-xs font-semibold text-stone-800">
                Hiển thị Section
              </span>
            </label>
          </div>
        </div>

        <div className="px-6 py-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between">
          <div>
            {onDelete && (
              <button
                type="button"
                onClick={() => onDelete(formData.id)}
                className="px-3 py-2 rounded-xl text-xs font-bold text-red-600 hover:bg-red-50 flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>Xóa Section</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:bg-stone-200"
            >
              Hủy
            </button>
            <button
              type="button"
              onClick={() => onSave(formData)}
              className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 flex items-center gap-1.5 shadow-xs"
            >
              <Check className="w-4 h-4" />
              <span>Lưu cấu hình Section</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
