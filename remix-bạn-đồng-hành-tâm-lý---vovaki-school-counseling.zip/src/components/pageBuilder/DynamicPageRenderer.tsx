import React from 'react';
import { useApp } from '../../context/AppContext';
import { DynamicPage, ThemeDesignSystem, PageSection, PageBlock } from '../../types/pageBuilder';
import { DynamicSectionRenderer } from './DynamicSectionRenderer';

interface DynamicPageRendererProps {
  page?: DynamicPage;
  theme: ThemeDesignSystem;
  isLiveEditing?: boolean;
  onEditSection?: (section: PageSection) => void;
  onDeleteSection?: (sectionId: string) => void;
  onMoveSection?: (sectionId: string, direction: 'up' | 'down') => void;
  onAddBlockToSection?: (sectionId: string) => void;
  onEditBlock?: (block: PageBlock) => void;
  onDeleteBlock?: (blockId: string) => void;
  onMoveBlock?: (blockId: string, direction: 'up' | 'down') => void;
  onDuplicateBlock?: (blockId: string) => void;
  onAddNewSection?: () => void;
}

export const DynamicPageRenderer: React.FC<DynamicPageRendererProps> = ({
  page,
  theme,
  isLiveEditing,
  onEditSection,
  onDeleteSection,
  onMoveSection,
  onAddBlockToSection,
  onEditBlock,
  onDeleteBlock,
  onMoveBlock,
  onDuplicateBlock,
  onAddNewSection,
}) => {
  const { state } = useApp();
  const activePage = page || state.dynamicWebsite?.pages.find((p) => p.id === state.dynamicWebsite?.activePageId) || state.dynamicWebsite?.pages[0];

  if (!activePage) {
    return (
      <div className="py-20 text-center text-stone-500">
        <p className="text-base font-semibold">Chưa tìm thấy trang nội dung nào.</p>
        <p className="text-xs text-stone-400 mt-1">Vui lòng tạo trang mới trong trang quản trị Administrator.</p>
      </div>
    );
  }

  return (
    <div
      className="w-full flex flex-col space-y-4 pb-12 transition-colors"
      style={{
        backgroundColor: theme.backgroundColor || '#ffffff',
        fontFamily: theme.fontFamily || 'Be Vietnam Pro',
        color: theme.textColor || '#1c1917',
      }}
    >
      {/* Sections rendering loop */}
      {activePage.sections.map((section) => (
        <DynamicSectionRenderer
          key={section.id}
          section={section}
          theme={theme}
          isLiveEditing={isLiveEditing}
          onEditSection={onEditSection}
          onDeleteSection={onDeleteSection}
          onMoveSection={onMoveSection}
          onAddBlockToSection={onAddBlockToSection}
          onEditBlock={onEditBlock}
          onDeleteBlock={onDeleteBlock}
          onMoveBlock={onMoveBlock}
          onDuplicateBlock={onDuplicateBlock}
        />
      ))}

      {/* If in live edit mode, show button to add new section at bottom */}
      {isLiveEditing && onAddNewSection && (
        <div className="max-w-7xl mx-auto w-full px-4 py-6 text-center">
          <button
            type="button"
            onClick={onAddNewSection}
            className="w-full py-4 rounded-2xl border-2 border-dashed border-emerald-400 hover:border-emerald-600 bg-emerald-50/50 hover:bg-emerald-50 text-emerald-800 font-bold text-sm transition-all flex items-center justify-center gap-2"
          >
            <span>+ Thêm Section (Phần Bố Cục) Mới Cho Trang Này</span>
          </button>
        </div>
      )}
    </div>
  );
};
