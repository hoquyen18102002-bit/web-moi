import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PageBlock, ThemeDesignSystem } from '../../types/pageBuilder';
import {
  Sparkles,
  ArrowRight,
  BookOpen,
  Clock,
  User,
  HeartHandshake,
  Phone,
  AlertTriangle,
  Radio,
  ExternalLink,
  Edit,
  Trash2,
  MoveUp,
  MoveDown,
  Copy,
} from 'lucide-react';

interface DynamicBlockRendererProps {
  block: PageBlock;
  theme: ThemeDesignSystem;
  isLiveEditing?: boolean;
  onEditBlock?: (block: PageBlock) => void;
  onDeleteBlock?: (blockId: string) => void;
  onMoveBlock?: (blockId: string, direction: 'up' | 'down') => void;
  onDuplicateBlock?: (blockId: string) => void;
}

export const DynamicBlockRenderer: React.FC<DynamicBlockRendererProps> = ({
  block,
  theme,
  isLiveEditing,
  onEditBlock,
  onDeleteBlock,
  onMoveBlock,
  onDuplicateBlock,
}) => {
  const { state, setCurrentView, setActiveEmergencyId } = useApp();
  const [selectedArticle, setSelectedArticle] = useState<any>(null);

  if (!block.isVisible && !isLiveEditing) {
    return null;
  }

  const getButtonClass = (variant?: string) => {
    const base = `px-5 py-2.5 font-bold text-xs sm:text-sm inline-flex items-center gap-2 transition-all active:scale-95 ${theme.buttonStyle || 'rounded-xl'} shadow-xs`;
    switch (variant) {
      case 'secondary':
        return `${base} bg-sky-600 hover:bg-sky-700 text-white`;
      case 'outline':
        return `${base} bg-white hover:bg-stone-100 text-stone-800 border border-stone-300`;
      case 'danger':
        return `${base} bg-red-600 hover:bg-red-700 text-white shadow-md animate-pulse`;
      case 'amber':
        return `${base} bg-amber-500 hover:bg-amber-600 text-stone-950 font-extrabold`;
      case 'primary':
      default:
        return `${base} text-white`;
    }
  };

  const handleActionClick = (link?: string) => {
    if (!link) return;
    if (link === 'positive_room') {
      // Trigger positive room modal or dashboard
      setCurrentView('positive_room');
    } else if (link === 'emergency') {
      setCurrentView('urgent_chat');
    } else if (link === 'counseling' || link === 'tests') {
      setCurrentView('dashboard');
    } else if (link.startsWith('http') || link.startsWith('tel:') || link.startsWith('mailto:')) {
      window.open(link, '_blank');
    } else {
      // Internal navigation
      setCurrentView('home');
    }
  };

  const renderContent = () => {
    switch (block.type) {
      // 1. BANNER BLOCK
      case 'banner':
        return (
          <div
            className={`p-6 sm:p-10 rounded-2xl sm:rounded-3xl relative overflow-hidden transition-all ${
              block.content.alignment === 'center'
                ? 'text-center items-center'
                : block.content.alignment === 'right'
                ? 'text-right items-end'
                : 'text-left items-start'
            } flex flex-col justify-center space-y-4`}
            style={{
              backgroundColor: block.style.backgroundColor || 'transparent',
              color: block.style.textColor || theme.textColor,
            }}
          >
            {block.content.badge && (
              <span
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border shadow-xs"
                style={{
                  backgroundColor: `${theme.primaryColor}25`,
                  color: theme.primaryColor,
                  borderColor: `${theme.primaryColor}40`,
                }}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{block.content.badge}</span>
              </span>
            )}

            {block.content.text && (
              <h2
                className={`tracking-tight leading-tight ${
                  block.style.fontSize === '4xl'
                    ? 'text-3xl sm:text-5xl font-extrabold'
                    : block.style.fontSize === '3xl'
                    ? 'text-2xl sm:text-4xl font-extrabold'
                    : 'text-xl sm:text-3xl font-bold'
                }`}
                style={{ color: block.style.textColor || '#ffffff' }}
              >
                {block.content.text}
              </h2>
            )}

            {block.content.subText && (
              <p
                className="text-sm sm:text-base opacity-90 max-w-2xl leading-relaxed"
                style={{ color: block.style.textColor ? `${block.style.textColor}dd` : '#e2e8f0' }}
              >
                {block.content.subText}
              </p>
            )}

            {block.content.buttonText && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => handleActionClick(block.content.buttonLink)}
                  className={getButtonClass(block.content.buttonVariant)}
                  style={
                    block.content.buttonVariant === 'primary' || !block.content.buttonVariant
                      ? { backgroundColor: theme.primaryColor }
                      : {}
                  }
                >
                  <span>{block.content.buttonText}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        );

      // 2. HEADING BLOCK
      case 'heading':
        return (
          <div
            className={`space-y-1 ${
              block.content.alignment === 'center'
                ? 'text-center'
                : block.content.alignment === 'right'
                ? 'text-right'
                : 'text-left'
            }`}
          >
            {block.content.badge && (
              <span
                className="inline-block text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full mb-1"
                style={{ backgroundColor: `${theme.primaryColor}20`, color: theme.primaryColor }}
              >
                {block.content.badge}
              </span>
            )}
            <h3
              className={`font-bold tracking-tight ${
                block.style.fontSize === '3xl'
                  ? 'text-2xl sm:text-3xl'
                  : block.style.fontSize === '2xl'
                  ? 'text-xl sm:text-2xl'
                  : 'text-lg sm:text-xl'
              }`}
              style={{ color: block.style.textColor || theme.textColor }}
            >
              {block.content.text}
            </h3>
            {block.content.subText && (
              <p className="text-xs sm:text-sm text-stone-500 max-w-xl mx-auto">
                {block.content.subText}
              </p>
            )}
          </div>
        );

      // 3. PARAGRAPH BLOCK
      case 'paragraph':
        return (
          <div
            className={`text-sm sm:text-base leading-relaxed ${
              block.content.alignment === 'center' ? 'text-center' : 'text-left'
            }`}
            style={{ color: block.style.textColor || theme.textColor }}
          >
            {block.content.text}
          </div>
        );

      // 4. IMAGE BLOCK
      case 'image':
        return (
          <div className="space-y-2 overflow-hidden rounded-2xl">
            <img
              src={block.content.imageUrl || 'https://images.unsplash.com/photo-1516534775068-ba3e7458af70?auto=format&fit=crop&w=800&q=80'}
              alt={block.content.text || 'Hình ảnh khối'}
              className="w-full h-auto object-cover rounded-2xl border border-stone-200 shadow-xs max-h-96"
            />
            {block.content.subText && (
              <p className="text-xs text-stone-500 italic text-center">
                {block.content.subText}
              </p>
            )}
          </div>
        );

      // 5. BUTTON BLOCK
      case 'button':
        return (
          <div
            className={`flex ${
              block.content.alignment === 'center'
                ? 'justify-center'
                : block.content.alignment === 'right'
                ? 'justify-end'
                : 'justify-start'
            }`}
          >
            <button
              type="button"
              onClick={() => handleActionClick(block.content.buttonLink)}
              className={getButtonClass(block.content.buttonVariant)}
              style={
                block.content.buttonVariant === 'primary' || !block.content.buttonVariant
                  ? { backgroundColor: theme.primaryColor }
                  : {}
              }
            >
              <span>{block.content.buttonText || block.content.text || 'Nhấn vào đây'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        );

      // 6. CARD BLOCK
      case 'card':
        return (
          <div
            className={`p-6 ${theme.cardRadius || 'rounded-2xl'} ${theme.cardShadow || 'shadow-xs'} border transition-all hover:shadow-md flex flex-col justify-between space-y-4`}
            style={{
              backgroundColor: block.style.backgroundColor || theme.surfaceColor,
              borderColor: block.style.borderColor || '#e2e8f0',
            }}
          >
            {block.content.imageUrl && (
              <div className="h-40 -mx-6 -mt-6 mb-2 overflow-hidden rounded-t-2xl relative">
                <img
                  src={block.content.imageUrl}
                  alt={block.title || 'Card banner'}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                {block.content.badge && (
                  <span
                    className="absolute top-3 left-3 text-[11px] font-bold px-2.5 py-0.5 rounded-full text-white shadow-xs"
                    style={{ backgroundColor: theme.primaryColor }}
                  >
                    {block.content.badge}
                  </span>
                )}
              </div>
            )}

            <div className="space-y-2">
              {!block.content.imageUrl && block.content.badge && (
                <span
                  className="inline-block text-xs font-semibold px-2 py-0.5 rounded-md"
                  style={{ backgroundColor: `${theme.primaryColor}15`, color: theme.primaryColor }}
                >
                  {block.content.badge}
                </span>
              )}

              <h4 className="font-bold text-base text-stone-900 leading-snug">
                {block.content.text || block.title}
              </h4>

              {block.content.subText && (
                <p className="text-xs text-stone-600 leading-relaxed">
                  {block.content.subText}
                </p>
              )}
            </div>

            {block.content.buttonText && (
              <button
                type="button"
                onClick={() => handleActionClick(block.content.buttonLink)}
                className={`w-full py-2.5 rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-1.5 ${
                  block.content.buttonVariant === 'amber'
                    ? 'bg-amber-500 hover:bg-amber-600 text-stone-950'
                    : block.content.buttonVariant === 'secondary'
                    ? 'bg-sky-600 hover:bg-sky-700 text-white'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                }`}
                style={
                  block.content.buttonVariant === 'primary' || !block.content.buttonVariant
                    ? { backgroundColor: theme.primaryColor }
                    : {}
                }
              >
                <span>{block.content.buttonText}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        );

      // 7. ARTICLES MODULE (Chuyên mục bài viết tư vấn)
      case 'articles_module':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold text-stone-900 tracking-tight flex items-center gap-2">
                  <BookOpen className="w-5 h-5" style={{ color: theme.primaryColor }} />
                  <span>{block.content.text || 'Chuyên mục Bài viết Tâm lý Học đường'}</span>
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  {block.content.subText || 'Những bài viết chuyên sâu từ Tổ Tư vấn Tâm lý giúp học sinh thấu hiểu cảm xúc'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {state.articles.slice(0, 6).map((article) => (
                <article
                  key={article.id}
                  className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col group cursor-pointer"
                  onClick={() => setSelectedArticle(article)}
                >
                  <div className="relative h-44 overflow-hidden bg-stone-100">
                    <img
                      src={article.imageUrl}
                      alt={article.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <span className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-xs text-white text-[11px] font-semibold px-2.5 py-1 rounded-md">
                      {article.category}
                    </span>
                  </div>

                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-3 text-xs text-stone-400">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {article.readTime}
                        </span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {article.author}
                        </span>
                      </div>
                      <h4 className="font-bold text-sm sm:text-base text-stone-900 group-hover:text-emerald-700 transition-colors line-clamp-2">
                        {article.title}
                      </h4>
                      <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                        {article.excerpt}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs font-bold text-emerald-600 group-hover:translate-x-1 transition-transform">
                      <span>Đọc bài viết</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </article>
              ))}
            </div>

            {/* Article modal reader */}
            {selectedArticle && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fade-in">
                <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden shadow-2xl border border-stone-200">
                  <div className="relative h-56 shrink-0 bg-stone-900">
                    <img
                      src={selectedArticle.imageUrl}
                      alt={selectedArticle.title}
                      className="w-full h-full object-cover opacity-80"
                    />
                    <button
                      type="button"
                      onClick={() => setSelectedArticle(null)}
                      className="absolute top-4 right-4 p-2 rounded-full bg-black/50 hover:bg-black/70 text-white transition-colors"
                    >
                      ✕
                    </button>
                    <div className="absolute bottom-4 left-6 right-6 text-white">
                      <span className="px-2.5 py-1 rounded-md bg-emerald-600 text-xs font-bold inline-block mb-2">
                        {selectedArticle.category}
                      </span>
                      <h3 className="text-lg sm:text-xl font-extrabold leading-snug">
                        {selectedArticle.title}
                      </h3>
                    </div>
                  </div>

                  <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-stone-700 leading-relaxed">
                    <div className="flex items-center justify-between text-xs text-stone-500 pb-3 border-b border-stone-100">
                      <span>Tác giả: <strong>{selectedArticle.author}</strong></span>
                      <span>Ngày đăng: {selectedArticle.date}</span>
                    </div>
                    <p className="font-semibold text-stone-900 text-sm italic">
                      {selectedArticle.excerpt}
                    </p>
                    <div className="whitespace-pre-line space-y-3">
                      {selectedArticle.content}
                    </div>
                  </div>

                  <div className="p-4 bg-stone-50 border-t border-stone-200 flex justify-end">
                    <button
                      type="button"
                      onClick={() => setSelectedArticle(null)}
                      className="px-5 py-2 rounded-xl bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold"
                    >
                      Đóng cẩm nang
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        );

      // 8. EMERGENCY MODULE (Khối SOS)
      case 'emergency_module':
        return (
          <div className="p-6 rounded-2xl bg-white border border-red-200 shadow-md flex flex-col justify-between space-y-4">
            <div className="space-y-2">
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-700">
                <AlertTriangle className="w-3.5 h-3.5 text-red-600 animate-pulse" />
                <span>{block.content.badge || 'Hỗ trợ 24/7'}</span>
              </span>
              <h4 className="font-bold text-base text-red-950">
                {block.content.text || 'Kênh Hỗ Trợ SOS Khẩn Cấp'}
              </h4>
              <p className="text-xs text-stone-600 leading-relaxed">
                {block.content.subText || 'Kết nối ngay lập tức với chuyên gia tư vấn khi bạn gặp áp lực hoặc bế tắc.'}
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleActionClick(block.content.buttonLink || 'emergency')}
              className="w-full py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              <Radio className="w-4 h-4 animate-pulse" />
              <span>{block.content.buttonText || 'Mở phiên SOS Khẩn cấp'}</span>
            </button>
          </div>
        );

      // 9. HOTLINE MODULE
      case 'hotline_module':
        return (
          <div className="p-6 rounded-2xl bg-white border border-amber-200 shadow-md flex flex-col justify-between space-y-4">
            <div className="space-y-2">
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
                <Phone className="w-3.5 h-3.5 text-amber-600" />
                <span>{block.content.badge || 'Đường dây nóng'}</span>
              </span>
              <h4 className="font-bold text-base text-stone-900">
                {block.content.text || 'Hotline Tâm lý Học đường: 1900 6868'}
              </h4>
              <p className="text-xs text-stone-600 leading-relaxed">
                {block.content.subText || 'Tư vấn viên trực tiếp 24/7. Hoàn toàn miễn phí cước gọi và bảo mật danh tính.'}
              </p>
            </div>
            <a
              href="tel:19006868"
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-stone-950 font-extrabold text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4" />
              <span>{block.content.buttonText || 'Gọi ngay 1900 6868'}</span>
            </a>
          </div>
        );

      // 10. LIST BLOCK
      case 'list':
        return (
          <div className="p-5 rounded-2xl bg-white border border-stone-200 space-y-3">
            {block.title && (
              <h4 className="font-bold text-sm text-stone-900">{block.title}</h4>
            )}
            <ul className="space-y-2 text-xs text-stone-700">
              {block.content.items?.map((item) => (
                <li key={item.id} className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                  <div>
                    <strong className="text-stone-900">{item.title}</strong>
                    {item.description && <p className="text-stone-500">{item.description}</p>}
                  </div>
                </li>
              )) || (
                <li className="text-stone-400 italic">Chưa có mục danh sách</li>
              )}
            </ul>
          </div>
        );

      // Default fallback
      default:
        return (
          <div className="p-4 rounded-xl border border-stone-200 bg-stone-50 text-xs text-stone-600">
            <strong>Block ({block.type}):</strong> {block.content.text || block.title || 'Nội dung block'}
          </div>
        );
    }
  };

  return (
    <div className="relative group/block transition-all">
      {/* Live Editor Overlay Toolbar */}
      {isLiveEditing && (
        <div className="absolute top-2 right-2 z-20 opacity-0 group-hover/block:opacity-100 transition-opacity bg-stone-900/90 backdrop-blur-xs text-white rounded-xl px-2 py-1 flex items-center gap-1 shadow-lg border border-stone-700 text-xs">
          <span className="text-[10px] font-mono text-stone-400 px-1">{block.type}</span>
          {onEditBlock && (
            <button
              type="button"
              onClick={() => onEditBlock(block)}
              className="p-1 hover:bg-stone-800 rounded text-emerald-400"
              title="Chỉnh sửa block này"
            >
              <Edit className="w-3.5 h-3.5" />
            </button>
          )}
          {onMoveBlock && (
            <>
              <button
                type="button"
                onClick={() => onMoveBlock(block.id, 'up')}
                className="p-1 hover:bg-stone-800 rounded text-stone-300"
                title="Di chuyển lên"
              >
                <MoveUp className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onMoveBlock(block.id, 'down')}
                className="p-1 hover:bg-stone-800 rounded text-stone-300"
                title="Di chuyển xuống"
              >
                <MoveDown className="w-3.5 h-3.5" />
              </button>
            </>
          )}
          {onDuplicateBlock && (
            <button
              type="button"
              onClick={() => onDuplicateBlock(block.id)}
              className="p-1 hover:bg-stone-800 rounded text-sky-400"
              title="Nhân bản block"
            >
              <Copy className="w-3.5 h-3.5" />
            </button>
          )}
          {onDeleteBlock && (
            <button
              type="button"
              onClick={() => onDeleteBlock(block.id)}
              className="p-1 hover:bg-stone-800 rounded text-red-400"
              title="Xóa block"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* Rendered Block Content */}
      <div className={isLiveEditing ? 'ring-1 ring-dashed ring-purple-400/40 hover:ring-purple-600 rounded-2xl p-1' : ''}>
        {renderContent()}
      </div>
    </div>
  );
};
