import React from 'react';
import { useApp } from '../../context/AppContext';
import { FooterConfig, ThemeDesignSystem } from '../../types/pageBuilder';
import { ArrowLeft, Home, Phone, Mail, Globe, MessageSquare, MapPin, ChevronUp } from 'lucide-react';

interface DynamicFooterProps {
  footer: FooterConfig;
  theme: ThemeDesignSystem;
  onOpenLogin: () => void;
}

export const DynamicFooter: React.FC<DynamicFooterProps> = ({
  footer,
  theme,
  onOpenLogin,
}) => {
  const { state, currentUser, currentView, setCurrentView } = useApp();

  const handleBack = () => {
    if (currentView === 'home') return;
    if (
      currentView === 'urgent_chat' ||
      currentView === 'booking_chat' ||
      currentView === 'positive_room' ||
      currentView === 'test_taker'
    ) {
      setCurrentView(currentUser ? 'dashboard' : 'home');
    } else {
      setCurrentView('home');
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getGridColsClass = () => {
    const count = footer.columns?.length || 4;
    if (footer.layout === 'minimal') return 'grid grid-cols-1 md:grid-cols-2 gap-8 mb-8 text-sm';
    if (count === 1) return 'grid grid-cols-1 gap-8 mb-8 text-sm';
    if (count === 2) return 'grid grid-cols-1 md:grid-cols-2 gap-8 mb-8 text-sm';
    if (count === 3) return 'grid grid-cols-1 md:grid-cols-3 gap-8 mb-8 text-sm';
    return 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 mb-8 text-sm';
  };

  const handleLinkClick = (e: React.MouseEvent, url: string) => {
    if (url === '#home' || url === '/') {
      e.preventDefault();
      setCurrentView('home');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (url === '#positive_room') {
      e.preventDefault();
      setCurrentView('positive_room');
    } else if (url === '#emergency' || url === '#sos') {
      e.preventDefault();
      setCurrentView('urgent_chat');
    } else if (url === '#counseling' || url === '#tests') {
      e.preventDefault();
      if (!currentUser) {
        onOpenLogin();
      } else {
        setCurrentView('dashboard');
      }
    } else if (url.startsWith('#')) {
      e.preventDefault();
      const el = document.getElementById(url.replace('#', ''));
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <footer
      className="mt-auto border-t border-stone-800 text-stone-300 transition-colors"
      style={{
        backgroundColor: footer.backgroundColor || '#1c1917',
        color: footer.textColor || '#d6d3d1',
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <div className={getGridColsClass()}>
          {footer.columns && footer.columns.map((col, idx) => (
            <div key={col.id || `col-${idx}`} className="space-y-3">
              <h4 className="text-white font-bold text-sm uppercase tracking-wider border-b border-stone-800/80 pb-2">
                {col.title}
              </h4>
              {col.content && (
                <p className="text-xs text-stone-400 leading-relaxed whitespace-pre-line">
                  {col.content}
                </p>
              )}
              {col.links && col.links.length > 0 && (
                <ul className="space-y-2 text-xs text-stone-400">
                  {col.links.map((link) => (
                    <li key={link.id}>
                      {link.url.startsWith('http') || link.url.startsWith('tel:') || link.url.startsWith('mailto:') ? (
                        <a
                          href={link.url}
                          target={link.url.startsWith('http') ? '_blank' : undefined}
                          rel={link.url.startsWith('http') ? 'noreferrer' : undefined}
                          className="hover:text-white hover:underline transition-colors inline-flex items-center gap-1.5"
                        >
                          {link.label}
                        </a>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => handleLinkClick(e, link.url)}
                          className="hover:text-white hover:underline transition-colors text-left cursor-pointer"
                        >
                          {link.label}
                        </button>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>

        {/* Social Media & Channels */}
        {footer.socialLinks && footer.socialLinks.length > 0 && (
          <div className="pt-6 border-t border-stone-800/80 flex flex-wrap items-center justify-between gap-4 text-xs">
            <div className="flex items-center gap-3">
              <span className="text-stone-400">Kết nối mạng xã hội:</span>
              {footer.socialLinks.map((soc) => (
                <a
                  key={soc.id}
                  href={soc.url}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 transition-colors"
                >
                  {soc.label}
                </a>
              ))}
            </div>

            {footer.showBackToTop && (
              <button
                type="button"
                onClick={scrollToTop}
                className="flex items-center gap-1 text-stone-400 hover:text-white transition-colors cursor-pointer"
              >
                <span>Lên đầu trang</span>
                <ChevronUp className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        <div className="pt-6 text-center text-xs text-stone-400 border-t border-stone-800/60 mt-6">
          {footer.copyrightText || `© ${new Date().getFullYear()} ${state.siteSettings.siteName}. All rights reserved.`}
        </div>
      </div>

      {/* Persistent Floating Bottom Quick Bar */}
      <div className="sticky bottom-0 z-30 bg-white/95 backdrop-blur-md border-t border-stone-200 py-2.5 px-4 shadow-lg text-stone-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {currentView !== 'home' ? (
              <button
                type="button"
                onClick={handleBack}
                className="px-3.5 py-1.5 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 font-bold text-xs flex items-center gap-1.5 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Quay lại</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setCurrentView('home')}
                className="px-3.5 py-1.5 rounded-xl bg-stone-100 text-stone-900 font-bold text-xs flex items-center gap-1.5"
              >
                <Home className="w-4 h-4 text-emerald-600" />
                <span>Trang chủ</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500 hidden sm:inline">
              Hotline hỗ trợ: <strong className="text-emerald-700">{state.siteSettings.footerInfo.hotline}</strong>
            </span>

            {currentUser?.role === 'admin' && (
              <button
                type="button"
                onClick={() => setCurrentView('dashboard')}
                className="px-3 py-1.5 rounded-xl bg-purple-100 text-purple-800 border border-purple-200 hover:bg-purple-200 font-bold text-xs transition-colors"
              >
                Quản trị Admin
              </button>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
};
