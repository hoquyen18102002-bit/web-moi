import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserAccount, UserRole } from '../../types';
import {
  Users,
  Plus,
  Trash2,
  Edit2,
  KeyRound,
  Lock,
  Unlock,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  ShieldAlert,
  UserCheck,
  UserX,
  X,
  Check,
  ShieldCheck,
  GraduationCap,
  Sparkles,
} from 'lucide-react';

interface AdminUserManagementProps {
  initialSubTab?: 'students' | 'teachers' | 'counselors' | 'accounts' | 'roles';
}

export const AdminUserManagement: React.FC<AdminUserManagementProps> = ({
  initialSubTab = 'accounts',
}) => {
  const { state, currentUser, provisionUser, deleteUser, updateUser } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'students' | 'teachers' | 'counselors' | 'accounts' | 'roles'>(
    initialSubTab
  );

  const [searchKeyword, setSearchKeyword] = useState('');
  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>(
    initialSubTab === 'students'
      ? 'student'
      : initialSubTab === 'teachers'
      ? 'homeroom'
      : initialSubTab === 'counselors'
      ? 'counselor'
      : 'all'
  );

  // Sync prop changes
  React.useEffect(() => {
    if (initialSubTab) {
      setActiveSubTab(initialSubTab);
      if (initialSubTab === 'students') setRoleFilter('student');
      else if (initialSubTab === 'teachers') setRoleFilter('homeroom');
      else if (initialSubTab === 'counselors') setRoleFilter('counselor');
      else if (initialSubTab === 'accounts') setRoleFilter('all');
    }
  }, [initialSubTab]);

  // Roles & Permissions matrix state
  const [rolePermissions, setRolePermissions] = useState([
    {
      module: 'Quản trị Giao diện & Website Builder',
      desc: 'Quyền chỉnh sửa trang, layout, theme, header và footer',
      admin: true,
      counselor: false,
      homeroom: false,
      student: false,
    },
    {
      module: 'Quản lý Tài khoản & Phân quyền',
      desc: 'Cấp mới, khóa tài khoản và thiết lập quyền hạn người dùng',
      admin: true,
      counselor: false,
      homeroom: false,
      student: false,
    },
    {
      module: 'Hồ sơ Tâm lý & Cảnh báo Sức khỏe',
      desc: 'Xem kết quả DASS-21, lịch sử cảm xúc và gắn cờ can thiệp',
      admin: true,
      counselor: true,
      homeroom: true,
      student: false,
    },
    {
      module: 'Tiếp nhận & Điều phối Lịch hẹn Tư vấn',
      desc: 'Duyệt lịch hẹn 1-1, phân công chuyên viên và mở phiên chat',
      admin: true,
      counselor: true,
      homeroom: false,
      student: false,
    },
    {
      module: 'Giám sát & Can thiệp Phòng Tích Cực',
      desc: 'Xem phiên trò chuyện của học sinh và gửi chỉ đạo từ xa',
      admin: true,
      counselor: true,
      homeroom: false,
      student: false,
    },
    {
      module: 'Cấu hình Mô hình & Prompt AI',
      desc: 'Tinh chỉnh Gemini, System Prompt và Voice TTS',
      admin: true,
      counselor: false,
      homeroom: false,
      student: false,
    },
    {
      module: 'Đăng Bài viết Cẩm nang & Thông báo',
      desc: 'Biên tập và phát hành nội dung tâm lý học đường',
      admin: true,
      counselor: true,
      homeroom: false,
      student: false,
    },
    {
      module: 'Sao lưu & Phục hồi CSDL',
      desc: 'Xuất file JSON backup và phục hồi dữ liệu hệ thống',
      admin: true,
      counselor: false,
      homeroom: false,
      student: false,
    },
    {
      module: 'Audit Logs & Cài đặt Bảo mật',
      desc: 'Giám sát lịch sử đăng nhập và thao tác quản trị',
      admin: true,
      counselor: false,
      homeroom: false,
      student: false,
    },
  ]);
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'locked'>('all');

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [resetPasswordUser, setResetPasswordUser] = useState<UserAccount | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [userToDelete, setUserToDelete] = useState<UserAccount | null>(null);

  // Add form state
  const [newUserForm, setNewUserForm] = useState<{
    fullName: string;
    username: string;
    role: UserRole;
    password: string;
    email: string;
    phone: string;
    classId: string;
    studentCode: string;
    avatar: string;
  }>({
    fullName: '',
    username: '',
    role: 'student',
    password: '123456',
    email: '',
    phone: '',
    classId: '10A1',
    studentCode: '',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
  });

  const [actionNotice, setActionNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setActionNotice({ type, text });
    setTimeout(() => setActionNotice(null), 4000);
  };

  // Filtered list
  const filteredUsers = state.users.filter((u) => {
    const matchSearch =
      u.fullName.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      u.username.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      (u.studentCode && u.studentCode.toLowerCase().includes(searchKeyword.toLowerCase())) ||
      (u.classId && u.classId.toLowerCase().includes(searchKeyword.toLowerCase()));

    const matchRole = roleFilter === 'all' || u.role === roleFilter;
    const isLocked = u.isActive === false;
    const matchStatus =
      statusFilter === 'all' ||
      (statusFilter === 'locked' && isLocked) ||
      (statusFilter === 'active' && !isLocked);

    return matchSearch && matchRole && matchStatus;
  });

  // Handle Provisioning User
  const handleProvisionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserForm.fullName.trim() || !newUserForm.username.trim()) {
      showToast('Vui lòng nhập đầy đủ Họ tên và Tên đăng nhập', 'error');
      return;
    }
    setIsProcessing(true);
    const res = await provisionUser({
      ...newUserForm,
      username: newUserForm.username.trim().toLowerCase(),
    });
    setIsProcessing(false);

    if (res.success) {
      showToast(`Đã cấp thành công tài khoản: ${newUserForm.fullName} (${newUserForm.username})`);
      setShowAddModal(false);
      setNewUserForm({
        fullName: '',
        username: '',
        role: 'student',
        password: '123456',
        email: '',
        phone: '',
        classId: '10A1',
        studentCode: '',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
      });
    } else {
      showToast(res.error || 'Cấp tài khoản thất bại', 'error');
    }
  };

  // Handle Edit User
  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setIsProcessing(true);
    const res = await updateUser(editingUser.id, editingUser);
    setIsProcessing(false);

    if (res.success) {
      showToast(`Đã cập nhật thông tin thành công cho tài khoản ${editingUser.fullName}`);
      setEditingUser(null);
    } else {
      showToast(res.error || 'Cập nhật thất bại', 'error');
    }
  };

  // Handle Reset Password
  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetPasswordUser || !newPassword.trim()) {
      showToast('Vui lòng nhập mật khẩu mới', 'error');
      return;
    }
    setIsProcessing(true);
    const res = await updateUser(resetPasswordUser.id, { password: newPassword.trim() });
    setIsProcessing(false);

    if (res.success) {
      showToast(`Đã đổi mật khẩu thành công cho ${resetPasswordUser.fullName}`);
      setResetPasswordUser(null);
      setNewPassword('');
    } else {
      showToast(res.error || 'Đổi mật khẩu thất bại', 'error');
    }
  };

  // Handle Toggle Active/Lock
  const handleToggleLock = async (user: UserAccount) => {
    if (user.id === currentUser?.id) {
      showToast('Bạn không thể tự khóa tài khoản Quản trị viên của chính mình', 'error');
      return;
    }
    const nextStatus = user.isActive === false ? true : false;
    const res = await updateUser(user.id, { isActive: nextStatus });
    if (res.success) {
      showToast(
        nextStatus
          ? `Đã mở khóa tài khoản: ${user.fullName}`
          : `Đã khóa tạm thời tài khoản: ${user.fullName}`,
        nextStatus ? 'success' : 'error'
      );
    }
  };

  // Handle Delete Confirmation
  const confirmDelete = async () => {
    if (!userToDelete) return;
    if (userToDelete.id === currentUser?.id) {
      showToast('Bạn không thể tự xóa tài khoản của chính mình', 'error');
      setUserToDelete(null);
      return;
    }
    setIsProcessing(true);
    const res = await deleteUser(userToDelete.id);
    setIsProcessing(false);

    if (res.success) {
      showToast(`Đã xóa vĩnh viễn tài khoản: ${userToDelete.fullName}`);
      setUserToDelete(null);
    } else {
      showToast(res.error || 'Xóa tài khoản thất bại', 'error');
    }
  };

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case 'admin':
        return <span className="text-[11px] px-2.5 py-0.5 rounded-full font-semibold bg-purple-100 text-purple-800 border border-purple-200">Quản trị viên</span>;
      case 'counselor':
        return <span className="text-[11px] px-2.5 py-0.5 rounded-full font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">GV Tư vấn</span>;
      case 'homeroom':
        return <span className="text-[11px] px-2.5 py-0.5 rounded-full font-semibold bg-blue-100 text-blue-800 border border-blue-200">GV Chủ nhiệm</span>;
      case 'student':
        return <span className="text-[11px] px-2.5 py-0.5 rounded-full font-semibold bg-amber-100 text-amber-800 border border-amber-200">Học sinh</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {actionNotice && (
        <div
          className={`p-4 rounded-xl text-xs font-semibold flex items-center justify-between shadow-xs transition-all ${
            actionNotice.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {actionNotice.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span>{actionNotice.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setActionNotice(null)}
            className="p-1 hover:bg-black/5 rounded text-stone-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Control Header */}
      <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-700 flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-stone-900">
                Người Dùng & Phân Quyền Hệ Thống ({state.users.length})
              </h3>
              <p className="text-xs text-stone-500">
                Toàn quyền thêm, chỉnh sửa, cấp lại mật khẩu, khóa tài khoản và thiết lập ma trận phân quyền
              </p>
            </div>
          </div>
        </div>

        {/* Sub-tab switcher */}
        <div className="flex flex-wrap items-center gap-1.5 bg-stone-100 p-1.5 rounded-2xl border border-stone-200 text-xs">
          <button
            type="button"
            onClick={() => {
              setActiveSubTab('students');
              setRoleFilter('student');
            }}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              activeSubTab === 'students'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Học sinh ({state.users.filter((u) => u.role === 'student').length})
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveSubTab('teachers');
              setRoleFilter('homeroom');
            }}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              activeSubTab === 'teachers'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Giáo viên ({state.users.filter((u) => u.role === 'homeroom').length})
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveSubTab('counselors');
              setRoleFilter('counselor');
            }}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              activeSubTab === 'counselors'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            GV Tư Vấn ({state.users.filter((u) => u.role === 'counselor').length})
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveSubTab('accounts');
              setRoleFilter('all');
            }}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
              activeSubTab === 'accounts'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            Tất cả Tài khoản ({state.users.length})
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('roles')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all flex items-center gap-1 ${
              activeSubTab === 'roles'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Vai trò & Phân quyền</span>
          </button>
        </div>

        {activeSubTab !== 'roles' && (
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-semibold text-xs flex items-center gap-2 shadow-xs transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Cấp tài khoản mới</span>
          </button>
        )}
      </div>

      {/* ================= ROLES & PERMISSIONS VIEW ================= */}
      {activeSubTab === 'roles' ? (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-stone-900 text-base">Ma Trận Vai Trò & Phân Quyền Tính Năng</h3>
              <p className="text-xs text-stone-500">
                Kiểm soát quyền truy cập chi tiết của từng vai trò đối với toàn bộ các phân hệ trong hệ thống VoVaKi.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setActionNotice({ type: 'success', text: 'Đã lưu cấu hình phân quyền vai trò thành công!' });
                setTimeout(() => setActionNotice(null), 3000);
              }}
              className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
            >
              <Check className="w-4 h-4" />
              <span>Lưu Ma Trận Phân Quyền</span>
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="px-5 py-4">Phân Hệ & Chức Năng</th>
                    <th className="px-4 py-4 text-center">Quản Trị Viên (Admin)</th>
                    <th className="px-4 py-4 text-center">GV Tư Vấn Tâm Lý</th>
                    <th className="px-4 py-4 text-center">GV Chủ Nhiệm</th>
                    <th className="px-4 py-4 text-center">Học Sinh</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {rolePermissions.map((perm, idx) => (
                    <tr key={idx} className="hover:bg-purple-50/20 transition-colors">
                      <td className="px-5 py-4">
                        <div className="font-bold text-stone-900 text-sm">{perm.module}</div>
                        <div className="text-[11px] text-stone-500">{perm.desc}</div>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={perm.admin}
                          disabled
                          className="w-4 h-4 accent-purple-600 cursor-not-allowed opacity-80"
                        />
                      </td>
                      <td className="px-4 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={perm.counselor}
                          onChange={(e) => {
                            const copy = [...rolePermissions];
                            copy[idx].counselor = e.target.checked;
                            setRolePermissions(copy);
                          }}
                          className="w-4 h-4 accent-purple-600 cursor-pointer"
                        />
                      </td>
                      <td className="px-4 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={perm.homeroom}
                          onChange={(e) => {
                            const copy = [...rolePermissions];
                            copy[idx].homeroom = e.target.checked;
                            setRolePermissions(copy);
                          }}
                          className="w-4 h-4 accent-purple-600 cursor-pointer"
                        />
                      </td>
                      <td className="px-4 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={perm.student}
                          onChange={(e) => {
                            const copy = [...rolePermissions];
                            copy[idx].student = e.target.checked;
                            setRolePermissions(copy);
                          }}
                          className="w-4 h-4 accent-purple-600 cursor-pointer"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-[220px] relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            placeholder="Tìm theo họ tên, tên đăng nhập, lớp hoặc mã số..."
            className="w-full pl-9 pr-4 py-2 rounded-lg border border-stone-200 text-xs focus:ring-2 focus:ring-purple-500 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-stone-400" />
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value as any)}
            className="px-3 py-2 rounded-lg border border-stone-200 text-xs font-medium bg-stone-50 text-stone-700"
          >
            <option value="all">Tất cả vai trò</option>
            <option value="student">Học sinh</option>
            <option value="homeroom">Giáo viên Chủ nhiệm</option>
            <option value="counselor">Giáo viên Tư vấn</option>
            <option value="admin">Quản trị viên</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-2 rounded-lg border border-stone-200 text-xs font-medium bg-stone-50 text-stone-700"
          >
            <option value="all">Tất cả trạng thái</option>
            <option value="active">Đang hoạt động</option>
            <option value="locked">Bị khóa tạm thời</option>
          </select>
        </div>
      </div>

      {/* User Table */}
      <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-stone-700">
            <thead className="bg-stone-50 border-b border-stone-200 text-[11px] font-bold text-stone-500 uppercase tracking-wider">
              <tr>
                <th className="px-4 py-3.5">Họ và Tên</th>
                <th className="px-4 py-3.5">Tài khoản & Mật khẩu</th>
                <th className="px-4 py-3.5">Vai trò</th>
                <th className="px-4 py-3.5">Lớp / Mã HS</th>
                <th className="px-4 py-3.5">Trạng thái</th>
                <th className="px-4 py-3.5">Liên hệ</th>
                <th className="px-4 py-3.5 text-right">Hành động Quản trị</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredUsers.map((u) => {
                const isLocked = u.isActive === false;
                const isCurrentAdmin = u.id === currentUser?.id;

                return (
                  <tr key={u.id} className={`hover:bg-stone-50/80 transition-colors ${isLocked ? 'bg-red-50/30' : ''}`}>
                    <td className="px-4 py-3 font-semibold text-stone-900 flex items-center gap-2.5">
                      <img
                        src={u.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                        alt={u.fullName}
                        className="w-9 h-9 rounded-full object-cover border border-stone-200 shadow-2xs"
                      />
                      <div>
                        <div className="text-stone-900 font-bold">{u.fullName}</div>
                        <div className="text-[10px] text-stone-400 font-normal">
                          Tạo ngày: {u.createdAt} {u.lastLogin && `• Đăng nhập: ${u.lastLogin}`}
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <div className="font-mono text-stone-900 font-bold">{u.username}</div>
                      <div className="text-[10px] text-stone-500 font-mono">
                        MK: {u.password ? '••••••••' : 'Mặc định (123456)'}
                      </div>
                    </td>

                    <td className="px-4 py-3">{getRoleBadge(u.role)}</td>

                    <td className="px-4 py-3">
                      {u.classId && (
                        <span className="bg-stone-100 text-stone-700 px-2 py-0.5 rounded font-mono font-semibold mr-1.5 text-[11px]">
                          {u.classId}
                        </span>
                      )}
                      {u.studentCode && (
                        <span className="text-stone-500 font-mono text-[11px]">
                          {u.studentCode}
                        </span>
                      )}
                      {!u.classId && !u.studentCode && <span className="text-stone-400">—</span>}
                    </td>

                    <td className="px-4 py-3">
                      {isLocked ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-red-600 bg-red-100/80 px-2 py-0.5 rounded-full">
                          <Lock className="w-3 h-3" />
                          Bị khóa
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                          <CheckCircle2 className="w-3 h-3" />
                          Hoạt động
                        </span>
                      )}
                    </td>

                    <td className="px-4 py-3 text-stone-500">
                      <div>{u.email || '—'}</div>
                      <div className="text-[10px]">{u.phone || '—'}</div>
                    </td>

                    <td className="px-4 py-3 text-right">
                      <div className="inline-flex items-center gap-1">
                        {/* Edit Info */}
                        <button
                          type="button"
                          onClick={() => setEditingUser({ ...u })}
                          className="p-1.5 text-stone-500 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                          title="Chỉnh sửa thông tin"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        {/* Reset Password */}
                        <button
                          type="button"
                          onClick={() => {
                            setResetPasswordUser(u);
                            setNewPassword('');
                          }}
                          className="p-1.5 text-stone-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                          title="Đổi mật khẩu"
                        >
                          <KeyRound className="w-3.5 h-3.5" />
                        </button>

                        {/* Lock / Unlock */}
                        {!isCurrentAdmin ? (
                          <button
                            type="button"
                            onClick={() => handleToggleLock(u)}
                            className={`p-1.5 rounded-lg transition-colors ${
                              isLocked
                                ? 'text-emerald-600 hover:bg-emerald-50'
                                : 'text-amber-600 hover:bg-amber-50'
                            }`}
                            title={isLocked ? 'Mở khóa tài khoản' : 'Khóa tài khoản'}
                          >
                            {isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                          </button>
                        ) : null}

                        {/* Delete User */}
                        {!isCurrentAdmin ? (
                          <button
                            type="button"
                            onClick={() => setUserToDelete(u)}
                            className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Xóa vĩnh viễn tài khoản"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <span className="text-[10px] text-purple-600 font-semibold px-2 py-0.5 bg-purple-50 rounded">
                            Chính bạn
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
      </>
      )}

      {/* Modal 1: Add/Provision User */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-stone-200 overflow-hidden">
            <div className="px-6 py-4 bg-purple-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                <h3 className="font-bold text-base">Cấp Tài khoản Mới cho Hệ thống</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg hover:bg-purple-800 text-purple-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleProvisionSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Họ và Tên <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={newUserForm.fullName}
                    onChange={(e) => setNewUserForm({ ...newUserForm, fullName: e.target.value })}
                    placeholder="VD: Nguyễn Văn An"
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Tên đăng nhập <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={newUserForm.username}
                    onChange={(e) => setNewUserForm({ ...newUserForm, username: e.target.value })}
                    placeholder="VD: hs_an, gv_minh"
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Vai trò trên Hệ thống
                  </label>
                  <select
                    value={newUserForm.role}
                    onChange={(e) => setNewUserForm({ ...newUserForm, role: e.target.value as UserRole })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-semibold bg-stone-50 focus:ring-2 focus:ring-purple-500"
                  >
                    <option value="student">Học sinh</option>
                    <option value="homeroom">Giáo viên Chủ nhiệm</option>
                    <option value="counselor">Giáo viên Tư vấn Tâm lý</option>
                    <option value="admin">Quản trị viên Hệ thống</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Mật khẩu khởi tạo
                  </label>
                  <input
                    type="text"
                    value={newUserForm.password}
                    onChange={(e) => setNewUserForm({ ...newUserForm, password: e.target.value })}
                    placeholder="VD: 123456"
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              {(newUserForm.role === 'student' || newUserForm.role === 'homeroom') && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      {newUserForm.role === 'student' ? 'Lớp đang học' : 'Lớp chủ nhiệm'}
                    </label>
                    <select
                      value={newUserForm.classId}
                      onChange={(e) => setNewUserForm({ ...newUserForm, classId: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-medium bg-stone-50"
                    >
                      {state.classes.map((cls) => (
                        <option key={cls} value={cls}>{cls}</option>
                      ))}
                    </select>
                  </div>

                  {newUserForm.role === 'student' && (
                    <div>
                      <label className="block text-xs font-bold text-stone-700 mb-1">
                        Mã định danh học sinh
                      </label>
                      <input
                        type="text"
                        value={newUserForm.studentCode}
                        onChange={(e) => setNewUserForm({ ...newUserForm, studentCode: e.target.value })}
                        placeholder="VD: VVK-10025 (Tự sinh nếu trống)"
                        className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono"
                      />
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Email liên hệ
                  </label>
                  <input
                    type="email"
                    value={newUserForm.email}
                    onChange={(e) => setNewUserForm({ ...newUserForm, email: e.target.value })}
                    placeholder="VD: user@vovaki.edu.vn"
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Số điện thoại
                  </label>
                  <input
                    type="tel"
                    value={newUserForm.phone}
                    onChange={(e) => setNewUserForm({ ...newUserForm, phone: e.target.value })}
                    placeholder="VD: 0912 345 678"
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium text-stone-600 hover:bg-stone-50"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-5 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs"
                >
                  {isProcessing ? 'Đang cấp tài khoản...' : 'Hoàn tất & Cấp tài khoản'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Edit User */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-stone-200 overflow-hidden">
            <div className="px-6 py-4 bg-stone-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Edit2 className="w-5 h-5 text-purple-400" />
                <h3 className="font-bold text-base">Chỉnh sửa Tài khoản: {editingUser.fullName}</h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="p-1 rounded-lg hover:bg-stone-800 text-stone-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Họ và Tên
                </label>
                <input
                  type="text"
                  required
                  value={editingUser.fullName}
                  onChange={(e) => setEditingUser({ ...editingUser, fullName: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Vai trò
                  </label>
                  <select
                    value={editingUser.role}
                    onChange={(e) => setEditingUser({ ...editingUser, role: e.target.value as UserRole })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-medium"
                  >
                    <option value="student">Học sinh</option>
                    <option value="homeroom">GV Chủ nhiệm</option>
                    <option value="counselor">GV Tư vấn Tâm lý</option>
                    <option value="admin">Quản trị viên</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Lớp phụ trách / Lớp học
                  </label>
                  <input
                    type="text"
                    value={editingUser.classId || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, classId: e.target.value })}
                    placeholder="VD: 10A1, 11B2"
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={editingUser.email || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Số điện thoại
                  </label>
                  <input
                    type="tel"
                    value={editingUser.phone || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Đường dẫn ảnh đại diện (Avatar URL)
                </label>
                <input
                  type="url"
                  value={editingUser.avatar || ''}
                  onChange={(e) => setEditingUser({ ...editingUser, avatar: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono"
                />
              </div>

              <div className="pt-3 flex justify-end gap-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium text-stone-600 hover:bg-stone-50"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-5 py-2 rounded-lg bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs"
                >
                  Lưu thay đổi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 3: Reset Password */}
      {resetPasswordUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-stone-200 overflow-hidden">
            <div className="px-6 py-4 bg-amber-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <KeyRound className="w-5 h-5" />
                <h3 className="font-bold text-base">Đổi Mật khẩu</h3>
              </div>
              <button
                type="button"
                onClick={() => setResetPasswordUser(null)}
                className="p-1 rounded-lg hover:bg-amber-700 text-amber-100 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleResetPasswordSubmit} className="p-6 space-y-4">
              <p className="text-xs text-stone-600">
                Bạn đang thiết lập mật khẩu mới cho tài khoản{' '}
                <strong className="text-stone-900">{resetPasswordUser.fullName}</strong> (
                <code className="bg-stone-100 px-1.5 py-0.5 rounded text-amber-700 font-bold">
                  {resetPasswordUser.username}
                </code>
                ).
              </p>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Mật khẩu mới
                </label>
                <input
                  type="text"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Nhập mật khẩu mới..."
                  className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-sm font-mono focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setResetPasswordUser(null)}
                  className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-5 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs"
                >
                  Xác nhận Đổi mật khẩu
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 4: Confirm Delete */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-stone-200 overflow-hidden">
            <div className="px-6 py-4 bg-red-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5" />
                <h3 className="font-bold text-base">Xác nhận Xóa Tài khoản</h3>
              </div>
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="p-1 rounded-lg hover:bg-red-700 text-red-100 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-xs text-stone-700 leading-relaxed">
                Bạn có chắc chắn muốn xóa vĩnh viễn tài khoản của{' '}
                <strong className="text-red-600">{userToDelete.fullName}</strong> (Tên đăng nhập:{' '}
                <code>{userToDelete.username}</code>, Vai trò: {userToDelete.role}) khỏi cơ sở dữ liệu?
              </p>
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
                Hành động này không thể hoàn tác và sẽ ghi nhật ký vào hệ thống kiểm tra bảo mật.
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setUserToDelete(null)}
                  className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium"
                >
                  Hủy bỏ
                </button>
                <button
                  type="button"
                  onClick={confirmDelete}
                  disabled={isProcessing}
                  className="px-5 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-xs"
                >
                  {isProcessing ? 'Đang xóa...' : 'Xóa vĩnh viễn'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
