import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  Brain,
  MessageSquareHeart,
  Bot,
  FileText,
  LayoutTemplate,
  Bell,
  Database,
  ShieldCheck,
  Settings,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  TrendingUp,
  Activity,
  HeartHandshake,
  Radio,
  Server,
  Sparkles,
} from 'lucide-react';

interface AdminOverviewProps {
  onNavigate: (category: string, subItem?: string) => void;
}

export const AdminOverview: React.FC<AdminOverviewProps> = ({ onNavigate }) => {
  const { state, currentUser } = useApp();

  const totalUsers = state.users?.length || 0;
  const studentsCount = state.users?.filter((u) => u.role === 'student').length || 0;
  const teachersCount = state.users?.filter((u) => u.role === 'homeroom').length || 0;
  const counselorsCount = state.users?.filter((u) => u.role === 'counselor').length || 0;

  const totalRecords = state.studentRecords?.length || 0;
  const normalRecords = state.studentRecords?.filter((r) => r.status === 'Bình thường').length || 0;
  const attentionRecords = state.studentRecords?.filter((r) => r.status === 'Cần lưu ý').length || 0;
  const highRiskRecords = state.studentRecords?.filter((r) => r.status === 'Cần đặc biệt lưu ý').length || 0;

  const totalBookings = state.bookings?.length || 0;
  const pendingBookings = state.bookings?.filter((b) => b.status === 'pending').length || 0;
  const completedBookings = state.bookings?.filter((b) => b.status === 'completed').length || 0;

  const emergencySessions = state.emergencySessions?.length || 0;
  const activeEmergencies = state.emergencySessions?.filter((e) => e.status === 'active').length || 0;

  const positiveSessions = state.positiveRoomSessions?.length || 0;
  const totalSubmissions = state.testSubmissions?.length || 0;
  const totalArticles = state.articles?.length || 0;
  const totalTests = state.psychologicalTests?.length || 0;
  const totalSentiments = state.sentimentAnalyses?.length || 0;

  const isBroadcastActive = state.realtimeSettings?.broadcastAlert?.active;

  return (
    <div className="space-y-6">
      {/* High Alert Banner if emergency active */}
      {activeEmergencies > 0 && (
        <div className="bg-red-500 text-white p-4 rounded-2xl shadow-md flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 shrink-0" />
            <div>
              <p className="font-bold text-sm">Cảnh báo: Có {activeEmergencies} phiên tư vấn SOS khẩn cấp đang cần can thiệp!</p>
              <p className="text-xs text-red-100">Học sinh đang cần hỗ trợ tâm lý ngay lập tức.</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('counseling', 'counseling_emergency')}
            className="px-4 py-2 bg-white text-red-700 hover:bg-red-50 font-bold text-xs rounded-xl shadow-xs transition-colors"
          >
            Mở phiên khẩn cấp ngay
          </button>
        </div>
      )}

      {/* Top Welcome Banner */}
      <div className="bg-gradient-to-r from-stone-900 via-stone-800 to-purple-950 text-white rounded-3xl p-6 sm:p-8 shadow-sm border border-stone-800 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 space-y-3 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-400/20 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-purple-300" />
            <span>Trung tâm Điều hành Toàn trường • Phiên bản 3.0</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Xin chào, {currentUser?.fullName || 'Quản trị viên'}
          </h1>
          <p className="text-stone-300 text-xs sm:text-sm leading-relaxed">
            Hệ thống đang bảo vệ sức khỏe tâm thần cho <strong>{studentsCount}</strong> học sinh, kết nối <strong>{counselorsCount}</strong> chuyên gia tư vấn và <strong>{teachersCount}</strong> giáo viên chủ nhiệm. Toàn bộ cơ sở dữ liệu và AI trợ lý đang vận hành ổn định.
          </p>
          <div className="pt-2 flex flex-wrap gap-2.5">
            <button
              type="button"
              onClick={() => onNavigate('psychology', 'psych_alerts')}
              className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition-all flex items-center gap-1.5 shadow-xs"
            >
              <Brain className="w-3.5 h-3.5" />
              <span>Xem cảnh báo rủi ro ({highRiskRecords})</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('builder', 'builder_pages')}
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs transition-all flex items-center gap-1.5 backdrop-blur-xs"
            >
              <LayoutTemplate className="w-3.5 h-3.5" />
              <span>Tùy biến Website</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('ai', 'ai_config')}
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs transition-all flex items-center gap-1.5 backdrop-blur-xs"
            >
              <Bot className="w-3.5 h-3.5" />
              <span>Cấu hình AI Trợ lý</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Users */}
        <div
          onClick={() => onNavigate('users', 'users_students')}
          className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs hover:shadow-md hover:border-purple-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="p-2.5 rounded-xl bg-purple-50 text-purple-700 group-hover:scale-110 transition-transform">
              <Users className="w-5 h-5" />
            </span>
            <ArrowUpRight className="w-4 h-4 text-stone-400 group-hover:text-purple-600 transition-colors" />
          </div>
          <div className="text-2xl font-black text-stone-900">{totalUsers}</div>
          <div className="text-xs font-bold text-stone-700 mt-0.5">Tổng người dùng</div>
          <div className="text-[11px] text-stone-500 mt-1 flex items-center gap-1">
            <span>{studentsCount} Học sinh</span> • <span>{counselorsCount} GV tư vấn</span>
          </div>
        </div>

        {/* Card 2: Mental Health & Risk */}
        <div
          onClick={() => onNavigate('psychology', 'psych_records')}
          className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs hover:shadow-md hover:border-emerald-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700 group-hover:scale-110 transition-transform">
              <Brain className="w-5 h-5" />
            </span>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${highRiskRecords > 0 ? 'bg-red-100 text-red-700' : 'bg-emerald-100 text-emerald-700'}`}>
              {highRiskRecords > 0 ? `${highRiskRecords} Cần chú ý` : 'An toàn'}
            </span>
          </div>
          <div className="text-2xl font-black text-stone-900">{totalRecords}</div>
          <div className="text-xs font-bold text-stone-700 mt-0.5">Hồ sơ tâm lý học sinh</div>
          <div className="text-[11px] text-stone-500 mt-1">
            {normalRecords} bình thường • {attentionRecords} cần lưu ý
          </div>
        </div>

        {/* Card 3: Counseling Bookings */}
        <div
          onClick={() => onNavigate('counseling', 'counseling_bookings')}
          className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs hover:shadow-md hover:border-blue-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="p-2.5 rounded-xl bg-blue-50 text-blue-700 group-hover:scale-110 transition-transform">
              <MessageSquareHeart className="w-5 h-5" />
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-700">
              {pendingBookings} Chờ duyệt
            </span>
          </div>
          <div className="text-2xl font-black text-stone-900">{totalBookings}</div>
          <div className="text-xs font-bold text-stone-700 mt-0.5">Lịch hẹn tư vấn 1-1</div>
          <div className="text-[11px] text-stone-500 mt-1">
            {completedBookings} Đã hoàn thành • {positiveSessions} Phòng tích cực
          </div>
        </div>

        {/* Card 4: Tests & Submissions */}
        <div
          onClick={() => onNavigate('psychology', 'psych_results')}
          className="bg-white p-5 rounded-2xl border border-stone-200 shadow-2xs hover:shadow-md hover:border-amber-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="p-2.5 rounded-xl bg-amber-50 text-amber-700 group-hover:scale-110 transition-transform">
              <Activity className="w-5 h-5" />
            </span>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">
              {totalTests} Bộ đề
            </span>
          </div>
          <div className="text-2xl font-black text-stone-900">{totalSubmissions}</div>
          <div className="text-xs font-bold text-stone-700 mt-0.5">Lượt làm trắc nghiệm</div>
          <div className="text-[11px] text-stone-500 mt-1">
            DASS-21, MBTI & RIASEC toàn trường
          </div>
        </div>
      </div>

      {/* Two Columns: Mental Health Status & Quick Action Shortcuts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Mental Health Distribution & Real-time Status */}
        <div className="lg:col-span-2 space-y-6">
          {/* Mental Health Distribution Card */}
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-2xs space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
                  <HeartHandshake className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm sm:text-base">
                    Phân bổ Sức khỏe Tâm thần Học sinh Toàn trường
                  </h3>
                  <p className="text-xs text-stone-500">
                    Dữ liệu tổng hợp từ kết quả DASS-21 và hồ sơ theo dõi định kỳ
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('psychology', 'psych_stats')}
                className="text-xs font-bold text-purple-700 hover:text-purple-800 flex items-center gap-1"
              >
                <span>Xem chi tiết</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Progress Visual Bar */}
            <div className="space-y-2">
              <div className="h-4 w-full bg-stone-100 rounded-full overflow-hidden flex shadow-inner">
                <div
                  style={{ width: `${totalRecords ? (normalRecords / totalRecords) * 100 : 70}%` }}
                  className="bg-emerald-500 h-full transition-all duration-500"
                  title="Bình thường"
                />
                <div
                  style={{ width: `${totalRecords ? (attentionRecords / totalRecords) * 100 : 20}%` }}
                  className="bg-amber-500 h-full transition-all duration-500"
                  title="Cần lưu ý"
                />
                <div
                  style={{ width: `${totalRecords ? (highRiskRecords / totalRecords) * 100 : 10}%` }}
                  className="bg-red-500 h-full transition-all duration-500"
                  title="Cần đặc biệt lưu ý"
                />
              </div>

              <div className="grid grid-cols-3 gap-2 pt-2">
                <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-100 text-center">
                  <div className="text-xs font-semibold text-emerald-700 flex items-center justify-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span>Bình thường</span>
                  </div>
                  <div className="text-lg font-extrabold text-emerald-900 mt-1">
                    {normalRecords}{' '}
                    <span className="text-[11px] font-normal text-emerald-700">
                      ({totalRecords ? Math.round((normalRecords / totalRecords) * 100) : 0}%)
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-100 text-center">
                  <div className="text-xs font-semibold text-amber-700 flex items-center justify-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    <span>Cần lưu ý</span>
                  </div>
                  <div className="text-lg font-extrabold text-amber-900 mt-1">
                    {attentionRecords}{' '}
                    <span className="text-[11px] font-normal text-amber-700">
                      ({totalRecords ? Math.round((attentionRecords / totalRecords) * 100) : 0}%)
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-red-50/70 border border-red-100 text-center">
                  <div className="text-xs font-semibold text-red-700 flex items-center justify-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-red-500" />
                    <span>Đặc biệt lưu ý</span>
                  </div>
                  <div className="text-lg font-extrabold text-red-900 mt-1">
                    {highRiskRecords}{' '}
                    <span className="text-[11px] font-normal text-red-700">
                      ({totalRecords ? Math.round((highRiskRecords / totalRecords) * 100) : 0}%)
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent High Risk Callout */}
            {highRiskRecords > 0 && (
              <div className="p-4 rounded-2xl bg-red-50 border border-red-200 flex items-start justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <p className="text-xs font-bold text-red-900">
                      Có {highRiskRecords} học sinh đang được gắn cờ theo dõi sát sao
                    </p>
                    <p className="text-[11px] text-red-700">
                      Chuyên viên tâm lý và GVCN đã thiết lập kế hoạch đồng hành từng tuần.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onNavigate('psychology', 'psych_alerts')}
                  className="text-xs font-bold text-red-800 underline shrink-0 hover:text-red-900"
                >
                  Xem danh sách
                </button>
              </div>
            )}
          </div>

          {/* Recent Counseling Activities */}
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-stone-500" />
                <h3 className="font-bold text-stone-900 text-sm">
                  Lịch hẹn & Hoạt động Tư vấn Gần đây
                </h3>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('counseling', 'counseling_bookings')}
                className="text-xs font-bold text-purple-700 hover:text-purple-800"
              >
                Tất cả lịch hẹn
              </button>
            </div>

            <div className="divide-y divide-stone-100">
              {state.bookings?.slice(0, 4).map((booking) => (
                <div key={booking.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-50 text-blue-700 flex items-center justify-center font-bold text-xs">
                      {booking.nickname ? booking.nickname.substring(0, 1).toUpperCase() : 'H'}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-stone-800">
                        {booking.nickname || 'Học sinh ẩn danh'} ({booking.studentAnonymousCode})
                      </p>
                      <p className="text-[11px] text-stone-500">
                        Chủ đề: {booking.topic} • {booking.date} ({booking.timeSlot})
                      </p>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                      booking.status === 'confirmed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : booking.status === 'completed'
                        ? 'bg-stone-100 text-stone-700'
                        : booking.status === 'in_progress'
                        ? 'bg-purple-100 text-purple-800 animate-pulse'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {booking.status === 'confirmed'
                      ? 'Đã duyệt'
                      : booking.status === 'completed'
                      ? 'Đã xong'
                      : booking.status === 'in_progress'
                      ? 'Đang tư vấn'
                      : 'Chờ duyệt'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: System Services Status & Quick Navigation Tree */}
        <div className="space-y-6">
          {/* System Services Status */}
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
                <Server className="w-4 h-4 text-purple-600" />
                <span>Trạng thái Dịch vụ</span>
              </h3>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            </div>

            <div className="space-y-2.5">
              <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-semibold text-stone-700">Cơ sở dữ liệu (JSON Store)</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                  Hoạt động
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-semibold text-stone-700">Gemini AI Model</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-purple-100 text-purple-800">
                  Sẵn sàng
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Radio className={`w-4 h-4 ${isBroadcastActive ? 'text-red-600 animate-pulse' : 'text-emerald-600'}`} />
                  <span className="text-xs font-semibold text-stone-700">Hệ thống Phát sóng & Alert</span>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${isBroadcastActive ? 'bg-red-100 text-red-800' : 'bg-stone-200 text-stone-700'}`}>
                  {isBroadcastActive ? 'Đang phát sóng' : 'Chờ lệnh'}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-semibold text-stone-700">Bảo mật & Mã hóa danh tính</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                  Bật
                </span>
              </div>
            </div>
          </div>

          {/* Quick Shortcuts to Admin Tree */}
          <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-2xs space-y-3">
            <h3 className="font-bold text-stone-900 text-sm">Thao tác Nhanh</h3>
            <div className="grid grid-cols-1 gap-2">
              <button
                type="button"
                onClick={() => onNavigate('users', 'users_accounts')}
                className="w-full text-left p-3 rounded-2xl bg-stone-50 hover:bg-purple-50 hover:border-purple-200 border border-stone-200 text-xs font-semibold text-stone-800 transition-all flex items-center justify-between group"
              >
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-purple-600" />
                  <span>Cấp tài khoản người dùng mới</span>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-stone-400 group-hover:text-purple-600" />
              </button>

              <button
                type="button"
                onClick={() => onNavigate('content', 'content_articles')}
                className="w-full text-left p-3 rounded-2xl bg-stone-50 hover:bg-emerald-50 hover:border-emerald-200 border border-stone-200 text-xs font-semibold text-stone-800 transition-all flex items-center justify-between group"
              >
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-emerald-600" />
                  <span>Đăng bài viết mới lên Trang chủ</span>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-stone-400 group-hover:text-emerald-600" />
              </button>

              <button
                type="button"
                onClick={() => onNavigate('notifications')}
                className="w-full text-left p-3 rounded-2xl bg-stone-50 hover:bg-red-50 hover:border-red-200 border border-stone-200 text-xs font-semibold text-stone-800 transition-all flex items-center justify-between group"
              >
                <div className="flex items-center gap-2">
                  <Bell className="w-4 h-4 text-red-600" />
                  <span>Phát thông báo khẩn toàn trường</span>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-stone-400 group-hover:text-red-600" />
              </button>

              <button
                type="button"
                onClick={() => onNavigate('database')}
                className="w-full text-left p-3 rounded-2xl bg-stone-50 hover:bg-blue-50 hover:border-blue-200 border border-stone-200 text-xs font-semibold text-stone-800 transition-all flex items-center justify-between group"
              >
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4 text-blue-600" />
                  <span>Sao lưu & Tải backup CSDL</span>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-stone-400 group-hover:text-blue-600" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
