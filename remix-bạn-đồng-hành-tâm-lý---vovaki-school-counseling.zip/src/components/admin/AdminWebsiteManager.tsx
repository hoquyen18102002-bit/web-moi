import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  DynamicWebsiteConfig,
  DynamicPage,
  ThemeDesignSystem,
  HeaderConfig,
  FooterConfig,
  NavMenuItem,
  PageSection,
  PageBlock,
  BlockType,
} from '../../types/pageBuilder';
import { BlockEditorModal } from '../pageBuilder/BlockEditorModal';
import { SectionEditorModal } from '../pageBuilder/SectionEditorModal';
import { DynamicPageRenderer } from '../pageBuilder/DynamicPageRenderer';
import { DynamicHeader } from '../pageBuilder/DynamicHeader';
import { DynamicFooter } from '../pageBuilder/DynamicFooter';
import {
  Palette,
  Layout,
  Navigation,
  FileText,
  History,
  Eye,
  Save,
  Plus,
  Trash2,
  Edit,
  RotateCcw,
  Check,
  Sparkles,
  Sliders,
  Maximize2,
  RefreshCw,
  ExternalLink,
  Layers,
  Smartphone,
  Monitor,
  Tablet,
  CheckCircle2,
  AlertCircle,
  GripVertical,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Share2,
  Phone,
  Mail,
  MapPin,
  Clock,
  Move,
  Copy,
  BookOpen,
} from 'lucide-react';
import { CounselorArticleManager } from '../counselor/CounselorArticleManager';

interface AdminWebsiteManagerProps {
  initialSubTab?: 'pages' | 'theme' | 'header' | 'footer' | 'menu' | 'articles' | 'versions' | 'preview' | 'components';
}

export const AdminWebsiteManager: React.FC<AdminWebsiteManagerProps> = ({
  initialSubTab = 'pages',
}) => {
  const { state, currentUser, publishWebsiteConfig, rollbackWebsiteVersion, updateWebsiteTheme } = useApp();
  const rawConfig = state.dynamicWebsite;

  // Local draft state for non-destructive live editing & previewing
  const [draftConfig, setDraftConfig] = useState<DynamicWebsiteConfig>(() =>
    JSON.parse(JSON.stringify(rawConfig || {}))
  );

  // Active Admin Sub-tab
  const [activeTab, setActiveTab] = useState<
    'pages' | 'theme' | 'header' | 'footer' | 'menu' | 'articles' | 'versions' | 'preview'
  >(initialSubTab === 'components' ? 'pages' : (initialSubTab as any) || 'pages');

  React.useEffect(() => {
    if (initialSubTab) {
      if (initialSubTab === 'components') {
        setActiveTab('pages');
      } else {
        setActiveTab(initialSubTab as any);
      }
    }
  }, [initialSubTab]);

  // Preview device mode
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');

  // Page selection
  const [selectedPageId, setSelectedPageId] = useState<string>(
    draftConfig?.pages?.[0]?.id || 'page-home'
  );

  // Active editing modal targets
  const [editingBlock, setEditingBlock] = useState<PageBlock | null>(null);
  const [editingSection, setEditingSection] = useState<PageSection | null>(null);
  const [activeSectionIdForNewBlock, setActiveSectionIdForNewBlock] = useState<string | null>(null);

  // Publish / Versioning state
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishMessage, setPublishMessage] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const currentPage = draftConfig.pages.find((p) => p.id === selectedPageId) || draftConfig.pages[0];

  // --- Handlers for Page Sections & Blocks ---
  const handleSaveSection = (updatedSection: PageSection) => {
    setDraftConfig((prev) => {
      const updatedPages = prev.pages.map((p) => {
        if (p.id !== selectedPageId) return p;
        return {
          ...p,
          sections: p.sections.map((s) => (s.id === updatedSection.id ? updatedSection : s)),
        };
      });
      return { ...prev, pages: updatedPages };
    });
    setEditingSection(null);
    showToast('Đã cập nhật Section thành công');
  };

  const handleDeleteSection = (sectionId: string) => {
    if (!window.confirm('Bạn có chắc muốn xóa phần bố cục (section) này?')) return;
    setDraftConfig((prev) => {
      const updatedPages = prev.pages.map((p) => {
        if (p.id !== selectedPageId) return p;
        return {
          ...p,
          sections: p.sections.filter((s) => s.id !== sectionId),
        };
      });
      return { ...prev, pages: updatedPages };
    });
    setEditingSection(null);
    showToast('Đã xóa Section');
  };

  const handleMoveSection = (sectionId: string, direction: 'up' | 'down') => {
    setDraftConfig((prev) => {
      const updatedPages = prev.pages.map((p) => {
        if (p.id !== selectedPageId) return p;
        const index = p.sections.findIndex((s) => s.id === sectionId);
        if (index === -1) return p;
        if (direction === 'up' && index === 0) return p;
        if (direction === 'down' && index === p.sections.length - 1) return p;

        const targetIndex = direction === 'up' ? index - 1 : index + 1;
        const newSections = [...p.sections];
        const temp = newSections[index];
        newSections[index] = newSections[targetIndex];
        newSections[targetIndex] = temp;

        return { ...p, sections: newSections };
      });
      return { ...prev, pages: updatedPages };
    });
  };

  const handleAddNewSection = () => {
    const newSec: PageSection = {
      id: `sec-${Date.now()}`,
      name: `Phần nội dung mới #${currentPage.sections.length + 1}`,
      layout: '1-col',
      fullWidth: false,
      paddingTop: 8,
      paddingBottom: 8,
      backgroundColor: '#ffffff',
      isVisible: true,
      blocks: [
        {
          id: `blk-${Date.now()}`,
          type: 'heading',
          title: 'Tiêu đề mới',
          content: {
            text: 'Tiêu đề khối nội dung mới',
            subText: 'Đoạn mô tả chi tiết của khối này. Bạn có thể chỉnh sửa tự do bằng cách nhấn vào nút chỉnh sửa.',
            alignment: 'center',
          },
          style: {
            fontSize: '2xl',
            fontWeight: 'bold',
            paddingY: 2,
          },
          isVisible: true,
        },
      ],
    };

    setDraftConfig((prev) => {
      const updatedPages = prev.pages.map((p) => {
        if (p.id !== selectedPageId) return p;
        return { ...p, sections: [...p.sections, newSec] };
      });
      return { ...prev, pages: updatedPages };
    });
    showToast('Đã thêm một Section mới');
  };

  // --- Handlers for Blocks ---
  const handleSaveBlock = (updatedBlock: PageBlock) => {
    setDraftConfig((prev) => {
      const updatedPages = prev.pages.map((p) => {
        if (p.id !== selectedPageId) return p;
        return {
          ...p,
          sections: p.sections.map((s) => ({
            ...s,
            blocks: s.blocks.map((b) => (b.id === updatedBlock.id ? updatedBlock : b)),
          })),
        };
      });
      return { ...prev, pages: updatedPages };
    });
    setEditingBlock(null);
    showToast('Đã lưu cấu hình khối');
  };

  const handleDeleteBlock = (blockId: string) => {
    if (!window.confirm('Bạn có chắc muốn xóa khối này?')) return;
    setDraftConfig((prev) => {
      const updatedPages = prev.pages.map((p) => {
        if (p.id !== selectedPageId) return p;
        return {
          ...p,
          sections: p.sections.map((s) => ({
            ...s,
            blocks: s.blocks.filter((b) => b.id !== blockId),
          })),
        };
      });
      return { ...prev, pages: updatedPages };
    });
    setEditingBlock(null);
    showToast('Đã xóa khối');
  };

  const handleMoveBlock = (blockId: string, direction: 'up' | 'down') => {
    setDraftConfig((prev) => {
      const updatedPages = prev.pages.map((p) => {
        if (p.id !== selectedPageId) return p;
        return {
          ...p,
          sections: p.sections.map((s) => {
            const index = s.blocks.findIndex((b) => b.id === blockId);
            if (index === -1) return s;
            if (direction === 'up' && index === 0) return s;
            if (direction === 'down' && index === s.blocks.length - 1) return s;

            const targetIndex = direction === 'up' ? index - 1 : index + 1;
            const newBlocks = [...s.blocks];
            const temp = newBlocks[index];
            newBlocks[index] = newBlocks[targetIndex];
            newBlocks[targetIndex] = temp;

            return { ...s, blocks: newBlocks };
          }),
        };
      });
      return { ...prev, pages: updatedPages };
    });
  };

  const handleDuplicateBlock = (blockId: string) => {
    setDraftConfig((prev) => {
      const updatedPages = prev.pages.map((p) => {
        if (p.id !== selectedPageId) return p;
        return {
          ...p,
          sections: p.sections.map((s) => {
            const blockToDup = s.blocks.find((b) => b.id === blockId);
            if (!blockToDup) return s;

            const duplicated: PageBlock = {
              ...JSON.parse(JSON.stringify(blockToDup)),
              id: `blk-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              title: `${blockToDup.title || blockToDup.type} (Bản sao)`,
            };

            const index = s.blocks.findIndex((b) => b.id === blockId);
            const newBlocks = [...s.blocks];
            newBlocks.splice(index + 1, 0, duplicated);

            return { ...s, blocks: newBlocks };
          }),
        };
      });
      return { ...prev, pages: updatedPages };
    });
    showToast('Đã nhân bản khối');
  };

  const handleAddBlockToSection = (sectionId: string, type: BlockType = 'paragraph') => {
    const newBlock: PageBlock = {
      id: `blk-${Date.now()}`,
      type,
      title: 'Khối nội dung mới',
      content: {
        text: type === 'heading' ? 'Tiêu đề mới' : 'Nội dung văn bản mới được thêm vào bố cục.',
        subText: 'Mô tả chi tiết bổ sung',
        alignment: 'left',
      },
      style: {
        fontSize: type === 'heading' ? 'xl' : 'base',
        textColor: draftConfig.theme.textColor,
        borderRadius: 'xl',
      },
      isVisible: true,
    };

    setDraftConfig((prev) => {
      const updatedPages = prev.pages.map((p) => {
        if (p.id !== selectedPageId) return p;
        return {
          ...p,
          sections: p.sections.map((s) => (s.id === sectionId ? { ...s, blocks: [...s.blocks, newBlock] } : s)),
        };
      });
      return { ...prev, pages: updatedPages };
    });
    setActiveSectionIdForNewBlock(null);
    setEditingBlock(newBlock);
  };

  // --- Publish Changes & Version Control ---
  const handlePublish = async () => {
    setIsPublishing(true);
    const summary = publishMessage.trim() || 'Cập nhật giao diện động từ Administrator';
    const res = await publishWebsiteConfig(draftConfig, summary);
    setIsPublishing(false);
    if (res.success) {
      setPublishMessage('');
      showToast('Đã xuất bản thành công! Website đã được cập nhật trực tiếp theo bố cục mới.');
    } else {
      alert('Lỗi khi xuất bản: ' + res.error);
    }
  };

  const handleRollback = async (verId: string) => {
    if (!window.confirm('Khôi phục website về phiên bản lịch sử này?')) return;
    const res = await rollbackWebsiteVersion(verId);
    if (res.success) {
      if (res.restoredVersion?.snapshot) {
        setDraftConfig((prev) => ({
          ...prev,
          ...res.restoredVersion.snapshot,
          activePageId: prev.activePageId || 'page-home',
        }));
      }
      showToast('Đã khôi phục thành công về phiên bản lịch sử được chọn');
    } else {
      alert('Lỗi: ' + res.error);
    }
  };

  // Drag & Drop State for Website Structure Page Builder
  const [draggedSectionIndex, setDraggedSectionIndex] = useState<number | null>(null);
  const [dragOverSectionIndex, setDragOverSectionIndex] = useState<number | null>(null);
  const [draggedBlockInfo, setDraggedBlockInfo] = useState<{ sectionId: string; blockIndex: number } | null>(null);
  const [dragOverBlockInfo, setDragOverBlockInfo] = useState<{ sectionId: string; blockIndex: number } | null>(null);
  const [structureViewMode, setStructureViewMode] = useState<'canvas' | 'tree' | 'split'>('split');

  const handleDragSectionStart = (e: React.DragEvent, index: number) => {
    e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'section', index }));
    e.dataTransfer.effectAllowed = 'move';
    setDraggedSectionIndex(index);
  };

  const handleDragSectionOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverSectionIndex !== index) {
      setDragOverSectionIndex(index);
    }
  };

  const handleDropSection = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    setDragOverSectionIndex(null);
    if (draggedSectionIndex === null || draggedSectionIndex === targetIndex) {
      setDraggedSectionIndex(null);
      return;
    }
    setDraftConfig((prev) => {
      const updatedPages = prev.pages.map((p) => {
        if (p.id !== selectedPageId) return p;
        const sections = [...p.sections];
        const [moved] = sections.splice(draggedSectionIndex, 1);
        sections.splice(targetIndex, 0, moved);
        return { ...p, sections };
      });
      return { ...prev, pages: updatedPages };
    });
    setDraggedSectionIndex(null);
    showToast('Đã thay đổi thứ tự Section bằng kéo thả thành công!');
  };

  const handleDragBlockStart = (e: React.DragEvent, sectionId: string, blockIndex: number) => {
    e.stopPropagation();
    e.dataTransfer.setData('text/plain', JSON.stringify({ type: 'block', sectionId, blockIndex }));
    e.dataTransfer.effectAllowed = 'move';
    setDraggedBlockInfo({ sectionId, blockIndex });
  };

  const handleDragBlockOver = (e: React.DragEvent, sectionId: string, blockIndex: number) => {
    e.preventDefault();
    e.stopPropagation();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverBlockInfo?.sectionId !== sectionId || dragOverBlockInfo?.blockIndex !== blockIndex) {
      setDragOverBlockInfo({ sectionId, blockIndex });
    }
  };

  const handleDropBlock = (e: React.DragEvent, targetSectionId: string, targetBlockIndex: number) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverBlockInfo(null);
    if (!draggedBlockInfo) return;
    const { sectionId: srcSecId, blockIndex: srcBlkIdx } = draggedBlockInfo;

    setDraftConfig((prev) => {
      const updatedPages = prev.pages.map((p) => {
        if (p.id !== selectedPageId) return p;
        const newSections = p.sections.map((sec) => ({
          ...sec,
          blocks: [...sec.blocks],
        }));

        const srcSec = newSections.find((s) => s.id === srcSecId);
        const targetSec = newSections.find((s) => s.id === targetSectionId);
        if (!srcSec || !targetSec) return p;

        const [movedBlock] = srcSec.blocks.splice(srcBlkIdx, 1);
        targetSec.blocks.splice(targetBlockIndex, 0, movedBlock);

        return { ...p, sections: newSections };
      });
      return { ...prev, pages: updatedPages };
    });

    setDraggedBlockInfo(null);
    showToast('Đã kéo thả di chuyển khối nội dung (Block) thành công!');
  };

  // --- Footer Management Handlers ---
  const handleAddFooterColumn = () => {
    const newCol = {
      id: `col-${Date.now()}`,
      title: `Cột thông tin #${draftConfig.footer.columns.length + 1}`,
      content: 'Thông tin bổ sung hoặc giới thiệu phòng tư vấn.',
      links: [
        { id: `link-${Date.now()}-1`, label: 'Trang chủ', url: '#home' },
        { id: `link-${Date.now()}-2`, label: 'Phòng tích cực', url: '#positive_room' },
      ],
    };
    setDraftConfig((prev) => ({
      ...prev,
      footer: {
        ...prev.footer,
        columns: [...prev.footer.columns, newCol],
      },
    }));
    showToast('Đã thêm Cột Chân Trang mới');
  };

  const handleDeleteFooterColumn = (colId: string) => {
    if (!window.confirm('Bạn có chắc chắn muốn xóa cột chân trang này?')) return;
    setDraftConfig((prev) => ({
      ...prev,
      footer: {
        ...prev.footer,
        columns: prev.footer.columns.filter((c) => c.id !== colId),
      },
    }));
    showToast('Đã xóa cột chân trang');
  };

  const handleMoveFooterColumn = (colId: string, direction: 'left' | 'right') => {
    setDraftConfig((prev) => {
      const cols = [...prev.footer.columns];
      const idx = cols.findIndex((c) => c.id === colId);
      if (idx === -1) return prev;
      if (direction === 'left' && idx === 0) return prev;
      if (direction === 'right' && idx === cols.length - 1) return prev;

      const targetIdx = direction === 'left' ? idx - 1 : idx + 1;
      const temp = cols[idx];
      cols[idx] = cols[targetIdx];
      cols[targetIdx] = temp;

      return {
        ...prev,
        footer: {
          ...prev.footer,
          columns: cols,
        },
      };
    });
  };

  const handleAddFooterLink = (colId: string) => {
    const newLink = {
      id: `link-${Date.now()}`,
      label: 'Liên kết mới',
      url: '#home',
    };
    setDraftConfig((prev) => ({
      ...prev,
      footer: {
        ...prev.footer,
        columns: prev.footer.columns.map((c) =>
          c.id === colId ? { ...c, links: [...(c.links || []), newLink] } : c
        ),
      },
    }));
  };

  const handleRemoveFooterLink = (colId: string, linkId: string) => {
    setDraftConfig((prev) => ({
      ...prev,
      footer: {
        ...prev.footer,
        columns: prev.footer.columns.map((c) =>
          c.id === colId ? { ...c, links: (c.links || []).filter((l) => l.id !== linkId) } : c
        ),
      },
    }));
  };

  const handleUpdateFooterLink = (
    colId: string,
    linkId: string,
    field: 'label' | 'url',
    val: string
  ) => {
    setDraftConfig((prev) => ({
      ...prev,
      footer: {
        ...prev.footer,
        columns: prev.footer.columns.map((c) =>
          c.id === colId
            ? {
                ...c,
                links: (c.links || []).map((l) => (l.id === linkId ? { ...l, [field]: val } : l)),
              }
            : c
        ),
      },
    }));
  };

  const handleAddSocialLink = () => {
    const newSocial = {
      id: `soc-${Date.now()}`,
      platform: 'facebook' as const,
      label: 'Fanpage Tư Vấn',
      url: 'https://facebook.com',
    };
    setDraftConfig((prev) => ({
      ...prev,
      footer: {
        ...prev.footer,
        socialLinks: [...(prev.footer.socialLinks || []), newSocial],
      },
    }));
    showToast('Đã thêm kênh kết nối');
  };

  const handleDeleteSocialLink = (socId: string) => {
    setDraftConfig((prev) => ({
      ...prev,
      footer: {
        ...prev.footer,
        socialLinks: (prev.footer.socialLinks || []).filter((s) => s.id !== socId),
      },
    }));
    showToast('Đã xóa kênh kết nối');
  };

  const handleUpdateSocialLink = (socId: string, field: string, val: string) => {
    setDraftConfig((prev) => ({
      ...prev,
      footer: {
        ...prev.footer,
        socialLinks: (prev.footer.socialLinks || []).map((s) =>
          s.id === socId ? { ...s, [field]: val } : s
        ),
      },
    }));
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Toast feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-stone-700 text-xs sm:text-sm font-semibold flex items-center gap-2 animate-slide-up">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Admin Dynamic Website Control Bar */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-purple-100 text-purple-800 border border-purple-200 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-600" />
              Dynamic CMS & Page Builder
            </span>
            <span className="text-xs text-stone-500 font-mono">
              Phiên bản #{draftConfig.versions?.[0]?.versionNumber || 1}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold text-stone-900 tracking-tight mt-1">
            Hệ Thống Quản Trị Giao Diện Động Dành Cho Administrator
          </h2>
          <p className="text-xs sm:text-sm text-stone-500 mt-1 max-w-2xl">
            Admin không cần chỉnh sửa mã nguồn vẫn có thể thay đổi giao diện, bố cục trang, menu, màu sắc, font chữ và xuất bản trực tiếp.
          </p>
        </div>

        {/* Publish Action Box */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full md:w-auto">
          <input
            type="text"
            placeholder="Tóm tắt thay đổi (VD: Cập nhật banner & màu)..."
            value={publishMessage}
            onChange={(e) => setPublishMessage(e.target.value)}
            className="px-3 py-2 rounded-xl border border-stone-300 text-xs outline-hidden focus:ring-2 focus:ring-purple-500 w-full sm:w-64"
          />
          <button
            type="button"
            disabled={isPublishing}
            onClick={handlePublish}
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 active:scale-95 text-white font-extrabold text-xs shadow-md transition-all flex items-center justify-center gap-2 shrink-0 disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{isPublishing ? 'Đang xuất bản...' : 'Xuất bản giao diện ngay'}</span>
          </button>
        </div>
      </div>

      {/* Main Admin Tab Buttons */}
      <div className="bg-white rounded-2xl p-2 border border-stone-200 shadow-xs flex flex-wrap items-center gap-1 text-xs font-bold">
        {[
          { id: 'pages', label: 'Quản lý Bố cục Trang (Page Builder)', icon: Layout },
          { id: 'theme', label: 'Màu sắc & Nhận diện (Theme)', icon: Palette },
          { id: 'header', label: 'Cấu hình Header & Logo', icon: Sliders },
          { id: 'footer', label: 'Cấu hình Chân trang (Footer)', icon: Layers },
          { id: 'menu', label: 'Menu & Điều hướng', icon: Navigation },
          { id: 'articles', label: 'Tin tức & Cẩm nang Trang chủ', icon: BookOpen },
          { id: 'versions', label: 'Lịch sử & Khôi phục (Rollback)', icon: History },
          { id: 'preview', label: 'Xem trước Trực quan (Live Preview)', icon: Eye },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 ${
                isActive
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ================= TAB 1: PAGE BUILDER ================= */}
      {activeTab === 'pages' && (
        <div className="space-y-6">
          {/* Page Selector & Mode Controls */}
          <div className="bg-white rounded-2xl p-4 border border-stone-200 flex flex-wrap items-center justify-between gap-3 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-stone-700">Trang:</span>
                <select
                  value={selectedPageId}
                  onChange={(e) => setSelectedPageId(e.target.value)}
                  className="px-3 py-1.5 rounded-xl border border-stone-300 text-xs font-bold text-stone-900 focus:ring-2 focus:ring-purple-500 outline-hidden bg-stone-50"
                >
                  {draftConfig.pages.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.title} (/{p.slug})
                    </option>
                  ))}
                </select>
              </div>

              {/* View Mode Switcher */}
              <div className="hidden sm:flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200 text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setStructureViewMode('split')}
                  className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 ${
                    structureViewMode === 'split' ? 'bg-white text-purple-700 shadow-xs' : 'text-stone-600 hover:text-stone-900'
                  }`}
                  title="Hiển thị song song Kéo thả Cấu trúc và Canvas Trực quan"
                >
                  <Move className="w-3.5 h-3.5" />
                  <span>Kéo thả + Canvas</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStructureViewMode('tree')}
                  className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 ${
                    structureViewMode === 'tree' ? 'bg-white text-purple-700 shadow-xs' : 'text-stone-600 hover:text-stone-900'
                  }`}
                  title="Chỉ hiển thị Cây cấu trúc Kéo thả"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Cây Bố Cục ({currentPage.sections.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStructureViewMode('canvas')}
                  className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 ${
                    structureViewMode === 'canvas' ? 'bg-white text-purple-700 shadow-xs' : 'text-stone-600 hover:text-stone-900'
                  }`}
                  title="Chỉ hiển thị Khung vẽ Trực quan"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Canvas</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleAddNewSection}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Thêm Section mới</span>
              </button>
            </div>
          </div>

          {/* Main Workspace Layout (Tree + Canvas) */}
          <div className={`grid gap-6 ${structureViewMode === 'split' ? 'grid-cols-1 lg:grid-cols-12' : 'grid-cols-1'}`}>
            {/* PANEL 1: INTERACTIVE DRAG & DROP STRUCTURE ORGANIZER */}
            {(structureViewMode === 'split' || structureViewMode === 'tree') && (
              <div className={`${structureViewMode === 'split' ? 'lg:col-span-5' : 'w-full'} space-y-4`}>
                <div className="bg-white rounded-3xl p-5 border border-purple-200 shadow-sm space-y-4">
                  <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-xl bg-purple-100 text-purple-700">
                        <Move className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-stone-900">
                          Kéo Thả Cấu Trúc Website
                        </h4>
                        <p className="text-[11px] text-stone-500">
                          Kéo biểu tượng tay nắm để đổi vị trí Section hoặc Block
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-purple-50 text-purple-700 border border-purple-200">
                      {currentPage.sections.length} Sections
                    </span>
                  </div>

                  {/* Drag and Drop List of Sections */}
                  <div className="space-y-3 max-h-[750px] overflow-y-auto pr-1">
                    {currentPage.sections.map((section, secIdx) => {
                      const isDragged = draggedSectionIndex === secIdx;
                      const isOver = dragOverSectionIndex === secIdx;
                      return (
                        <div
                          key={section.id}
                          draggable
                          onDragStart={(e) => handleDragSectionStart(e, secIdx)}
                          onDragOver={(e) => handleDragSectionOver(e, secIdx)}
                          onDrop={(e) => handleDropSection(e, secIdx)}
                          className={`rounded-2xl border transition-all p-3.5 space-y-2.5 ${
                            isDragged
                              ? 'opacity-40 border-purple-500 bg-purple-50 scale-95'
                              : isOver
                              ? 'border-2 border-purple-600 bg-purple-50/70 shadow-md ring-2 ring-purple-300'
                              : 'border-stone-200 bg-stone-50/70 hover:border-purple-300 hover:bg-white shadow-xs'
                          }`}
                        >
                          {/* Section Header with Drag Handle & Actions */}
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-2 min-w-0">
                              <span
                                className="cursor-grab active:cursor-grabbing p-1.5 rounded-lg text-stone-400 hover:text-purple-600 hover:bg-purple-100 transition-colors"
                                title="Giữ và kéo để đổi vị trí Section này"
                              >
                                <GripVertical className="w-4 h-4" />
                              </span>
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-[10px] font-mono font-bold uppercase px-1.5 py-0.5 rounded bg-stone-200 text-stone-700">
                                    #{secIdx + 1}
                                  </span>
                                  <span className="text-xs font-bold text-stone-800 truncate block">
                                    {section.name || `Section ${secIdx + 1}`}
                                  </span>
                                </div>
                                <span className="text-[10px] text-stone-500 font-mono">
                                  {section.layout} • {section.blocks.length} blocks
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleMoveSection(section.id, 'up')}
                                disabled={secIdx === 0}
                                className="p-1 text-stone-400 hover:text-stone-700 disabled:opacity-30 rounded hover:bg-stone-200"
                                title="Đẩy lên"
                              >
                                <ArrowUp className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleMoveSection(section.id, 'down')}
                                disabled={secIdx === currentPage.sections.length - 1}
                                className="p-1 text-stone-400 hover:text-stone-700 disabled:opacity-30 rounded hover:bg-stone-200"
                                title="Đẩy xuống"
                              >
                                <ArrowDown className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setEditingSection(section)}
                                className="p-1 text-purple-600 hover:bg-purple-100 rounded"
                                title="Cài đặt Section"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteSection(section.id)}
                                className="p-1 text-red-500 hover:bg-red-100 rounded"
                                title="Xóa Section"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          {/* Nested Draggable Blocks inside this Section */}
                          <div className="pl-6 border-l-2 border-stone-200 space-y-1.5">
                            {section.blocks.map((block, blkIdx) => {
                              const isBlockOver =
                                dragOverBlockInfo?.sectionId === section.id &&
                                dragOverBlockInfo?.blockIndex === blkIdx;
                              return (
                                <div
                                  key={block.id}
                                  draggable
                                  onDragStart={(e) => handleDragBlockStart(e, section.id, blkIdx)}
                                  onDragOver={(e) => handleDragBlockOver(e, section.id, blkIdx)}
                                  onDrop={(e) => handleDropBlock(e, section.id, blkIdx)}
                                  className={`rounded-xl px-2.5 py-1.5 flex items-center justify-between gap-2 border text-xs transition-all ${
                                    isBlockOver
                                      ? 'border-2 border-purple-500 bg-purple-100 ring-2 ring-purple-300'
                                      : 'border-stone-200 bg-white hover:border-purple-300 shadow-2xs'
                                  }`}
                                >
                                  <div className="flex items-center gap-2 min-w-0">
                                    <span
                                      className="cursor-grab active:cursor-grabbing text-stone-400 hover:text-purple-600"
                                      title="Kéo thả đổi vị trí Block"
                                    >
                                      <GripVertical className="w-3.5 h-3.5" />
                                    </span>
                                    <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 font-bold">
                                      {block.type}
                                    </span>
                                    <span className="text-xs text-stone-700 truncate max-w-[150px]">
                                      {block.title || block.content?.text || 'Khối nội dung'}
                                    </span>
                                  </div>

                                  <div className="flex items-center gap-0.5 shrink-0">
                                    <button
                                      type="button"
                                      onClick={() => handleMoveBlock(block.id, 'up')}
                                      className="p-0.5 text-stone-400 hover:text-stone-700 rounded"
                                      title="Lên"
                                    >
                                      <ArrowUp className="w-3 h-3" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleMoveBlock(block.id, 'down')}
                                      className="p-0.5 text-stone-400 hover:text-stone-700 rounded"
                                      title="Xuống"
                                    >
                                      <ArrowDown className="w-3 h-3" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => setEditingBlock(block)}
                                      className="p-0.5 text-purple-600 hover:bg-purple-50 rounded"
                                      title="Sửa Block"
                                    >
                                      <Edit className="w-3 h-3" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteBlock(block.id)}
                                      className="p-0.5 text-red-400 hover:bg-red-50 rounded"
                                      title="Xóa Block"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </button>
                                  </div>
                                </div>
                              );
                            })}

                            <button
                              type="button"
                              onClick={() => {
                                setActiveSectionIdForNewBlock(section.id);
                                handleAddBlockToSection(section.id, 'card');
                              }}
                              className="w-full py-1.5 rounded-xl border border-dashed border-stone-300 hover:border-purple-400 text-stone-500 hover:text-purple-700 text-[11px] font-bold flex items-center justify-center gap-1 transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                              <span>Thêm Block vào Section này</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* PANEL 2: VISUAL PAGE CANVAS */}
            {(structureViewMode === 'split' || structureViewMode === 'canvas') && (
              <div className={`${structureViewMode === 'split' ? 'lg:col-span-7' : 'w-full'} bg-stone-100 p-4 sm:p-6 rounded-3xl border border-stone-300`}>
                <div className="mb-4 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs text-stone-500 font-semibold">
                    <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                    <span>Khung vẽ Trực quan (Visual Canvas Preview)</span>
                  </div>
                  <span className="text-xs text-stone-400">
                    Bấm vào bút chì trên từng khối để tinh chỉnh
                  </span>
                </div>

                <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-stone-200">
                  <DynamicPageRenderer
                    page={currentPage}
                    theme={draftConfig.theme}
                    isLiveEditing={true}
                    onEditSection={(sec) => setEditingSection(sec)}
                    onDeleteSection={handleDeleteSection}
                    onMoveSection={handleMoveSection}
                    onAddBlockToSection={(secId) => {
                      setActiveSectionIdForNewBlock(secId);
                      handleAddBlockToSection(secId, 'card');
                    }}
                    onEditBlock={(blk) => setEditingBlock(blk)}
                    onDeleteBlock={handleDeleteBlock}
                    onMoveBlock={handleMoveBlock}
                    onDuplicateBlock={handleDuplicateBlock}
                    onAddNewSection={handleAddNewSection}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= TAB 2: THEME & BRANDING ================= */}
      {activeTab === 'theme' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-xs space-y-8">
          <div>
            <h3 className="text-lg font-bold text-stone-900 flex items-center gap-2">
              <Palette className="w-5 h-5 text-purple-600" />
              <span>Hệ Thống Màu Sắc & Nhận Diện Thương Hiệu Toàn Website</span>
            </h3>
            <p className="text-xs text-stone-500 mt-1">
              Thay đổi màu chủ đạo, font chữ, độ bo góc nút bấm và thẻ nội dung. Mọi trang sẽ tự động áp dụng ngay lập tức.
            </p>
          </div>

          {/* Color Palettes Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 rounded-2xl border border-stone-200 space-y-3 bg-stone-50/50">
              <label className="block text-xs font-bold text-stone-700">
                Màu sắc chủ đạo (Primary Color)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={draftConfig.theme.primaryColor}
                  onChange={(e) =>
                    setDraftConfig({
                      ...draftConfig,
                      theme: { ...draftConfig.theme, primaryColor: e.target.value },
                    })
                  }
                  className="w-12 h-12 rounded-xl border border-stone-300 cursor-pointer"
                />
                <input
                  type="text"
                  value={draftConfig.theme.primaryColor}
                  onChange={(e) =>
                    setDraftConfig({
                      ...draftConfig,
                      theme: { ...draftConfig.theme, primaryColor: e.target.value },
                    })
                  }
                  className="px-3 py-2 rounded-xl border border-stone-300 text-xs font-mono font-bold flex-1"
                />
              </div>
              <div className="flex items-center gap-1.5 pt-1">
                {['#059669', '#2563eb', '#7c3aed', '#dc2626', '#0d9488', '#ea580c'].map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() =>
                      setDraftConfig({
                        ...draftConfig,
                        theme: { ...draftConfig.theme, primaryColor: color },
                      })
                    }
                    className="w-6 h-6 rounded-full border border-stone-300 transition-transform hover:scale-110"
                    style={{ backgroundColor: color }}
                    title={color}
                  />
                ))}
              </div>
            </div>

            <div className="p-4 rounded-2xl border border-stone-200 space-y-3 bg-stone-50/50">
              <label className="block text-xs font-bold text-stone-700">
                Màu phụ trợ (Secondary Color)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={draftConfig.theme.secondaryColor}
                  onChange={(e) =>
                    setDraftConfig({
                      ...draftConfig,
                      theme: { ...draftConfig.theme, secondaryColor: e.target.value },
                    })
                  }
                  className="w-12 h-12 rounded-xl border border-stone-300 cursor-pointer"
                />
                <input
                  type="text"
                  value={draftConfig.theme.secondaryColor}
                  onChange={(e) =>
                    setDraftConfig({
                      ...draftConfig,
                      theme: { ...draftConfig.theme, secondaryColor: e.target.value },
                    })
                  }
                  className="px-3 py-2 rounded-xl border border-stone-300 text-xs font-mono font-bold flex-1"
                />
              </div>
            </div>

            <div className="p-4 rounded-2xl border border-stone-200 space-y-3 bg-stone-50/50">
              <label className="block text-xs font-bold text-stone-700">
                Màu nhấn (Accent Color)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={draftConfig.theme.accentColor}
                  onChange={(e) =>
                    setDraftConfig({
                      ...draftConfig,
                      theme: { ...draftConfig.theme, accentColor: e.target.value },
                    })
                  }
                  className="w-12 h-12 rounded-xl border border-stone-300 cursor-pointer"
                />
                <input
                  type="text"
                  value={draftConfig.theme.accentColor}
                  onChange={(e) =>
                    setDraftConfig({
                      ...draftConfig,
                      theme: { ...draftConfig.theme, accentColor: e.target.value },
                    })
                  }
                  className="px-3 py-2 rounded-xl border border-stone-300 text-xs font-mono font-bold flex-1"
                />
              </div>
            </div>
          </div>

          {/* Typography & Fonts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-stone-200">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-2">
                Font chữ nội dung toàn trang (Body Font Family)
              </label>
              <select
                value={draftConfig.theme.fontFamily}
                onChange={(e) =>
                  setDraftConfig({
                    ...draftConfig,
                    theme: { ...draftConfig.theme, fontFamily: e.target.value as any },
                  })
                }
                className="w-full px-4 py-2.5 rounded-xl border border-stone-300 text-sm font-semibold"
              >
                <option value="Be Vietnam Pro">Be Vietnam Pro (Chuẩn tiếng Việt tối ưu)</option>
                <option value="Nunito">Nunito (Thân thiện, trẻ trung cho học sinh)</option>
                <option value="Merriweather">Merriweather (Ấm áp, phong cách giáo dục)</option>
                <option value="Inter">Inter (Hiện đại, tối giản)</option>
                <option value="Roboto">Roboto (Phổ biến)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-2">
                Độ bo góc các nút bấm (Button Styling)
              </label>
              <select
                value={draftConfig.theme.buttonStyle}
                onChange={(e) =>
                  setDraftConfig({
                    ...draftConfig,
                    theme: { ...draftConfig.theme, buttonStyle: e.target.value as any },
                  })
                }
                className="w-full px-4 py-2.5 rounded-xl border border-stone-300 text-sm font-semibold"
              >
                <option value="rounded-md">Bo góc nhẹ (rounded-md - 6px)</option>
                <option value="rounded-xl">Bo tròn thanh lịch (rounded-xl - 12px)</option>
                <option value="rounded-2xl">Bo tròn mềm mại (rounded-2xl - 16px)</option>
                <option value="rounded-full">Hình viên thuốc (rounded-full)</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 3: HEADER & LOGO ================= */}
      {activeTab === 'header' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-xs space-y-6">
          <div>
            <h3 className="text-lg font-bold text-stone-900 flex items-center gap-2">
              <Sliders className="w-5 h-5 text-purple-600" />
              <span>Cấu Hình Header, Logo & Thanh Điều Hướng Trên Cùng</span>
            </h3>
            <p className="text-xs text-stone-500 mt-1">
              Admin chỉnh sửa tên trường, logo biểu tượng, chiều cao header và các nút hành động mà không đụng tới mã nguồn.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Tên thương hiệu / Tiêu đề Header (Logo Text)
              </label>
              <input
                type="text"
                value={draftConfig.header.logoText}
                onChange={(e) =>
                  setDraftConfig({
                    ...draftConfig,
                    header: { ...draftConfig.header, logoText: e.target.value },
                  })
                }
                className="w-full px-4 py-2.5 rounded-xl border border-stone-300 text-sm font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Mô tả phụ dưới tên (Logo Subtext)
              </label>
              <input
                type="text"
                value={draftConfig.header.logoSubtext || ''}
                onChange={(e) =>
                  setDraftConfig({
                    ...draftConfig,
                    header: { ...draftConfig.header, logoSubtext: e.target.value },
                  })
                }
                className="w-full px-4 py-2.5 rounded-xl border border-stone-300 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              URL Ảnh Logo / Biểu tượng (Logo Icon URL)
            </label>
            <input
              type="text"
              value={draftConfig.header.logoIconUrl || ''}
              onChange={(e) =>
                setDraftConfig({
                  ...draftConfig,
                  header: { ...draftConfig.header, logoIconUrl: e.target.value },
                })
              }
              placeholder="https://..."
              className="w-full px-4 py-2.5 rounded-xl border border-stone-300 text-xs font-mono"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-stone-200">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={draftConfig.header.isSticky}
                onChange={(e) =>
                  setDraftConfig({
                    ...draftConfig,
                    header: { ...draftConfig.header, isSticky: e.target.checked },
                  })
                }
                className="w-4 h-4 text-purple-600 rounded"
              />
              <span className="text-xs font-bold text-stone-800">Cố định Header khi cuộn (Sticky)</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={draftConfig.header.showEmergencyHotline}
                onChange={(e) =>
                  setDraftConfig({
                    ...draftConfig,
                    header: { ...draftConfig.header, showEmergencyHotline: e.target.checked },
                  })
                }
                className="w-4 h-4 text-purple-600 rounded"
              />
              <span className="text-xs font-bold text-stone-800">Hiển thị thanh Hotline trên cùng</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={draftConfig.header.showAuthButton}
                onChange={(e) =>
                  setDraftConfig({
                    ...draftConfig,
                    header: { ...draftConfig.header, showAuthButton: e.target.checked },
                  })
                }
                className="w-4 h-4 text-purple-600 rounded"
              />
              <span className="text-xs font-bold text-stone-800">Hiển thị nút Đăng nhập</span>
            </label>
          </div>
        </div>
      )}

      {/* ================= TAB 4: FOOTER ================= */}
      {activeTab === 'footer' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-xs space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-stone-100 pb-5">
              <div>
                <h3 className="text-lg font-bold text-stone-900 flex items-center gap-2">
                  <Layers className="w-5 h-5 text-purple-600" />
                  <span>Quản Lý & Cấu Hình Chân Trang (Dynamic Footer)</span>
                </h3>
                <p className="text-xs text-stone-500 mt-1">
                  Quản trị viên có toàn quyền thêm/bớt, chỉnh sửa nội dung cột, liên kết nhanh, thông tin phòng tư vấn và bản quyền chân trang.
                </p>
              </div>

              <button
                type="button"
                onClick={handleAddFooterColumn}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Thêm Cột Chân Trang Mới</span>
              </button>
            </div>

            {/* General Footer Settings */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4 rounded-2xl bg-stone-50 border border-stone-200 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Bố cục cột (Layout)</label>
                <select
                  value={draftConfig.footer.layout}
                  onChange={(e) =>
                    setDraftConfig({
                      ...draftConfig,
                      footer: { ...draftConfig.footer, layout: e.target.value as any },
                    })
                  }
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 font-semibold bg-white"
                >
                  <option value="4-col">4 Cột phân bổ đều</option>
                  <option value="3-col">3 Cột nội dung</option>
                  <option value="minimal">Tối giản (Minimal)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Màu nền Footer</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={draftConfig.footer.backgroundColor || '#1c1917'}
                    onChange={(e) =>
                      setDraftConfig({
                        ...draftConfig,
                        footer: { ...draftConfig.footer, backgroundColor: e.target.value },
                      })
                    }
                    className="w-8 h-8 rounded-lg cursor-pointer border border-stone-300 p-0.5"
                  />
                  <input
                    type="text"
                    value={draftConfig.footer.backgroundColor || '#1c1917'}
                    onChange={(e) =>
                      setDraftConfig({
                        ...draftConfig,
                        footer: { ...draftConfig.footer, backgroundColor: e.target.value },
                      })
                    }
                    className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Màu chữ Footer</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={draftConfig.footer.textColor || '#d6d3d1'}
                    onChange={(e) =>
                      setDraftConfig({
                        ...draftConfig,
                        footer: { ...draftConfig.footer, textColor: e.target.value },
                      })
                    }
                    className="w-8 h-8 rounded-lg cursor-pointer border border-stone-300 p-0.5"
                  />
                  <input
                    type="text"
                    value={draftConfig.footer.textColor || '#d6d3d1'}
                    onChange={(e) =>
                      setDraftConfig({
                        ...draftConfig,
                        footer: { ...draftConfig.footer, textColor: e.target.value },
                      })
                    }
                    className="w-full px-2.5 py-1.5 rounded-lg border border-stone-300 font-mono text-xs"
                  />
                </div>
              </div>

              <div className="flex items-end pb-1">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-stone-700">
                  <input
                    type="checkbox"
                    checked={draftConfig.footer.showBackToTop}
                    onChange={(e) =>
                      setDraftConfig({
                        ...draftConfig,
                        footer: { ...draftConfig.footer, showBackToTop: e.target.checked },
                      })
                    }
                    className="w-4 h-4 text-purple-600 rounded"
                  />
                  <span>Nút quay lại đầu trang</span>
                </label>
              </div>
            </div>

            {/* Copyright Input */}
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Dòng bản quyền chân trang (Copyright Text)
              </label>
              <input
                type="text"
                value={draftConfig.footer.copyrightText}
                onChange={(e) =>
                  setDraftConfig({
                    ...draftConfig,
                    footer: { ...draftConfig.footer, copyrightText: e.target.value },
                  })
                }
                className="w-full px-4 py-2.5 rounded-xl border border-stone-300 text-xs sm:text-sm font-medium"
              />
            </div>

            {/* ================= FOOTER COLUMNS MANAGER ================= */}
            <div className="space-y-4 pt-2">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-stone-800 flex items-center gap-2">
                  <span>Danh sách Cột Thông Tin ({draftConfig.footer.columns.length} cột)</span>
                </h4>
                <span className="text-xs text-stone-400">
                  Bạn có thể di chuyển vị trí cột sang trái/phải hoặc xóa bớt cột
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {draftConfig.footer.columns.map((col, idx) => (
                  <div
                    key={col.id}
                    className="p-5 rounded-3xl border border-stone-200 bg-stone-50/60 shadow-xs space-y-4 relative group"
                  >
                    {/* Column Top Bar */}
                    <div className="flex items-center justify-between border-b border-stone-200/80 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-full bg-purple-100 text-purple-700">
                          Cột #{idx + 1}
                        </span>
                        <span className="text-xs font-bold text-stone-700 truncate max-w-[160px]">
                          {col.title || 'Chưa đặt tiêu đề'}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleMoveFooterColumn(col.id, 'left')}
                          disabled={idx === 0}
                          className="p-1 text-stone-400 hover:text-stone-700 disabled:opacity-30 rounded hover:bg-stone-200"
                          title="Di chuyển sang trái"
                        >
                          <ArrowLeft className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleMoveFooterColumn(col.id, 'right')}
                          disabled={idx === draftConfig.footer.columns.length - 1}
                          className="p-1 text-stone-400 hover:text-stone-700 disabled:opacity-30 rounded hover:bg-stone-200"
                          title="Di chuyển sang phải"
                        >
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteFooterColumn(col.id)}
                          className="p-1 text-red-500 hover:bg-red-100 rounded"
                          title="Xóa cột này"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Column Title & Content Inputs */}
                    <div className="space-y-2">
                      <div>
                        <label className="block text-[11px] font-bold text-stone-600 mb-0.5">
                          Tiêu đề cột
                        </label>
                        <input
                          type="text"
                          value={col.title}
                          onChange={(e) => {
                            const newCols = [...draftConfig.footer.columns];
                            newCols[idx].title = e.target.value;
                            setDraftConfig({
                              ...draftConfig,
                              footer: { ...draftConfig.footer, columns: newCols },
                            });
                          }}
                          className="w-full px-3 py-1.5 rounded-xl border border-stone-300 text-xs font-bold bg-white"
                          placeholder="Ví dụ: Giới thiệu, Liên hệ khẩn cấp..."
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-stone-600 mb-0.5">
                          Nội dung mô tả / thông tin cột
                        </label>
                        <textarea
                          rows={2}
                          value={col.content || ''}
                          onChange={(e) => {
                            const newCols = [...draftConfig.footer.columns];
                            newCols[idx].content = e.target.value;
                            setDraftConfig({
                              ...draftConfig,
                              footer: { ...draftConfig.footer, columns: newCols },
                            });
                          }}
                          placeholder="Nội dung mô tả hoặc thông tin liên hệ..."
                          className="w-full px-3 py-1.5 rounded-xl border border-stone-300 text-xs bg-white leading-relaxed"
                        />
                      </div>
                    </div>

                    {/* Column Links Section */}
                    <div className="space-y-2 pt-2 border-t border-stone-200/60">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-stone-700">
                          Liên kết trong cột ({col.links?.length || 0})
                        </span>
                        <button
                          type="button"
                          onClick={() => handleAddFooterLink(col.id)}
                          className="text-[11px] font-bold text-purple-600 hover:text-purple-700 flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" />
                          <span>+ Thêm liên kết</span>
                        </button>
                      </div>

                      {(!col.links || col.links.length === 0) ? (
                        <p className="text-[11px] text-stone-400 italic">
                          Cột này chưa có liên kết nào. Nhấn "+ Thêm liên kết" ở trên để bổ sung.
                        </p>
                      ) : (
                        <div className="space-y-1.5">
                          {col.links.map((link) => (
                            <div
                              key={link.id}
                              className="flex items-center gap-1.5 bg-white p-1.5 rounded-xl border border-stone-200 text-xs"
                            >
                              <input
                                type="text"
                                value={link.label}
                                onChange={(e) =>
                                  handleUpdateFooterLink(col.id, link.id, 'label', e.target.value)
                                }
                                placeholder="Tên hiển thị"
                                className="w-2/5 px-2 py-1 rounded-lg border border-stone-200 text-xs font-medium"
                              />
                              <input
                                type="text"
                                value={link.url}
                                onChange={(e) =>
                                  handleUpdateFooterLink(col.id, link.id, 'url', e.target.value)
                                }
                                placeholder="#home, #positive_room, tel:..."
                                className="w-3/5 px-2 py-1 rounded-lg border border-stone-200 font-mono text-[11px]"
                              />
                              <button
                                type="button"
                                onClick={() => handleRemoveFooterLink(col.id, link.id)}
                                className="p-1 text-red-400 hover:text-red-600 rounded hover:bg-red-50 shrink-0"
                                title="Xóa liên kết này"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ================= SOCIAL LINKS MANAGER ================= */}
            <div className="space-y-4 pt-4 border-t border-stone-100">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                    <Share2 className="w-4 h-4 text-purple-600" />
                    <span>Mạng Xã Hội & Kênh Kết Nối ({draftConfig.footer.socialLinks?.length || 0})</span>
                  </h4>
                  <p className="text-[11px] text-stone-500">
                    Hiển thị các biểu tượng Facebook, Zalo, YouTube hoặc Hotline ở cuối chân trang
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleAddSocialLink}
                  className="px-3 py-1.5 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-700 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Thêm Kênh</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {draftConfig.footer.socialLinks?.map((soc) => (
                  <div
                    key={soc.id}
                    className="p-3 rounded-2xl border border-stone-200 bg-stone-50/50 flex items-center gap-2 text-xs"
                  >
                    <select
                      value={soc.platform}
                      onChange={(e) => handleUpdateSocialLink(soc.id, 'platform', e.target.value)}
                      className="px-2 py-1 rounded-lg border border-stone-300 font-bold bg-white text-xs"
                    >
                      <option value="facebook">Facebook</option>
                      <option value="youtube">YouTube</option>
                      <option value="zalo">Zalo</option>
                      <option value="tiktok">TikTok</option>
                      <option value="website">Website</option>
                    </select>

                    <input
                      type="text"
                      value={soc.label}
                      onChange={(e) => handleUpdateSocialLink(soc.id, 'label', e.target.value)}
                      placeholder="Nhãn kênh..."
                      className="flex-1 px-2 py-1 rounded-lg border border-stone-300 font-semibold text-xs"
                    />

                    <input
                      type="text"
                      value={soc.url}
                      onChange={(e) => handleUpdateSocialLink(soc.id, 'url', e.target.value)}
                      placeholder="URL..."
                      className="w-24 px-2 py-1 rounded-lg border border-stone-300 font-mono text-[10px]"
                    />

                    <button
                      type="button"
                      onClick={() => handleDeleteSocialLink(soc.id)}
                      className="p-1 text-red-400 hover:text-red-600 rounded hover:bg-red-50"
                      title="Xóa mạng xã hội"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* ================= LIVE FOOTER PREVIEW ================= */}
            <div className="pt-6 border-t border-stone-100 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-700 flex items-center gap-2">
                  <Eye className="w-4 h-4 text-purple-600" />
                  <span>Khung Xem Trước Chân Trang Trực Tiếp (Live Footer Preview)</span>
                </span>
                <span className="text-[11px] text-stone-400">
                  Phản chiếu đúng giao diện chân trang khách truy cập sẽ nhìn thấy
                </span>
              </div>

              <div className="rounded-2xl overflow-hidden border border-stone-300 shadow-sm">
                <DynamicFooter footer={draftConfig.footer} theme={draftConfig.theme} />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 5: MENU & NAVIGATION ================= */}
      {activeTab === 'menu' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-xs space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-stone-900 flex items-center gap-2">
                <Navigation className="w-5 h-5 text-purple-600" />
                <span>Quản Lý Menu & Điều Hướng Website</span>
              </h3>
              <p className="text-xs text-stone-500 mt-1">
                Thêm bớt, đổi tên hoặc thay đổi thứ tự các liên kết trên thanh điều hướng chính.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                const newItem: NavMenuItem = {
                  id: `m-${Date.now()}`,
                  label: 'Menu mới',
                  path: '/new-link',
                  targetType: 'action',
                  targetAction: 'dashboard',
                  order: draftConfig.menu.length + 1,
                };
                setDraftConfig({
                  ...draftConfig,
                  menu: [...draftConfig.menu, newItem],
                });
                showToast('Đã thêm mục Menu mới');
              }}
              className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm Menu</span>
            </button>
          </div>

          <div className="space-y-3">
            {draftConfig.menu.map((item, idx) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl border border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-stone-50/40"
              >
                <div className="flex items-center gap-3 flex-1">
                  <span className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 text-xs font-bold flex items-center justify-center shrink-0">
                    {idx + 1}
                  </span>
                  <input
                    type="text"
                    value={item.label}
                    onChange={(e) => {
                      const updated = [...draftConfig.menu];
                      updated[idx].label = e.target.value;
                      setDraftConfig({ ...draftConfig, menu: updated });
                    }}
                    className="px-3 py-1.5 rounded-xl border border-stone-300 text-xs font-bold text-stone-900 w-44"
                  />
                  <select
                    value={item.targetAction || 'dashboard'}
                    onChange={(e) => {
                      const updated = [...draftConfig.menu];
                      updated[idx].targetAction = e.target.value as any;
                      setDraftConfig({ ...draftConfig, menu: updated });
                    }}
                    className="px-3 py-1.5 rounded-xl border border-stone-300 text-xs font-medium"
                  >
                    <option value="positive_room">Mở Phòng Tích Cực (AI)</option>
                    <option value="emergency">Mở SOS Khẩn Cấp</option>
                    <option value="tests">Mở Trắc Nghiệm Tâm Lý</option>
                    <option value="dashboard">Vào Dashboard Làm Việc</option>
                    <option value="login">Mở Đăng Nhập</option>
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setDraftConfig({
                        ...draftConfig,
                        menu: draftConfig.menu.filter((m) => m.id !== item.id),
                      });
                      showToast('Đã xóa menu');
                    }}
                    className="p-1.5 rounded-lg text-red-500 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= TAB 6: VERSIONS & ROLLBACK ================= */}
      {activeTab === 'versions' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-stone-200 shadow-xs space-y-6">
          <div>
            <h3 className="text-lg font-bold text-stone-900 flex items-center gap-2">
              <History className="w-5 h-5 text-purple-600" />
              <span>Lịch Sử Phiên Bản & Khôi Phục Giao Diện (Rollback Version)</span>
            </h3>
            <p className="text-xs text-stone-500 mt-1">
              Mỗi lần xuất bản, hệ thống tự động lưu trữ một ảnh chụp (snapshot). Bạn có thể khôi phục về bất kỳ phiên bản nào chỉ với 1 cú nhấp chuột.
            </p>
          </div>

          <div className="space-y-3">
            {(draftConfig.versions || []).map((ver, idx) => (
              <div
                key={ver.id}
                className="p-5 rounded-2xl border border-stone-200 bg-stone-50/50 hover:bg-stone-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-purple-100 text-purple-800 font-mono">
                      Phiên bản #{ver.versionNumber}
                    </span>
                    {idx === 0 && (
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        Phiên bản hiện tại
                      </span>
                    )}
                  </div>
                  <h4 className="font-bold text-sm text-stone-900">{ver.changeSummary}</h4>
                  <p className="text-xs text-stone-500">
                    Xuất bản bởi <strong>{ver.createdByName}</strong> lúc {ver.createdAt}
                  </p>
                </div>

                <div>
                  <button
                    type="button"
                    onClick={() => handleRollback(ver.id)}
                    className="px-4 py-2 rounded-xl border border-purple-300 hover:bg-purple-50 text-purple-700 font-bold text-xs flex items-center gap-1.5 transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Khôi phục về bản này</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= TAB: ARTICLES & NEWS MANAGEMENT ================= */}
      {activeTab === 'articles' && (
        <CounselorArticleManager />
      )}

      {/* ================= TAB 7: LIVE PREVIEW ================= */}
      {activeTab === 'preview' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl p-4 border border-stone-200 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-stone-700">
              <span>Xem trước trên thiết bị:</span>
              <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setPreviewDevice('desktop')}
                  className={`p-1.5 rounded-lg flex items-center gap-1 ${
                    previewDevice === 'desktop' ? 'bg-white shadow-xs text-purple-700' : 'text-stone-500'
                  }`}
                >
                  <Monitor className="w-4 h-4" />
                  <span>Máy tính</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewDevice('tablet')}
                  className={`p-1.5 rounded-lg flex items-center gap-1 ${
                    previewDevice === 'tablet' ? 'bg-white shadow-xs text-purple-700' : 'text-stone-500'
                  }`}
                >
                  <Tablet className="w-4 h-4" />
                  <span>Máy tính bảng</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewDevice('mobile')}
                  className={`p-1.5 rounded-lg flex items-center gap-1 ${
                    previewDevice === 'mobile' ? 'bg-white shadow-xs text-purple-700' : 'text-stone-500'
                  }`}
                >
                  <Smartphone className="w-4 h-4" />
                  <span>Điện thoại</span>
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={handlePublish}
              className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>Đồng ý & Xuất bản ngay</span>
            </button>
          </div>

          <div className="bg-stone-900 p-6 rounded-3xl flex justify-center overflow-x-auto">
            <div
              className={`bg-white rounded-2xl overflow-hidden shadow-2xl transition-all ${
                previewDevice === 'mobile'
                  ? 'w-[375px]'
                  : previewDevice === 'tablet'
                  ? 'w-[768px]'
                  : 'w-full max-w-7xl'
              }`}
            >
              <DynamicHeader
                header={draftConfig.header}
                menu={draftConfig.menu}
                theme={draftConfig.theme}
                onOpenLogin={() => alert('Xem trước: Mở popup đăng nhập')}
              />
              <DynamicPageRenderer
                page={currentPage}
                theme={draftConfig.theme}
                isLiveEditing={false}
              />
              <DynamicFooter
                footer={draftConfig.footer}
                theme={draftConfig.theme}
                onOpenLogin={() => alert('Xem trước: Mở popup đăng nhập')}
              />
            </div>
          </div>
        </div>
      )}

      {/* Editing Modals */}
      {editingBlock && (
        <BlockEditorModal
          block={editingBlock}
          onSave={handleSaveBlock}
          onClose={() => setEditingBlock(null)}
          onDelete={handleDeleteBlock}
        />
      )}

      {editingSection && (
        <SectionEditorModal
          section={editingSection}
          onSave={handleSaveSection}
          onClose={() => setEditingSection(null)}
          onDelete={handleDeleteSection}
        />
      )}
    </div>
  );
};
