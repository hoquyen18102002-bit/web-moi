import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { StudentHealthRecord, PsychologicalTest, TestSubmission } from '../../types';
import {
  Brain,
  FileCheck2,
  AlertTriangle,
  BarChart3,
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  Eye,
  CheckCircle2,
  XCircle,
  Flag,
  User,
  Clock,
  Sparkles,
  TrendingDown,
  TrendingUp,
  Activity,
  HeartHandshake,
  Download,
  Check,
  X,
} from 'lucide-react';

interface AdminPsychologyManagerProps {
  initialSubTab?: 'records' | 'tests' | 'results' | 'alerts' | 'stats';
}

export const AdminPsychologyManager: React.FC<AdminPsychologyManagerProps> = ({
  initialSubTab = 'records',
}) => {
  const { state, updateSharedState, createTest, deleteTest } = useApp();

  const [activeTab, setActiveTab] = useState<'records' | 'tests' | 'results' | 'alerts' | 'stats'>(
    initialSubTab
  );

  // Sync if prop changes
  React.useEffect(() => {
    if (initialSubTab) {
      setActiveTab(initialSubTab);
    }
  }, [initialSubTab]);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClass, setSelectedClass] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedRecord, setSelectedRecord] = useState<StudentHealthRecord | null>(null);
  const [selectedSubmission, setSelectedSubmission] = useState<TestSubmission | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Create Test Modal
  const [showCreateTestModal, setShowCreateTestModal] = useState(false);
  const [newTestTitle, setNewTestTitle] = useState('');
  const [newTestDesc, setNewTestDesc] = useState('');
  const [newTestTargetGrades, setNewTestTargetGrades] = useState('10, 11, 12');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Toggle flag on student record
  const handleToggleSpecialFlag = async (recordId: string, currentFlag: boolean) => {
    const updated = state.studentRecords.map((rec) =>
      rec.id === recordId ? { ...rec, specialAttentionFlag: !currentFlag } : rec
    );
    await updateSharedState({ studentRecords: updated });
    showToast(`Đã ${!currentFlag ? 'gắn cờ cảnh báo đặc biệt' : 'gỡ cờ cảnh báo'} cho học sinh`);
    if (selectedRecord && selectedRecord.id === recordId) {
      setSelectedRecord({ ...selectedRecord, specialAttentionFlag: !currentFlag });
    }
  };

  // Filtered records
  const filteredRecords = (state.studentRecords || []).filter((rec) => {
    const matchSearch =
      rec.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.studentCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.classId.toLowerCase().includes(searchQuery.toLowerCase());
    const matchClass = selectedClass === 'all' || rec.classId === selectedClass;
    const matchStatus = selectedStatus === 'all' || rec.status === selectedStatus;
    return matchSearch && matchClass && matchStatus;
  });

  // Filtered alerts
  const alertRecords = (state.studentRecords || []).filter(
    (rec) => rec.specialAttentionFlag || rec.status === 'Cần đặc biệt lưu ý'
  );

  // Filtered submissions
  const filteredSubmissions = (state.testSubmissions || []).filter((sub) => {
    const matchSearch =
      sub.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.studentCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.classId.toLowerCase().includes(searchQuery.toLowerCase());
    const matchClass = selectedClass === 'all' || sub.classId === selectedClass;
    return matchSearch && matchClass;
  });

  // Handle create new test
  const handleCreateTestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTestTitle.trim()) return;

    const grades = newTestTargetGrades
      .split(',')
      .map((g) => parseInt(g.trim(), 10))
      .filter((n) => !isNaN(n));

    const res = await createTest({
      title: newTestTitle.trim(),
      description: newTestDesc.trim() || 'Bài đánh giá sức khỏe tâm lý định kỳ cho học sinh',
      targetGrades: grades.length ? grades : [10, 11, 12],
      month: new Date().toISOString().substring(0, 7),
      questions: [
        {
          id: 'q1',
          content: 'Em cảm thấy khó thư giãn và thường xuyên căng thẳng trong tuần qua?',
          options: [
            { text: 'Không đúng chút nào', score: 0 },
            { text: 'Đúng một phần / Thỉnh thoảng', score: 1 },
            { text: 'Khá đúng / Khá thường xuyên', score: 2 },
            { text: 'Hoàn toàn đúng / Hầu như lúc nào cũng vậy', score: 3 },
          ],
        },
        {
          id: 'q2',
          content: 'Em cảm thấy lo lắng vô cớ hoặc tim đập nhanh trước giờ kiểm tra?',
          options: [
            { text: 'Không bao giờ', score: 0 },
            { text: 'Hiếm khi', score: 1 },
            { text: 'Thường xuyên', score: 2 },
            { text: 'Liên tục', score: 3 },
          ],
        },
      ],
      scoreTiers: [
        {
          label: 'Bình thường',
          minScore: 0,
          maxScore: 10,
          color: '#10b981',
          description: 'Trạng thái tâm lý ổn định, cân bằng tốt.',
          actionRecommendation: 'Tiếp tục duy trì lối sống lành mạnh và tự chăm sóc bản thân.',
        },
        {
          label: 'Cần lưu ý',
          minScore: 11,
          maxScore: 20,
          color: '#f59e0b',
          description: 'Có biểu hiện lo âu hoặc căng thẳng mức độ nhẹ.',
          actionRecommendation: 'Nên tham gia phòng suy nghĩ tích cực và trao đổi với GV tư vấn.',
        },
        {
          label: 'Cần đặc biệt lưu ý',
          minScore: 21,
          maxScore: 50,
          color: '#ef4444',
          description: 'Mức độ căng thẳng hoặc lo âu cao.',
          actionRecommendation: 'Cần sự hỗ trợ trực tiếp và can thiệp kịp thời từ GV tư vấn tâm lý.',
        },
      ],
      isActive: true,
    });

    if (res.success) {
      showToast('Đã tạo thành công bộ trắc nghiệm tâm lý mới');
      setShowCreateTestModal(false);
      setNewTestTitle('');
      setNewTestDesc('');
    } else {
      alert('Lỗi tạo bài test: ' + res.error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-white px-5 py-3 rounded-2xl shadow-xl border border-stone-700 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-purple-100 text-purple-700">
              <Brain className="w-5 h-5" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-purple-700">
              Chuyên mục Quản trị
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight">
            Tâm Lý Học Sinh & Sức Khỏe Tinh Thần
          </h2>
          <p className="text-xs text-stone-600 max-w-2xl">
            Theo dõi hồ sơ sức khỏe tâm thần, quản trị các bài trắc nghiệm tâm lý định kỳ, phân tích kết quả và giám sát các chỉ số cảnh báo rủi ro toàn trường.
          </p>
        </div>

        {/* Sub-tab Navigation Pills */}
        <div className="flex flex-wrap items-center gap-1.5 bg-stone-100 p-1.5 rounded-2xl border border-stone-200">
          <button
            type="button"
            onClick={() => setActiveTab('records')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'records'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Hồ sơ tâm lý ({state.studentRecords?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('tests')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'tests'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>Trắc nghiệm ({state.psychologicalTests?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('results')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'results'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Kết quả ({state.testSubmissions?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('alerts')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'alerts'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-red-700 hover:bg-red-50'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Cảnh báo ({alertRecords.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('stats')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'stats'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Thống kê</span>
          </button>
        </div>
      </div>

      {/* ================= 1. HỒ SƠ TÂM LÝ ================= */}
      {activeTab === 'records' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-1 min-w-[240px] max-w-md bg-stone-50 px-3 py-2 rounded-xl border border-stone-200">
              <Search className="w-4 h-4 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Tìm học sinh theo tên, mã số, hoặc lớp..."
                className="w-full bg-transparent text-xs text-stone-800 outline-none font-medium"
              />
            </div>

            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-stone-400" />
              <select
                value={selectedClass}
                onChange={(e) => setSelectedClass(e.target.value)}
                className="px-3 py-2 rounded-xl border border-stone-200 text-xs font-semibold bg-stone-50 text-stone-700 outline-none"
              >
                <option value="all">Tất cả các lớp</option>
                {state.classes.map((cls) => (
                  <option key={cls} value={cls}>
                    Lớp {cls}
                  </option>
                ))}
              </select>

              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-3 py-2 rounded-xl border border-stone-200 text-xs font-semibold bg-stone-50 text-stone-700 outline-none"
              >
                <option value="all">Tất cả trạng thái</option>
                <option value="Bình thường">Bình thường</option>
                <option value="Cần lưu ý">Cần lưu ý</option>
                <option value="Cần đặc biệt lưu ý">Cần đặc biệt lưu ý</option>
              </select>
            </div>
          </div>

          {/* Records Table */}
          <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="px-5 py-3.5">Học sinh</th>
                    <th className="px-4 py-3.5">Lớp / Khối</th>
                    <th className="px-4 py-3.5">Điểm DASS-21 gần nhất</th>
                    <th className="px-4 py-3.5">Trạng thái sức khỏe</th>
                    <th className="px-4 py-3.5">Ghi chú chuyên môn</th>
                    <th className="px-4 py-3.5 text-center">Cờ cảnh báo</th>
                    <th className="px-4 py-3.5 text-right">Chi tiết</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {filteredRecords.map((rec) => (
                    <tr key={rec.id} className="hover:bg-purple-50/30 transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-stone-900">{rec.studentName}</div>
                        <div className="text-[11px] text-stone-400 font-mono">{rec.studentCode}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="font-semibold text-stone-800">Lớp {rec.classId}</span>
                        <div className="text-[10px] text-stone-400">Khối {rec.grade}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="font-bold text-sm text-stone-900">{rec.latestScore}</span>
                        <span className="text-[10px] text-stone-400"> / 63</span>
                        <div className="text-[10px] text-stone-400">{rec.lastUpdatedMonth}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                            rec.status === 'Bình thường'
                              ? 'bg-emerald-100 text-emerald-800'
                              : rec.status === 'Cần lưu ý'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {rec.status === 'Bình thường' && <CheckCircle2 className="w-3 h-3" />}
                          {rec.status === 'Cần lưu ý' && <AlertTriangle className="w-3 h-3" />}
                          {rec.status === 'Cần đặc biệt lưu ý' && <XCircle className="w-3 h-3" />}
                          <span>{rec.status}</span>
                        </span>
                      </td>
                      <td className="px-4 py-3.5 max-w-xs">
                        <p className="text-[11px] text-stone-600 line-clamp-1 italic">
                          {rec.counselorNotes || 'Chưa có ghi chú'}
                        </p>
                      </td>
                      <td className="px-4 py-3.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleToggleSpecialFlag(rec.id, rec.specialAttentionFlag)}
                          className={`p-1.5 rounded-xl transition-all cursor-pointer ${
                            rec.specialAttentionFlag
                              ? 'bg-red-100 text-red-600 hover:bg-red-200 ring-2 ring-red-400'
                              : 'bg-stone-100 text-stone-400 hover:text-red-500'
                          }`}
                          title={rec.specialAttentionFlag ? 'Gỡ cờ cảnh báo' : 'Gắn cờ cảnh báo nguy cơ'}
                        >
                          <Flag className="w-4 h-4 fill-current" />
                        </button>
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        <button
                          type="button"
                          onClick={() => setSelectedRecord(rec)}
                          className="px-3 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold text-xs inline-flex items-center gap-1 transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Hồ sơ</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= 2. TRẮC NGHIỆM ================= */}
      {activeTab === 'tests' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-base text-stone-900">
              Danh sách Bộ Đề Trắc Nghiệm Tâm Lý Chuẩn Hóa
            </h3>
            <button
              type="button"
              onClick={() => setShowCreateTestModal(true)}
              className="px-4 py-2 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Tạo bộ trắc nghiệm mới</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {state.psychologicalTests?.map((test) => (
              <div
                key={test.id}
                className="bg-white rounded-3xl p-5 border border-stone-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-700">
                      Tháng: {test.month}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                      Đang kích hoạt
                    </span>
                  </div>
                  <h4 className="font-bold text-base text-stone-900 leading-snug">{test.title}</h4>
                  <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                    {test.description}
                  </p>
                  <div className="pt-2 flex items-center gap-3 text-xs text-stone-600">
                    <span>
                      <strong>{test.questions?.length || 0}</strong> câu hỏi
                    </span>
                    <span>•</span>
                    <span>
                      Khối áp dụng: <strong>{test.targetGrades?.join(', ')}</strong>
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                  <span className="text-[10px] text-stone-400">Tạo bởi: {test.createdBy}</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => alert(`Bộ đề "${test.title}" đang được áp dụng trực tiếp cho học sinh.`)}
                      className="p-1.5 rounded-xl hover:bg-purple-50 text-purple-600 text-xs font-semibold flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Chi tiết</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`Bạn có chắc chắn muốn xóa bộ đề "${test.title}"?`)) {
                          deleteTest(test.id);
                          showToast('Đã xóa bộ đề trắc nghiệm');
                        }
                      }}
                      className="p-1.5 rounded-xl hover:bg-red-50 text-red-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= 3. KẾT QUẢ TRẮC NGHIỆM ================= */}
      {activeTab === 'results' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-1 min-w-[240px] max-w-md bg-stone-50 px-3 py-2 rounded-xl border border-stone-200">
              <Search className="w-4 h-4 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Tìm kết quả theo tên học sinh, mã số..."
                className="w-full bg-transparent text-xs text-stone-800 outline-none font-medium"
              />
            </div>
            <span className="text-xs text-stone-500 font-semibold">
              Tổng số {filteredSubmissions.length} bài nộp
            </span>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="px-5 py-3.5">Học sinh</th>
                    <th className="px-4 py-3.5">Lớp / Khối</th>
                    <th className="px-4 py-3.5">Thời gian nộp</th>
                    <th className="px-4 py-3.5">Tổng điểm</th>
                    <th className="px-4 py-3.5">Đánh giá chuyên môn</th>
                    <th className="px-4 py-3.5 text-right">Thao tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {filteredSubmissions.map((sub) => (
                    <tr key={sub.id} className="hover:bg-purple-50/30 transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-stone-900">{sub.studentName}</div>
                        <div className="text-[11px] text-stone-400 font-mono">{sub.studentCode}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        <span className="font-semibold text-stone-800">Lớp {sub.classId}</span>
                        <div className="text-[10px] text-stone-400">Khối {sub.grade}</div>
                      </td>
                      <td className="px-4 py-3.5 text-stone-600">{sub.submittedAt}</td>
                      <td className="px-4 py-3.5">
                        <span className="font-bold text-base text-stone-900">{sub.totalScore}</span>
                        <span className="text-[10px] text-stone-400"> điểm</span>
                      </td>
                      <td className="px-4 py-3.5">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                            sub.evaluation === 'Bình thường'
                              ? 'bg-emerald-100 text-emerald-800'
                              : sub.evaluation === 'Cần lưu ý'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {sub.evaluation}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        <button
                          type="button"
                          onClick={() => setSelectedSubmission(sub)}
                          className="px-3 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold text-xs inline-flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Xem bài</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= 4. CẢNH BÁO TÂM LÝ ================= */}
      {activeTab === 'alerts' && (
        <div className="space-y-4">
          <div className="bg-red-50 border border-red-200 rounded-3xl p-6 flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-700 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-black text-red-950 text-base sm:text-lg">
                Trung Tâm Giám Sát Cảnh Báo Sức Khỏe Tâm Thần Khẩn Cấp
              </h3>
              <p className="text-xs text-red-800 leading-relaxed max-w-3xl">
                Bảng theo dõi các học sinh có điểm DASS-21 ở mức cảnh báo rủi ro cao hoặc được giáo viên chủ nhiệm và chuyên viên tâm lý gắn cờ giám sát. Bấm vào học sinh để xem hồ sơ và tiến hành can thiệp tâm lý kịp thời.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {alertRecords.map((rec) => (
              <div
                key={rec.id}
                className="bg-white rounded-3xl p-5 border-2 border-red-200 shadow-sm hover:border-red-400 transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-red-100 text-red-800 flex items-center gap-1">
                      <Flag className="w-3 h-3 fill-current" />
                      <span>Cảnh báo nguy cơ cao</span>
                    </span>
                    <span className="text-xs font-bold text-stone-500">Lớp {rec.classId}</span>
                  </div>

                  <h4 className="font-extrabold text-base text-stone-900">{rec.studentName}</h4>
                  <div className="text-xs text-stone-500">Mã học sinh: {rec.studentCode}</div>

                  <div className="p-3 rounded-xl bg-stone-50 border border-stone-200 space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="text-stone-500">Điểm DASS-21:</span>
                      <span className="font-bold text-red-600">{rec.latestScore} / 63</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">Ghi chú chuyên viên:</span>
                      <span className="text-stone-700 italic font-medium">{rec.counselorNotes || 'Đang cập nhật'}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => handleToggleSpecialFlag(rec.id, rec.specialAttentionFlag)}
                    className="text-xs font-semibold text-stone-500 hover:text-stone-700"
                  >
                    Gỡ cảnh báo
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedRecord(rec)}
                    className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
                  >
                    <HeartHandshake className="w-3.5 h-3.5" />
                    <span>Hồ sơ can thiệp</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= 5. THỐNG KÊ ================= */}
      {activeTab === 'stats' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-stone-500">
                <span>Tỉ lệ Tâm lý Ổn định</span>
                <TrendingUp className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-3xl font-black text-emerald-600">74.2%</div>
              <p className="text-[11px] text-stone-500 leading-relaxed">
                Tăng +3.8% so với cùng kỳ tháng trước nhờ các buổi tư vấn tích cực.
              </p>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-stone-500">
                <span>Tỉ lệ Cần Hỗ trợ Nhẹ</span>
                <Activity className="w-4 h-4 text-amber-600" />
              </div>
              <div className="text-3xl font-black text-amber-600">18.5%</div>
              <p className="text-[11px] text-stone-500 leading-relaxed">
                Tập trung vào áp lực thi cử và chọn ngành đại học ở khối 12.
              </p>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-stone-500">
                <span>Tỉ lệ Rủi ro Cần Can thiệp</span>
                <TrendingDown className="w-4 h-4 text-red-600" />
              </div>
              <div className="text-3xl font-black text-red-600">7.3%</div>
              <p className="text-[11px] text-stone-500 leading-relaxed">
                100% các trường hợp đã được thiết lập hồ sơ đồng hành cùng gia đình.
              </p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-4">
            <h3 className="font-bold text-stone-900 text-sm">
              Phân tích Chủ đề Căng thẳng Phổ biến Nhất theo Phản hồi Học sinh
            </h3>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-stone-700">Áp lực thi cử, khối lượng bài vở và kỳ thi chuyển cấp</span>
                  <span className="text-purple-700">52%</span>
                </div>
                <div className="w-full h-3 rounded-full bg-stone-100 overflow-hidden">
                  <div className="bg-purple-600 h-full rounded-full" style={{ width: '52%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-stone-700">Mối quan hệ bạn bè, xung đột nhóm & tâm lý lứa tuổi</span>
                  <span className="text-blue-700">26%</span>
                </div>
                <div className="w-full h-3 rounded-full bg-stone-100 overflow-hidden">
                  <div className="bg-blue-600 h-full rounded-full" style={{ width: '26%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-stone-700">Kỳ vọng gia đình & khoảng cách thế hệ giữa cha mẹ - con cái</span>
                  <span className="text-amber-700">14%</span>
                </div>
                <div className="w-full h-3 rounded-full bg-stone-100 overflow-hidden">
                  <div className="bg-amber-600 h-full rounded-full" style={{ width: '14%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-stone-700">Định hướng nghề nghiệp & tương lai</span>
                  <span className="text-emerald-700">8%</span>
                </div>
                <div className="w-full h-3 rounded-full bg-stone-100 overflow-hidden">
                  <div className="bg-emerald-600 h-full rounded-full" style={{ width: '8%' }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: RECORD DETAIL ================= */}
      {selectedRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 space-y-5 border border-stone-200 shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-purple-100 text-purple-700">
                  <Brain className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-extrabold text-stone-900 text-lg">{selectedRecord.studentName}</h3>
                  <p className="text-xs text-stone-500 font-mono">
                    Mã HS: {selectedRecord.studentCode} • Lớp {selectedRecord.classId}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                className="p-1.5 rounded-xl hover:bg-stone-100 text-stone-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100">
                  <div className="text-stone-400">Trạng thái sức khỏe:</div>
                  <div className="font-bold text-sm text-stone-900 mt-1">{selectedRecord.status}</div>
                </div>
                <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100">
                  <div className="text-stone-400">Điểm DASS-21 mới nhất:</div>
                  <div className="font-bold text-sm text-stone-900 mt-1">
                    {selectedRecord.latestScore} / 63
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-bold text-stone-800 mb-1">Ghi chú của Chuyên viên Tâm lý:</h4>
                <div className="p-3 rounded-2xl bg-purple-50/50 border border-purple-100 text-stone-700 leading-relaxed">
                  {selectedRecord.counselorNotes || 'Chưa có ghi chú chuyên sâu.'}
                </div>
              </div>

              <div>
                <h4 className="font-bold text-stone-800 mb-1">Ghi chú của Giáo viên Chủ nhiệm:</h4>
                <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200 text-stone-700 leading-relaxed">
                  {selectedRecord.homeroomNotes || 'Chưa có nhận xét từ GVCN.'}
                </div>
              </div>

              <div>
                <h4 className="font-bold text-stone-800 mb-2">Lịch sử Đánh giá qua các tháng:</h4>
                <div className="space-y-1.5">
                  {selectedRecord.scoreHistory?.map((h, i) => (
                    <div
                      key={i}
                      className="p-2 rounded-xl bg-stone-50 border border-stone-200 flex justify-between items-center"
                    >
                      <span className="font-semibold text-stone-700">Tháng {h.month}</span>
                      <span className="font-mono text-stone-600">{h.score} điểm</span>
                      <span className="font-bold text-purple-700">{h.evaluation}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-stone-100 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                className="px-5 py-2.5 rounded-xl bg-stone-900 text-white text-xs font-bold"
              >
                Đóng hồ sơ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: CREATE TEST ================= */}
      {showCreateTestModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-4 border border-stone-200 shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-extrabold text-stone-900 text-base">Thêm Bộ Trắc Nghiệm Tâm Lý Mới</h3>
              <button
                type="button"
                onClick={() => setShowCreateTestModal(false)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTestSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Tên bộ đề trắc nghiệm *</label>
                <input
                  type="text"
                  required
                  value={newTestTitle}
                  onChange={(e) => setNewTestTitle(e.target.value)}
                  placeholder="Ví dụ: Đánh giá Năng lực Thích ứng Tâm lý Đầu Năm Học"
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Mô tả mục tiêu đánh giá</label>
                <textarea
                  rows={3}
                  value={newTestDesc}
                  onChange={(e) => setNewTestDesc(e.target.value)}
                  placeholder="Mô tả mục tiêu của bài test..."
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Khối lớp áp dụng (phân cách bằng dấu phẩy)</label>
                <input
                  type="text"
                  value={newTestTargetGrades}
                  onChange={(e) => setNewTestTargetGrades(e.target.value)}
                  placeholder="10, 11, 12"
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 outline-none"
                />
              </div>

              <div className="pt-3 border-t border-stone-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateTestModal(false)}
                  className="px-4 py-2 rounded-xl text-stone-600 font-bold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 text-white font-bold hover:bg-purple-700"
                >
                  Tạo bộ đề
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
