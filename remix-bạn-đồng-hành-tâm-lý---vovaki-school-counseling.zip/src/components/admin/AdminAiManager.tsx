import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Bot,
  Cpu,
  Sliders,
  Sparkles,
  Volume2,
  MessageSquare,
  FileCode,
  CheckCircle2,
  AlertCircle,
  Brain,
  Zap,
  Shield,
  Activity,
  RotateCcw,
  Save,
  VolumeX,
  Play,
  Key,
} from 'lucide-react';

interface AdminAiManagerProps {
  initialSubTab?: 'config' | 'prompt' | 'voice' | 'chat_settings' | 'logs';
}

export const AdminAiManager: React.FC<AdminAiManagerProps> = ({
  initialSubTab = 'config',
}) => {
  const { state, updateSharedState } = useApp();

  const [activeTab, setActiveTab] = useState<'config' | 'prompt' | 'voice' | 'chat_settings' | 'logs'>(
    initialSubTab
  );

  React.useEffect(() => {
    if (initialSubTab) {
      setActiveTab(initialSubTab);
    }
  }, [initialSubTab]);

  // AI Configuration State
  const [model, setModel] = useState<'gemini-2.5-flash' | 'gemini-2.5-pro'>('gemini-2.5-flash');
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(2048);
  const [safetyLevel, setSafetyLevel] = useState('high');

  // AI Prompt State
  const [systemPrompt, setSystemPrompt] = useState(
    `Bạn là VoVaKi - Chuyên viên Trợ lý Tâm lý Học đường AI đầy thấu hiểu, ấm áp và tận tụy. 
Nhiệm vụ của bạn là lắng nghe không phán xét, đồng hành cùng học sinh THCS và THPT trong việc giải tỏa căng thẳng học tập, mối quan hệ bạn bè, áp lực kỳ thi và khó khăn cảm xúc.
Nguyên tắc đạo đức:
1. Luôn bảo mật danh tính học sinh.
2. Thể hiện sự đồng cảm sâu sắc, dùng từ ngữ trong sáng, gần gũi với lứa tuổi học đường.
3. Tuyệt đối không chẩn đoán y khoa hoặc kê đơn thuốc.
4. Khi nhận diện các từ khóa rủi ro cao (tự hại, tự vẫn, bạo lực học đường, bế tắc tột cùng), hãy an ủi khẩn thiết và lập tức hướng dẫn em liên hệ Hotline 1900 6868 hoặc nhấn nút "Tư Vấn Khẩn Cấp" để gặp Chuyên viên ThS. Nguyễn Mai Phương.`
  );

  // Voice / TTS State
  const [voiceGender, setVoiceGender] = useState<'female_north' | 'female_south' | 'male_north'>(
    'female_north'
  );
  const [speechRate, setSpeechRate] = useState(1.0);
  const [speechPitch, setSpeechPitch] = useState(1.0);
  const [autoPlayAudio, setAutoPlayAudio] = useState(true);

  // Chat Settings State
  const [welcomeGreeting, setWelcomeGreeting] = useState(
    'Chào em! VoVaKi ở đây để cùng em lắng nghe và san sẻ mọi áp lực học tập hay nỗi niềm khó nói. Hôm nay của em thế nào?'
  );
  const [dailyMessageLimit, setDailyMessageLimit] = useState(50);
  const [anonymousChatOnly, setAnonymousChatOnly] = useState(true);
  const [suggestedPrompts, setSuggestedPrompts] = useState([
    'Em cảm thấy quá tải trước kỳ thi sắp tới...',
    'Em có bất đồng với bạn thân và không biết làm hòa...',
    'Bố mẹ đặt quá nhiều kỳ vọng khiến em áp lực...',
    'Làm thế nào để ngủ ngon khi tâm trí không ngừng suy nghĩ?',
  ]);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSaveAll = () => {
    showToast('Đã lưu thành công toàn bộ thiết lập AI vào hệ thống');
  };

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-white px-5 py-3 rounded-2xl shadow-xl border border-stone-700 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-purple-100 text-purple-700">
              <Bot className="w-5 h-5" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-purple-700">
              Trí Tuệ Nhân Tạo
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight">
            Quản Trị AI & Trợ Lý Tâm Lý Học Đường
          </h2>
          <p className="text-xs text-stone-600 max-w-2xl">
            Cấu hình mô hình Gemini, tinh chỉnh System Prompt đạo đức tâm lý, cài đặt giọng đọc tiếng Việt và kiểm tra nhật ký phân tích cảm xúc sentiment.
          </p>
        </div>

        {/* Sub-tab Navigation */}
        <div className="flex flex-wrap items-center gap-1.5 bg-stone-100 p-1.5 rounded-2xl border border-stone-200">
          <button
            type="button"
            onClick={() => setActiveTab('config')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'config'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>AI Configuration</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('prompt')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'prompt'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>AI Prompt</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('voice')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'voice'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>Voice / TTS</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('chat_settings')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'chat_settings'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Chat Settings</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('logs')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'logs'
                ? 'bg-white text-purple-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>AI Logs ({state.sentimentAnalyses?.length || 0})</span>
          </button>
        </div>
      </div>

      {/* ================= 1. AI CONFIGURATION ================= */}
      {activeTab === 'config' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Model Selection Card */}
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-4">
              <div className="flex items-center gap-3">
                <span className="p-2.5 rounded-2xl bg-purple-100 text-purple-700">
                  <Zap className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm">Lựa Chọn Mô Hình Gemini</h3>
                  <p className="text-xs text-stone-500">Mô hình xử lý ngôn ngữ tự nhiên phía máy chủ</p>
                </div>
              </div>

              <div className="space-y-3">
                <label
                  className={`p-4 rounded-2xl border-2 flex items-start justify-between cursor-pointer transition-all ${
                    model === 'gemini-2.5-flash'
                      ? 'border-purple-600 bg-purple-50/40'
                      : 'border-stone-200 hover:border-stone-300'
                  }`}
                  onClick={() => setModel('gemini-2.5-flash')}
                >
                  <div className="space-y-1">
                    <div className="font-bold text-sm text-stone-900 flex items-center gap-2">
                      <span>Gemini 2.5 Flash</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        Khuyên dùng
                      </span>
                    </div>
                    <p className="text-xs text-stone-500">
                      Tốc độ phản hồi tức thì, tối ưu chi phí và độ trễ siêu thấp cho hội thoại tâm lý học đường.
                    </p>
                  </div>
                  <input
                    type="radio"
                    checked={model === 'gemini-2.5-flash'}
                    onChange={() => setModel('gemini-2.5-flash')}
                    className="mt-1"
                  />
                </label>

                <label
                  className={`p-4 rounded-2xl border-2 flex items-start justify-between cursor-pointer transition-all ${
                    model === 'gemini-2.5-pro'
                      ? 'border-purple-600 bg-purple-50/40'
                      : 'border-stone-200 hover:border-stone-300'
                  }`}
                  onClick={() => setModel('gemini-2.5-pro')}
                >
                  <div className="space-y-1">
                    <div className="font-bold text-sm text-stone-900 flex items-center gap-2">
                      <span>Gemini 2.5 Pro</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800">
                        Chuyên sâu
                      </span>
                    </div>
                    <p className="text-xs text-stone-500">
                      Khả năng suy luận đa tầng, phân tích ca tâm lý phức tạp và tổng hợp khuyến nghị lâm sàng.
                    </p>
                  </div>
                  <input
                    type="radio"
                    checked={model === 'gemini-2.5-pro'}
                    onChange={() => setModel('gemini-2.5-pro')}
                    className="mt-1"
                  />
                </label>
              </div>

              <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Key className="w-4 h-4 text-emerald-600" />
                  <span className="font-semibold text-stone-700">API Key Server Environment:</span>
                </div>
                <span className="font-mono text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md font-bold">
                  Bảo mật Máy chủ (Active)
                </span>
              </div>
            </div>

            {/* Inference Parameters Card */}
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-4">
              <div className="flex items-center gap-3">
                <span className="p-2.5 rounded-2xl bg-purple-100 text-purple-700">
                  <Sliders className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="font-bold text-stone-900 text-sm">Tham Số Suy Luận (Inference Tuning)</h3>
                  <p className="text-xs text-stone-500">Kiểm soát độ sáng tạo và độ dài phản hồi</p>
                </div>
              </div>

              <div className="space-y-4 text-xs">
                <div>
                  <div className="flex justify-between font-semibold mb-1">
                    <span className="text-stone-700">Temperature (Độ ấm áp / sáng tạo):</span>
                    <span className="font-bold text-purple-700">{temperature}</span>
                  </div>
                  <input
                    type="range"
                    min="0.1"
                    max="1.0"
                    step="0.05"
                    value={temperature}
                    onChange={(e) => setTemperature(parseFloat(e.target.value))}
                    className="w-full accent-purple-600"
                  />
                  <div className="flex justify-between text-[10px] text-stone-400 mt-0.5">
                    <span>0.1 (Chính xác, kỷ luật)</span>
                    <span>0.7 (Cân bằng đồng cảm)</span>
                    <span>1.0 (Phong phú, cởi mở)</span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between font-semibold mb-1">
                    <span className="text-stone-700">Max Output Tokens:</span>
                    <span className="font-bold text-purple-700">{maxTokens} tokens</span>
                  </div>
                  <input
                    type="range"
                    min="512"
                    max="4096"
                    step="256"
                    value={maxTokens}
                    onChange={(e) => setMaxTokens(parseInt(e.target.value, 10))}
                    className="w-full accent-purple-600"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Mức Lọc An Toàn (Safety Guardrails):</label>
                  <select
                    value={safetyLevel}
                    onChange={(e) => setSafetyLevel(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 font-medium"
                  >
                    <option value="high">Nghiêm ngặt cao (Khuyên dùng cho môi trường giáo dục)</option>
                    <option value="medium">Trung bình</option>
                  </select>
                </div>
              </div>

              <button
                type="button"
                onClick={handleSaveAll}
                className="w-full py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>Lưu Cấu Hình Model</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= 2. AI PROMPT ================= */}
      {activeTab === 'prompt' && (
        <div className="space-y-4">
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-stone-900 text-base">
                  Chỉ Dẫn Hệ Thống (System Prompt Cho Trợ Lý VoVaKi)
                </h3>
                <p className="text-xs text-stone-500">
                  Định hình nhân cách, phong cách giao tiếp và các rào chắn đạo đức bảo vệ học sinh.
                </p>
              </div>
              <button
                type="button"
                onClick={() =>
                  setSystemPrompt(
                    `Bạn là VoVaKi - Chuyên viên Trợ lý Tâm lý Học đường AI đầy thấu hiểu, ấm áp và tận tụy...`
                  )
                }
                className="text-xs font-semibold text-stone-500 hover:text-stone-700 flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Khôi phục mặc định</span>
              </button>
            </div>

            <textarea
              rows={12}
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              className="w-full p-4 rounded-2xl border border-stone-300 font-mono text-xs leading-relaxed outline-none focus:ring-2 focus:ring-purple-500"
            />

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={handleSaveAll}
                className="px-6 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>Lưu & Áp Dụng Prompt Mới</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= 3. VOICE / TTS ================= */}
      {activeTab === 'voice' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-4">
              <h3 className="font-bold text-stone-900 text-base">Cấu Hình Giọng Đọc Tiếng Việt</h3>
              <p className="text-xs text-stone-500">Giọng đọc phát ra khi học sinh vào Phòng Tích Cực</p>

              <div className="space-y-3">
                <label
                  className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                    voiceGender === 'female_north'
                      ? 'border-purple-600 bg-purple-50/40'
                      : 'border-stone-200 hover:border-stone-300'
                  }`}
                  onClick={() => setVoiceGender('female_north')}
                >
                  <div>
                    <div className="font-bold text-xs text-stone-900">Giọng Nữ Miền Bắc (Dịu dàng)</div>
                    <div className="text-[11px] text-stone-500">Ấm áp, êm dịu, tạo cảm giác an toàn</div>
                  </div>
                  <input
                    type="radio"
                    checked={voiceGender === 'female_north'}
                    onChange={() => setVoiceGender('female_north')}
                  />
                </label>

                <label
                  className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                    voiceGender === 'female_south'
                      ? 'border-purple-600 bg-purple-50/40'
                      : 'border-stone-200 hover:border-stone-300'
                  }`}
                  onClick={() => setVoiceGender('female_south')}
                >
                  <div>
                    <div className="font-bold text-xs text-stone-900">Giọng Nữ Miền Nam (Ngọt ngào)</div>
                    <div className="text-[11px] text-stone-500">Tự nhiên, gần gũi, truyền cảm hứng</div>
                  </div>
                  <input
                    type="radio"
                    checked={voiceGender === 'female_south'}
                    onChange={() => setVoiceGender('female_south')}
                  />
                </label>

                <label
                  className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                    voiceGender === 'male_north'
                      ? 'border-purple-600 bg-purple-50/40'
                      : 'border-stone-200 hover:border-stone-300'
                  }`}
                  onClick={() => setVoiceGender('male_north')}
                >
                  <div>
                    <div className="font-bold text-xs text-stone-900">Giọng Nam Miền Bắc (Trầm ấm)</div>
                    <div className="text-[11px] text-stone-500">Điềm đạm, tin cậy, thấu suốt</div>
                  </div>
                  <input
                    type="radio"
                    checked={voiceGender === 'male_north'}
                    onChange={() => setVoiceGender('male_north')}
                  />
                </label>
              </div>

              <div className="pt-2 flex items-center justify-between text-xs">
                <span className="font-bold text-stone-700">Tự động đọc lời thoại khi AI phản hồi:</span>
                <input
                  type="checkbox"
                  checked={autoPlayAudio}
                  onChange={(e) => setAutoPlayAudio(e.target.checked)}
                  className="w-4 h-4 accent-purple-600 cursor-pointer"
                />
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-4">
              <h3 className="font-bold text-stone-900 text-base">Tốc Độ & Cao Độ</h3>
              <div className="space-y-4 text-xs">
                <div>
                  <div className="flex justify-between font-semibold mb-1">
                    <span className="text-stone-700">Tốc độ đọc (Speech Rate):</span>
                    <span className="font-bold text-purple-700">{speechRate}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.75"
                    max="1.5"
                    step="0.05"
                    value={speechRate}
                    onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                    className="w-full accent-purple-600"
                  />
                </div>

                <div>
                  <div className="flex justify-between font-semibold mb-1">
                    <span className="text-stone-700">Cao độ (Pitch):</span>
                    <span className="font-bold text-purple-700">{speechPitch}</span>
                  </div>
                  <input
                    type="range"
                    min="0.8"
                    max="1.3"
                    step="0.05"
                    value={speechPitch}
                    onChange={(e) => setSpeechPitch(parseFloat(e.target.value))}
                    className="w-full accent-purple-600"
                  />
                </div>
              </div>

              <div className="pt-4 flex gap-2">
                <button
                  type="button"
                  onClick={() => alert('Đang phát thử đoạn âm thanh mẫu: "Chào em, VoVaKi luôn ở đây lắng nghe em!"')}
                  className="flex-1 py-2.5 rounded-2xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs flex items-center justify-center gap-1.5"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Nghe thử giọng</span>
                </button>
                <button
                  type="button"
                  onClick={handleSaveAll}
                  className="flex-1 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center justify-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Lưu Voice Settings</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= 4. CHAT SETTINGS ================= */}
      {activeTab === 'chat_settings' && (
        <div className="space-y-4">
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-4">
            <h3 className="font-bold text-stone-900 text-base">Cài Đặt Trải Nghiệm Hội Thoại Học Sinh</h3>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Lời chào mở đầu mặc định của AI:</label>
                <textarea
                  rows={2}
                  value={welcomeGreeting}
                  onChange={(e) => setWelcomeGreeting(e.target.value)}
                  className="w-full p-3 rounded-xl border border-stone-300 font-medium"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Giới hạn tin nhắn mỗi học sinh / ngày:</label>
                  <input
                    type="number"
                    value={dailyMessageLimit}
                    onChange={(e) => setDailyMessageLimit(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>

                <div className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 border border-stone-200 mt-2">
                  <span className="font-bold text-stone-700">Chế độ ẩn danh học sinh bắt buộc:</span>
                  <input
                    type="checkbox"
                    checked={anonymousChatOnly}
                    onChange={(e) => setAnonymousChatOnly(e.target.checked)}
                    className="w-4 h-4 accent-purple-600"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-2">Gợi ý câu hỏi nhanh (Quick Prompts):</label>
                <div className="space-y-2">
                  {suggestedPrompts.map((p, idx) => (
                    <input
                      key={idx}
                      type="text"
                      value={p}
                      onChange={(e) => {
                        const copy = [...suggestedPrompts];
                        copy[idx] = e.target.value;
                        setSuggestedPrompts(copy);
                      }}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 font-medium text-xs"
                    />
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={handleSaveAll}
                className="px-6 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>Lưu Cài Đặt Hội Thoại</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= 5. AI LOGS ================= */}
      {activeTab === 'logs' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs space-y-1">
            <h3 className="font-bold text-base text-stone-900">
              Nhật Ký Tương Tác & Phân Tích Cảm Xúc AI (Sentiment Logs)
            </h3>
            <p className="text-xs text-stone-500">
              Tổng số {state.sentimentAnalyses?.length || 0} bản ghi phân tích từ hội thoại học sinh.
            </p>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="px-5 py-3.5">Học sinh</th>
                    <th className="px-4 py-3.5">Thời điểm</th>
                    <th className="px-4 py-3.5">Trạng thái cảm xúc</th>
                    <th className="px-4 py-3.5">Mức độ khẩn cấp</th>
                    <th className="px-4 py-3.5">Từ khóa nhận diện</th>
                    <th className="px-4 py-3.5 text-right">Độ tin cậy</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {state.sentimentAnalyses?.map((log) => (
                    <tr key={log.id} className="hover:bg-purple-50/30 transition-colors">
                      <td className="px-5 py-3.5 font-bold text-stone-900">
                        {log.studentIdentifier}
                      </td>
                      <td className="px-4 py-3.5 text-stone-500">{log.analyzedAt}</td>
                      <td className="px-4 py-3.5">
                        <span className="font-semibold text-purple-700">{log.emotionalState}</span>
                      </td>
                      <td className="px-4 py-3.5">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            log.urgencyLevel === 'Báo động khẩn cấp'
                              ? 'bg-red-100 text-red-800'
                              : log.urgencyLevel === 'Cần chú ý'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {log.urgencyLevel}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-stone-600 max-w-xs truncate">
                        {log.keyPhrases?.join(', ') || 'Không có'}
                      </td>
                      <td className="px-4 py-3.5 text-right font-mono font-bold text-stone-700">
                        {Math.round(log.confidence * 100)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
