import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Settings,
  School,
  Phone,
  Mail,
  MapPin,
  Clock,
  Shield,
  Save,
  CheckCircle2,
  AlertTriangle,
  Server,
  Zap,
  Globe,
  BellRing,
} from 'lucide-react';

export const AdminSystemSettings: React.FC = () => {
  const { state, updateSharedState } = useApp();

  const [schoolName, setSchoolName] = useState(
    state.siteSettings?.siteName || 'Trường THPT VoVaKi - Chuyên Gia Tâm Lý Học Đường'
  );
  const [schoolAddress, setSchoolAddress] = useState(
    state.siteSettings?.footerInfo?.address ||
      'Tầng 2, Tòa nhà Tri thức, Trường THPT VoVaKi, Hà Nội'
  );
  const [hotline, setHotline] = useState(
    state.siteSettings?.footerInfo?.hotline || '1900 6868 (Trực tư vấn 24/7)'
  );
  const [phone, setPhone] = useState(state.siteSettings?.footerInfo?.phone || '024 3825 8899');
  const [email, setEmail] = useState(
    state.siteSettings?.footerInfo?.email || 'tuvan.tamly@vovaki.edu.vn'
  );
  const [schoolYear, setSchoolYear] = useState('2026 - 2027');
  const [counselingRoomLocation, setCounselingRoomLocation] = useState(
    'Phòng 204 - Nhà Hiệu Bộ (Không gian yên tĩnh, cách âm)'
  );
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [emailAlertsEnabled, setEmailAlertsEnabled] = useState(true);
  const [smsUrgentEnabled, setSmsUrgentEnabled] = useState(true);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (state.siteSettings) {
      await updateSharedState({
        siteSettings: {
          ...state.siteSettings,
          siteName: schoolName,
          footerInfo: {
            ...state.siteSettings.footerInfo,
            address: schoolAddress,
            hotline: hotline,
            phone: phone,
            email: email,
          },
        },
      });
    }
    showToast('Đã lưu thành công cài đặt hệ thống');
  };

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-white px-5 py-3 rounded-2xl shadow-xl border border-stone-700 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-purple-100 text-purple-700">
              <Settings className="w-5 h-5" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-purple-700">
              Thiết Lập Chung
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight">
            Cài Đặt Hệ Thống & Đơn Vị Trường Học
          </h2>
          <p className="text-xs text-stone-600 max-w-2xl">
            Cấu hình thông tin nhà trường, hotline phòng tham vấn học đường, kênh thông báo và các thiết lập vận hành toàn hệ thống.
          </p>
        </div>
      </div>

      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* Card 1: School Identity */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-stone-900 font-bold text-base">
            <School className="w-5 h-5 text-purple-600" />
            <h3>Thông Tin Đơn Vị Trường Học & Năm Học</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Tên trường học / Đơn vị:</label>
              <input
                type="text"
                required
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 font-semibold text-stone-900 outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Niên khóa / Năm học:</label>
              <input
                type="text"
                value={schoolYear}
                onChange={(e) => setSchoolYear(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 font-semibold text-stone-900 outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-bold text-stone-700 mb-1">Địa chỉ trường học:</label>
              <input
                type="text"
                value={schoolAddress}
                onChange={(e) => setSchoolAddress(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 font-medium text-stone-900 outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>
        </div>

        {/* Card 2: Counseling Room Details */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-stone-900 font-bold text-base">
            <Phone className="w-5 h-5 text-emerald-600" />
            <h3>Phòng Tư Vấn Tâm Lý & Đường Dây Nóng Khẩn Cấp</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Hotline SOS Khẩn cấp (24/7):</label>
              <input
                type="text"
                value={hotline}
                onChange={(e) => setHotline(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-red-300 bg-red-50/30 text-red-700 font-bold outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Điện thoại văn phòng tư vấn:</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 font-semibold text-stone-900 outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Email phòng tư vấn:</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 font-semibold text-stone-900 outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div className="sm:col-span-3">
              <label className="block font-bold text-stone-700 mb-1">Vị trí phòng tư vấn tại trường:</label>
              <input
                type="text"
                value={counselingRoomLocation}
                onChange={(e) => setCounselingRoomLocation(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 font-medium text-stone-900 outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>
        </div>

        {/* Card 3: Operations & Maintenance */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-stone-900 font-bold text-base">
            <Server className="w-5 h-5 text-blue-600" />
            <h3>Chế Độ Vận Hành & Kênh Cảnh Báo</h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between">
              <div>
                <div className="font-bold text-stone-900">Chế độ bảo trì hệ thống (Maintenance Mode):</div>
                <div className="text-[11px] text-stone-500">
                  Khi bật, học sinh sẽ nhận được thông báo hệ thống đang bảo dưỡng định kỳ
                </div>
              </div>
              <input
                type="checkbox"
                checked={maintenanceMode}
                onChange={(e) => setMaintenanceMode(e.target.checked)}
                className="w-4 h-4 accent-red-600 cursor-pointer"
              />
            </div>

            <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between">
              <div>
                <div className="font-bold text-stone-900">Gửi Email thông báo khi có ca tư vấn khẩn cấp:</div>
                <div className="text-[11px] text-stone-500">
                  Gửi cảnh báo tức thì tới email của ban giám hiệu và chuyên viên tâm lý
                </div>
              </div>
              <input
                type="checkbox"
                checked={emailAlertsEnabled}
                onChange={(e) => setEmailAlertsEnabled(e.target.checked)}
                className="w-4 h-4 accent-purple-600 cursor-pointer"
              />
            </div>

            <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between">
              <div>
                <div className="font-bold text-stone-900">Cảnh báo SMS khẩn cấp (SMS Gateway):</div>
                <div className="text-[11px] text-stone-500">
                  Gửi tin nhắn SMS trực tiếp tới điện thoại của chuyên viên trực ban khi có tín hiệu SOS
                </div>
              </div>
              <input
                type="checkbox"
                checked={smsUrgentEnabled}
                onChange={(e) => setSmsUrgentEnabled(e.target.checked)}
                className="w-4 h-4 accent-purple-600 cursor-pointer"
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className="px-8 py-3 rounded-2xl bg-stone-900 hover:bg-black text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Lưu Tất Cả Cài Đặt</span>
          </button>
        </div>
      </form>
    </div>
  );
};
