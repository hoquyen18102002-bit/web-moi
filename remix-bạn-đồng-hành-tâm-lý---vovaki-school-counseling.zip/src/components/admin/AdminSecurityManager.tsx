import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AuthSecuritySettings } from '../../types';
import {
  ShieldCheck,
  History,
  Lock,
  KeyRound,
  Users,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  Clock,
  Shield,
  Save,
  RotateCcw,
  Check,
  X,
  UserX,
  FileSpreadsheet,
} from 'lucide-react';

interface AdminSecurityManagerProps {
  initialSubTab?: 'audit' | 'login_logs' | 'settings';
}

export const AdminSecurityManager: React.FC<AdminSecurityManagerProps> = ({
  initialSubTab = 'audit',
}) => {
  const { state, updateAuthSettings } = useApp();

  const [activeTab, setActiveTab] = useState<'audit' | 'login_logs' | 'settings'>(initialSubTab);

  React.useEffect(() => {
    if (initialSubTab) {
      setActiveTab(initialSubTab);
    }
  }, [initialSubTab]);

  const authSettings: AuthSecuritySettings = state.authSettings || {
    minPasswordLength: 6,
    requireSpecialChars: false,
    sessionTimeoutMinutes: 60,
    allowStudentRegistration: false,
    forceAnonymousStudentMode: true,
    maxLoginAttempts: 5,
  };

  const [minPasswordLength, setMinPasswordLength] = useState<number>(authSettings.minPasswordLength);
  const [requireSpecialChars, setRequireSpecialChars] = useState<boolean>(
    authSettings.requireSpecialChars
  );
  const [sessionTimeoutMinutes, setSessionTimeoutMinutes] = useState<number>(
    authSettings.sessionTimeoutMinutes
  );
  const [allowStudentRegistration, setAllowStudentRegistration] = useState<boolean>(
    authSettings.allowStudentRegistration
  );
  const [forceAnonymousStudentMode, setForceAnonymousStudentMode] = useState<boolean>(
    authSettings.forceAnonymousStudentMode
  );
  const [maxLoginAttempts, setMaxLoginAttempts] = useState<number>(authSettings.maxLoginAttempts);

  const [searchLog, setSearchLog] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSaveSecuritySettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await updateAuthSettings({
      minPasswordLength,
      requireSpecialChars,
      sessionTimeoutMinutes,
      allowStudentRegistration,
      forceAnonymousStudentMode,
      maxLoginAttempts,
    });
    if (res.success) {
      showToast('Đã lưu thành công chính sách bảo mật hệ thống');
    } else {
      alert('Lỗi: ' + res.error);
    }
  };

  // Mock Audit Logs (Admin actions)
  const auditLogs = [
    {
      id: 'aud-1',
      adminName: 'Quản trị viên Hệ thống VoVaKi (admin)',
      action: 'Cập nhật phân quyền và cấu hình Website Builder',
      target: 'Dynamic Website Config v2.4',
      ip: '192.168.1.102',
      timestamp: '2026-09-13 14:45:10',
      status: 'success',
    },
    {
      id: 'aud-2',
      adminName: 'ThS. Nguyễn Mai Phương (gv_tuvan)',
      action: 'Xác nhận lịch hẹn tư vấn tâm lý 1-1',
      target: 'Học sinh HS-8392 (Nguyễn Hoài Nam)',
      ip: '192.168.1.115',
      timestamp: '2026-09-13 11:20:00',
      status: 'success',
    },
    {
      id: 'aud-3',
      adminName: 'Quản trị viên Hệ thống VoVaKi (admin)',
      action: 'Khởi tạo bản sao lưu toàn diện Cơ sở Dữ liệu',
      target: 'vovaki_backup_2026_09_12.json',
      ip: '192.168.1.102',
      timestamp: '2026-09-12 23:00:00',
      status: 'success',
    },
    {
      id: 'aud-4',
      adminName: 'Thầy Trần Quốc Bảo (gv_chunhiem10)',
      action: 'Gắn cờ theo dõi đặc biệt sức khỏe tâm thần',
      target: 'Học sinh VVK-10012',
      ip: '192.168.1.140',
      timestamp: '2026-09-12 16:15:32',
      status: 'success',
    },
    {
      id: 'aud-5',
      adminName: 'Quản trị viên Hệ thống VoVaKi (admin)',
      action: 'Cấp mới tài khoản Giáo viên tư vấn',
      target: 'usr-counselor-2 (ThS. Lê Minh Đức)',
      ip: '192.168.1.102',
      timestamp: '2026-09-11 09:30:15',
      status: 'success',
    },
  ];

  // Login Logs
  const loginLogs = [
    {
      id: 'log-1',
      username: 'admin',
      role: 'Quản trị viên',
      ip: '118.70.12.84',
      device: 'Chrome 128 / macOS Sequoia',
      timestamp: '2026-09-13 14:02:15',
      status: 'Thành công',
    },
    {
      id: 'log-2',
      username: 'gv_tuvan',
      role: 'GV Tư vấn',
      ip: '14.232.208.51',
      device: 'Safari 18 / iPadOS',
      timestamp: '2026-09-13 11:15:40',
      status: 'Thành công',
    },
    {
      id: 'log-3',
      username: 'hs_nam',
      role: 'Học sinh',
      ip: '171.244.35.12',
      device: 'Mobile Safari / iOS 18',
      timestamp: '2026-09-13 10:45:00',
      status: 'Thành công',
    },
    {
      id: 'log-4',
      username: 'guest_test',
      role: 'Không xác định',
      ip: '42.119.145.2',
      device: 'Firefox 130 / Windows 11',
      timestamp: '2026-09-13 08:12:09',
      status: 'Sai mật khẩu',
    },
    {
      id: 'log-5',
      username: 'gv_chunhiem10',
      role: 'GV Chủ nhiệm',
      ip: '14.232.208.51',
      device: 'Chrome 128 / Windows 11',
      timestamp: '2026-09-12 15:30:22',
      status: 'Thành công',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-white px-5 py-3 rounded-2xl shadow-xl border border-stone-700 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-stone-100 text-stone-800">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-stone-700">
              An Ninh & Kiểm Toán
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight">
            Trung Tâm Bảo Mật & Nhật Ký Truy Cập
          </h2>
          <p className="text-xs text-stone-600 max-w-2xl">
            Giám sát toàn diện lịch sử thao tác của ban quản trị (Audit Logs), nhật ký đăng nhập và thiết lập chính sách an toàn thông tin theo tiêu chuẩn học đường.
          </p>
        </div>

        {/* Sub-tab Navigation */}
        <div className="flex flex-wrap items-center gap-1.5 bg-stone-100 p-1.5 rounded-2xl border border-stone-200">
          <button
            type="button"
            onClick={() => setActiveTab('audit')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'audit'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Audit Logs ({auditLogs.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('login_logs')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'login_logs'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Login Logs ({loginLogs.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'settings'
                ? 'bg-white text-stone-900 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Security Settings</span>
          </button>
        </div>
      </div>

      {/* ================= 1. AUDIT LOGS ================= */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-stone-900 text-base">Nhật Ký Kiểm Toán Thao Tác Quản Trị</h3>
              <p className="text-xs text-stone-500">
                Ghi nhận chi tiết mọi hành vi thêm, xóa, sửa, xuất dữ liệu và đổi cấu hình hệ thống.
              </p>
            </div>
            <button
              type="button"
              onClick={() => showToast('Đang xuất tệp Audit Logs định dạng CSV...')}
              className="px-3.5 py-2 rounded-xl border border-stone-200 hover:bg-stone-50 text-stone-700 font-bold text-xs flex items-center gap-1.5"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>Xuất Audit CSV</span>
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="px-5 py-3.5">Người thực hiện</th>
                    <th className="px-4 py-3.5">Hành động</th>
                    <th className="px-4 py-3.5">Đối tượng chịu tác động</th>
                    <th className="px-4 py-3.5">Địa chỉ IP</th>
                    <th className="px-4 py-3.5 text-right">Thời gian</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {auditLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-stone-50 transition-colors">
                      <td className="px-5 py-3.5 font-bold text-stone-900">{log.adminName}</td>
                      <td className="px-4 py-3.5 font-semibold text-purple-800">{log.action}</td>
                      <td className="px-4 py-3.5 text-stone-600 font-mono text-[11px]">{log.target}</td>
                      <td className="px-4 py-3.5 text-stone-500 font-mono">{log.ip}</td>
                      <td className="px-4 py-3.5 text-right text-stone-400 font-mono">{log.timestamp}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= 2. LOGIN LOGS ================= */}
      {activeTab === 'login_logs' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs space-y-1">
            <h3 className="font-bold text-stone-900 text-base">Nhật Ký Đăng Nhập Hệ Thống</h3>
            <p className="text-xs text-stone-500">
              Giám sát các lần đăng nhập từ học sinh, giáo viên và tài khoản quản trị.
            </p>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="px-5 py-3.5">Tài khoản</th>
                    <th className="px-4 py-3.5">Vai trò</th>
                    <th className="px-4 py-3.5">Trình duyệt & Thiết bị</th>
                    <th className="px-4 py-3.5">Địa chỉ IP</th>
                    <th className="px-4 py-3.5">Trạng thái</th>
                    <th className="px-4 py-3.5 text-right">Thời điểm</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {loginLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-stone-50 transition-colors">
                      <td className="px-5 py-3.5 font-mono font-bold text-stone-900">{log.username}</td>
                      <td className="px-4 py-3.5 font-semibold text-stone-700">{log.role}</td>
                      <td className="px-4 py-3.5 text-stone-500">{log.device}</td>
                      <td className="px-4 py-3.5 font-mono text-stone-600">{log.ip}</td>
                      <td className="px-4 py-3.5">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            log.status === 'Thành công'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {log.status}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-right text-stone-400 font-mono">{log.timestamp}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= 3. SECURITY SETTINGS ================= */}
      {activeTab === 'settings' && (
        <div className="space-y-4">
          <form onSubmit={handleSaveSecuritySettings} className="bg-white p-6 rounded-3xl border border-stone-200 shadow-2xs space-y-6">
            <div>
              <h3 className="font-bold text-stone-900 text-base">Cấu Hình Chính Sách An Toàn & Bảo Mật</h3>
              <p className="text-xs text-stone-500">
                Quy định độ phức tạp mật khẩu, thời hạn phiên làm việc và bảo mật danh tính học sinh.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
              <div className="space-y-4">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Độ dài mật khẩu tối thiểu:
                  </label>
                  <input
                    type="number"
                    min="4"
                    max="32"
                    value={minPasswordLength}
                    onChange={(e) => setMinPasswordLength(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 font-semibold"
                  />
                  <p className="text-[11px] text-stone-400 mt-1">Khuyến nghị tối thiểu 6 ký tự cho trường học.</p>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Thời gian hết hạn phiên làm việc (Session Timeout):
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="10"
                      max="1440"
                      value={sessionTimeoutMinutes}
                      onChange={(e) => setSessionTimeoutMinutes(parseInt(e.target.value, 10))}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 font-semibold"
                    />
                    <span className="text-stone-500 font-bold shrink-0">phút</span>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">
                    Số lần đăng nhập sai tối đa trước khi tạm khóa:
                  </label>
                  <input
                    type="number"
                    min="3"
                    max="10"
                    value={maxLoginAttempts}
                    onChange={(e) => setMaxLoginAttempts(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 font-semibold"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-stone-900">Bắt buộc chế độ ẩn danh cho học sinh:</div>
                    <div className="text-[11px] text-stone-500">Mã hóa tên học sinh thành mã HS-XXXX khi chat tư vấn</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={forceAnonymousStudentMode}
                    onChange={(e) => setForceAnonymousStudentMode(e.target.checked)}
                    className="w-4 h-4 accent-purple-600"
                  />
                </div>

                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-stone-900">Yêu cầu ký tự đặc biệt trong mật khẩu:</div>
                    <div className="text-[11px] text-stone-500">Bắt buộc có ít nhất 1 chữ hoa và 1 ký tự đặc biệt</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={requireSpecialChars}
                    onChange={(e) => setRequireSpecialChars(e.target.checked)}
                    className="w-4 h-4 accent-purple-600"
                  />
                </div>

                <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-stone-900">Cho phép học sinh tự đăng ký tài khoản:</div>
                    <div className="text-[11px] text-stone-500">Nếu tắt, chỉ quản trị viên mới có thể cấp phát tài khoản</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={allowStudentRegistration}
                    onChange={(e) => setAllowStudentRegistration(e.target.checked)}
                    className="w-4 h-4 accent-purple-600"
                  />
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-stone-100 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-2xl bg-stone-900 hover:bg-black text-white font-bold text-xs flex items-center gap-1.5 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>Lưu Chính Sách Bảo Mật</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
