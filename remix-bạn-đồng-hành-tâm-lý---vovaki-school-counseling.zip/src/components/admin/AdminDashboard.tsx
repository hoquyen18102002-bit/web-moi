import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AdminOverview } from './AdminOverview';
import { AdminUserManagement } from './AdminUserManagement';
import { AdminPsychologyManager } from './AdminPsychologyManager';
import { AdminCounselingManager } from './AdminCounselingManager';
import { AdminAiManager } from './AdminAiManager';
import { AdminContentHub } from './AdminContentHub';
import { AdminWebsiteManager } from './AdminWebsiteManager';
import { AdminRealtimeManager } from './AdminRealtimeManager';
import { AdminDatabaseManager } from './AdminDatabaseManager';
import { AdminSecurityManager } from './AdminSecurityManager';
import { AdminSystemSettings } from './AdminSystemSettings';
import {
  BarChart3,
  Users,
  Brain,
  MessageCircle,
  Bot,
  FileText,
  Palette,
  Bell,
  Database,
  ShieldCheck,
  Settings,
  ChevronDown,
  ChevronRight,
  Shield,
  Search,
  CheckCircle2,
  Menu,
  X,
} from 'lucide-react';

export type AdminMainModule =
  | 'overview'
  | 'users'
  | 'psychology'
  | 'counseling'
  | 'ai'
  | 'content'
  | 'builder'
  | 'notifications'
  | 'database'
  | 'security'
  | 'system_settings';

interface NavItem {
  id: AdminMainModule;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number | string;
  children?: { id: string; label: string }[];
}

export const AdminDashboard: React.FC = () => {
  const { state } = useApp();

  const [activeModule, setActiveModule] = useState<AdminMainModule>('overview');
  const [activeSubTab, setActiveSubTab] = useState<string>('');
  const [expandedModules, setExpandedModules] = useState<Record<string, boolean>>({
    users: true,
    psychology: true,
    counseling: true,
    ai: true,
    content: true,
    builder: true,
    security: true,
  });

  const [searchMenuQuery, setSearchMenuQuery] = useState('');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  const pendingBookingsCount =
    state.bookings?.filter((b) => b.status === 'Chờ xác nhận').length || 0;
  const emergencyCount = state.emergencySessions?.length || 0;
  const highRiskStudents =
    state.studentRecords?.filter(
      (s) => s.currentMentalStatus === 'high_risk' || s.currentMentalStatus === 'crisis'
    ).length || 0;

  const navItems: NavItem[] = [
    {
      id: 'overview',
      label: 'Tổng quan',
      icon: BarChart3,
    },
    {
      id: 'users',
      label: 'Người dùng',
      icon: Users,
      badge: state.users?.length || 0,
      children: [
        { id: 'students', label: 'Học sinh' },
        { id: 'teachers', label: 'Giáo viên' },
        { id: 'counselors', label: 'GV tư vấn' },
        { id: 'accounts', label: 'Tài khoản' },
        { id: 'roles', label: 'Vai trò & phân quyền' },
      ],
    },
    {
      id: 'psychology',
      label: 'Tâm lý học sinh',
      icon: Brain,
      badge: highRiskStudents > 0 ? `${highRiskStudents} báo động` : undefined,
      children: [
        { id: 'records', label: 'Hồ sơ tâm lý' },
        { id: 'tests', label: 'Trắc nghiệm' },
        { id: 'results', label: 'Kết quả' },
        { id: 'alerts', label: 'Cảnh báo' },
        { id: 'stats', label: 'Thống kê' },
      ],
    },
    {
      id: 'counseling',
      label: 'Tư vấn',
      icon: MessageCircle,
      badge: pendingBookingsCount + emergencyCount > 0 ? pendingBookingsCount + emergencyCount : undefined,
      children: [
        { id: 'bookings', label: 'Lịch hẹn' },
        { id: 'sessions', label: 'Phiên tư vấn' },
        { id: 'positive_room', label: 'Phòng tích cực' },
        { id: 'emergency', label: 'Tư vấn khẩn cấp' },
      ],
    },
    {
      id: 'ai',
      label: 'AI',
      icon: Bot,
      children: [
        { id: 'config', label: 'AI Configuration' },
        { id: 'prompt', label: 'AI Prompt' },
        { id: 'voice', label: 'Voice / TTS' },
        { id: 'chat_settings', label: 'Chat Settings' },
        { id: 'logs', label: 'AI Logs' },
      ],
    },
    {
      id: 'content',
      label: 'Nội dung',
      icon: FileText,
      badge: state.articles?.length || 0,
      children: [
        { id: 'articles', label: 'Bài viết' },
        { id: 'announcements', label: 'Thông báo' },
        { id: 'documents', label: 'Tài liệu' },
        { id: 'media', label: 'Media Library' },
      ],
    },
    {
      id: 'builder',
      label: 'Website Builder',
      icon: Palette,
      children: [
        { id: 'pages', label: 'Trang' },
        { id: 'header', label: 'Header' },
        { id: 'menu', label: 'Menu' },
        { id: 'footer', label: 'Footer' },
        { id: 'theme', label: 'Theme' },
        { id: 'components', label: 'Components' },
      ],
    },
    {
      id: 'notifications',
      label: 'Thông báo',
      icon: Bell,
    },
    {
      id: 'database',
      label: 'Sao lưu & CSDL',
      icon: Database,
    },
    {
      id: 'security',
      label: 'Bảo mật',
      icon: ShieldCheck,
      children: [
        { id: 'audit', label: 'Audit Logs' },
        { id: 'login_logs', label: 'Login Logs' },
        { id: 'settings', label: 'Security Settings' },
      ],
    },
    {
      id: 'system_settings',
      label: 'Cài đặt hệ thống',
      icon: Settings,
    },
  ];

  const toggleModuleExpand = (modId: string) => {
    setExpandedModules((prev) => ({ ...prev, [modId]: !prev[modId] }));
  };

  const handleSelectModule = (modId: AdminMainModule, subId?: string) => {
    setActiveModule(modId);
    if (subId) {
      setActiveSubTab(subId);
    } else {
      setActiveSubTab('');
    }
    setMobileSidebarOpen(false);
  };

  const currentNav = navItems.find((n) => n.id === activeModule);
  const currentSub = currentNav?.children?.find((c) => c.id === activeSubTab);

  // Filter nav for quick search
  const filteredNavItems = navItems.filter((item) => {
    if (!searchMenuQuery.trim()) return true;
    const query = searchMenuQuery.toLowerCase();
    const matchesParent = item.label.toLowerCase().includes(query);
    const matchesChild = item.children?.some((c) => c.label.toLowerCase().includes(query));
    return matchesParent || matchesChild;
  });

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-purple-100 text-purple-700">
              <Shield className="w-4 h-4" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-purple-800">
              Quản Trị Viên Hệ Thống (Admin)
            </span>
            <span className="text-xs text-stone-400 font-mono">• vovaki-core-v2.6</span>
          </div>

          <h1 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight">
            Admin Dashboard Điều Hành Toàn Diện
          </h1>

          <div className="flex items-center gap-1.5 text-xs text-stone-500 pt-0.5">
            <span className="font-semibold text-stone-800">Bảng điều khiển</span>
            <span>&gt;</span>
            <span className="font-bold text-purple-700">{currentNav?.label || 'Tổng quan'}</span>
            {currentSub && (
              <>
                <span>&gt;</span>
                <span className="text-stone-700 font-medium">{currentSub.label}</span>
              </>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Mobile menu button */}
          <button
            type="button"
            onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
            className="lg:hidden p-2.5 rounded-2xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold flex items-center gap-1.5"
          >
            {mobileSidebarOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            <span>Danh mục</span>
          </button>
        </div>
      </div>

      {/* Layout: Sidebar + Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Sidebar Navigation */}
        <div
          className={`lg:col-span-3 bg-white rounded-3xl border border-stone-200 shadow-2xs p-4 space-y-4 ${
            mobileSidebarOpen ? 'block' : 'hidden lg:block'
          }`}
        >
          {/* Quick Menu Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={searchMenuQuery}
              onChange={(e) => setSearchMenuQuery(e.target.value)}
              placeholder="Tìm phân hệ admin..."
              className="w-full pl-8 pr-3 py-2 rounded-xl bg-stone-50 border border-stone-200 text-xs font-medium text-stone-800 outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>

          {/* Navigation Tree */}
          <nav className="space-y-1 text-xs">
            {filteredNavItems.map((item) => {
              const Icon = item.icon;
              const isSelected = activeModule === item.id;
              const isExpanded = expandedModules[item.id] ?? false;
              const hasChildren = item.children && item.children.length > 0;

              return (
                <div key={item.id} className="space-y-0.5">
                  <div
                    className={`group flex items-center justify-between px-3 py-2 rounded-2xl cursor-pointer transition-all ${
                      isSelected && !activeSubTab
                        ? 'bg-purple-600 text-white font-bold shadow-xs'
                        : isSelected
                        ? 'bg-purple-50 text-purple-900 font-bold'
                        : 'text-stone-700 hover:bg-stone-100'
                    }`}
                    onClick={() => {
                      if (hasChildren) {
                        toggleModuleExpand(item.id);
                        if (!isSelected) {
                          handleSelectModule(item.id, item.children![0].id);
                        }
                      } else {
                        handleSelectModule(item.id);
                      }
                    }}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Icon
                        className={`w-4 h-4 shrink-0 ${
                          isSelected && !activeSubTab ? 'text-white' : 'text-purple-600'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {item.badge !== undefined && (
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            isSelected && !activeSubTab
                              ? 'bg-white/20 text-white'
                              : 'bg-purple-100 text-purple-800'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                      {hasChildren && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleModuleExpand(item.id);
                          }}
                          className="p-1 hover:bg-black/5 rounded-lg"
                        >
                          {isExpanded ? (
                            <ChevronDown className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronRight className="w-3.5 h-3.5" />
                          )}
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Sub-items branch */}
                  {hasChildren && isExpanded && (
                    <div className="pl-6 pr-1 py-0.5 space-y-0.5 border-l-2 border-stone-200 ml-4">
                      {item.children!.map((child) => {
                        const isChildActive = activeModule === item.id && activeSubTab === child.id;
                        return (
                          <div
                            key={child.id}
                            onClick={() => handleSelectModule(item.id, child.id)}
                            className={`px-3 py-1.5 rounded-xl cursor-pointer transition-colors flex items-center justify-between ${
                              isChildActive
                                ? 'bg-purple-600 text-white font-bold shadow-2xs'
                                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-50 font-medium'
                            }`}
                          >
                            <span>{child.label}</span>
                            {isChildActive && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </nav>
        </div>

        {/* Right Main Panel */}
        <div className="lg:col-span-9 min-w-0">
          {activeModule === 'overview' && (
            <AdminOverview onNavigate={(module, subTab) => handleSelectModule(module as any, subTab)} />
          )}

          {activeModule === 'users' && (
            <AdminUserManagement initialSubTab={activeSubTab as any || 'accounts'} />
          )}

          {activeModule === 'psychology' && (
            <AdminPsychologyManager initialSubTab={activeSubTab as any || 'records'} />
          )}

          {activeModule === 'counseling' && (
            <AdminCounselingManager initialSubTab={activeSubTab as any || 'bookings'} />
          )}

          {activeModule === 'ai' && (
            <AdminAiManager initialSubTab={activeSubTab as any || 'config'} />
          )}

          {activeModule === 'content' && (
            <AdminContentHub initialSubTab={activeSubTab as any || 'articles'} />
          )}

          {activeModule === 'builder' && (
            <AdminWebsiteManager initialSubTab={activeSubTab as any || 'pages'} />
          )}

          {activeModule === 'notifications' && <AdminRealtimeManager />}

          {activeModule === 'database' && <AdminDatabaseManager />}

          {activeModule === 'security' && (
            <AdminSecurityManager initialSubTab={activeSubTab as any || 'audit'} />
          )}

          {activeModule === 'system_settings' && <AdminSystemSettings />}
        </div>
      </div>
    </div>
  );
};
