import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Radio,
  Activity,
  Wifi,
  Bell,
  Send,
  X,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  Sliders,
  Sparkles,
  Zap,
} from 'lucide-react';

export const AdminRealtimeManager: React.FC = () => {
  const { state, currentUser, publishBroadcastAlert, dismissBroadcastAlert, updateRealtimeSettings } = useApp();

  const realtimeSettings = state.realtimeSettings || {
    pollingIntervalMs: 3000,
    enableLiveSync: true,
    enableNotifications: true,
    broadcastAlert: null,
  };

  const [broadcastMessage, setBroadcastMessage] = useState(
    realtimeSettings.broadcastAlert?.message || ''
  );
  const [broadcastLevel, setBroadcastLevel] = useState<'info' | 'warning' | 'emergency'>(
    realtimeSettings.broadcastAlert?.level || 'warning'
  );
  const [pollingInterval, setPollingInterval] = useState<number>(
    realtimeSettings.pollingIntervalMs || 3000
  );
  const [enableLiveSync, setEnableLiveSync] = useState<boolean>(
    realtimeSettings.enableLiveSync ?? true
  );
  const [enableNotifications, setEnableNotifications] = useState<boolean>(
    realtimeSettings.enableNotifications ?? true
  );

  const [toastMsg, setToastMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMsg({ type, text });
    setTimeout(() => setToastMsg(null), 4000);
  };

  // Publish school-wide broadcast
  const handlePublishBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMessage.trim()) {
      showToast('Vui lòng nhập nội dung phát sóng khẩn cấp', 'error');
      return;
    }
    setIsProcessing(true);
    const res = await publishBroadcastAlert(
      broadcastMessage.trim(),
      broadcastLevel,
      currentUser?.fullName || 'Quản trị viên Hệ thống'
    );
    setIsProcessing(false);

    if (res.success) {
      showToast('Đã phát sóng thông báo khẩn cấp tới toàn bộ màn hình người dùng!');
    } else {
      showToast(res.error || 'Phát sóng thất bại', 'error');
    }
  };

  // Dismiss broadcast
  const handleDismissBroadcast = async () => {
    setIsProcessing(true);
    const res = await dismissBroadcastAlert();
    setIsProcessing(false);

    if (res.success) {
      showToast('Đã gỡ bỏ thông báo phát sóng khỏi thanh đầu trang');
      setBroadcastMessage('');
    } else {
      showToast(res.error || 'Gỡ bỏ thông báo thất bại', 'error');
    }
  };

  // Save realtime settings
  const handleSaveSettings = async () => {
    setIsProcessing(true);
    const res = await updateRealtimeSettings({
      pollingIntervalMs: pollingInterval,
      enableLiveSync,
      enableNotifications,
    });
    setIsProcessing(false);

    if (res.success) {
      showToast(`Đã lưu cấu hình Real-time! Tần suất làm mới: ${pollingInterval / 1000}s`);
    } else {
      showToast(res.error || 'Lưu cấu hình thất bại', 'error');
    }
  };

  const isAlertActive = realtimeSettings.broadcastAlert?.active;

  return (
    <div className="space-y-6">
      {/* Toast Notice */}
      {toastMsg && (
        <div
          className={`p-4 rounded-xl text-xs font-semibold flex items-center justify-between shadow-xs transition-all ${
            toastMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {toastMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span>{toastMsg.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setToastMsg(null)}
            className="p-1 hover:bg-black/5 rounded text-stone-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header and Live Status Card */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center font-bold">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="font-bold text-base text-stone-900">
              Quản lý Đồng bộ Real-time & Phát sóng Toàn trường
            </h3>
            <p className="text-xs text-stone-500">
              Điều chỉnh tần suất làm mới dữ liệu, giám sát độ trễ và phát tín hiệu khẩn cấp tức thời
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            KẾT NỐI REAL-TIME: TRỰC TUYẾN
          </span>
        </div>
      </div>

      {/* Live Server Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Wifi className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] text-stone-500 font-medium">Độ trễ trung bình</div>
            <div className="text-base font-mono font-bold text-stone-900">~12 ms</div>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] text-stone-500 font-medium">Tần suất Polling hiện tại</div>
            <div className="text-base font-mono font-bold text-stone-900">
              {realtimeSettings.pollingIntervalMs / 1000} giây / lần
            </div>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] text-stone-500 font-medium">Trạng thái Phát sóng</div>
            <div className="text-base font-bold text-stone-900">
              {isAlertActive ? (
                <span className="text-red-600 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-red-600 animate-ping" />
                  Đang phát sóng
                </span>
              ) : (
                <span className="text-stone-400">Không có cảnh báo</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Module 1: School-wide Emergency Live Broadcast */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-bold text-base text-stone-900 flex items-center gap-2">
              <Radio className="w-5 h-5 text-red-600" />
              <span>Phát sóng Khẩn cấp Toàn trường (Live School-wide Alert)</span>
            </h4>
            <p className="text-xs text-stone-500 mt-0.5">
              Khi kích hoạt, thông điệp này sẽ xuất hiện trên thanh điều hướng đầu trang của mọi học sinh, giáo viên ngay lập tức
            </p>
          </div>

          {isAlertActive && (
            <button
              type="button"
              onClick={handleDismissBroadcast}
              disabled={isProcessing}
              className="px-3.5 py-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold flex items-center gap-1.5"
            >
              <X className="w-4 h-4" />
              <span>Gỡ thông báo đang phát</span>
            </button>
          )}
        </div>

        <form onSubmit={handlePublishBroadcast} className="space-y-4 pt-2">
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Mức độ cảnh báo
            </label>
            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setBroadcastLevel('info')}
                className={`py-2 px-3 rounded-lg text-xs font-bold border transition-all ${
                  broadcastLevel === 'info'
                    ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                    : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                }`}
              >
                Thông tin chung (Xanh)
              </button>
              <button
                type="button"
                onClick={() => setBroadcastLevel('warning')}
                className={`py-2 px-3 rounded-lg text-xs font-bold border transition-all ${
                  broadcastLevel === 'warning'
                    ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                    : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                }`}
              >
                Cảnh báo quan trọng (Vàng cam)
              </button>
              <button
                type="button"
                onClick={() => setBroadcastLevel('emergency')}
                className={`py-2 px-3 rounded-lg text-xs font-bold border transition-all ${
                  broadcastLevel === 'emergency'
                    ? 'bg-red-600 text-white border-red-700 shadow-xs'
                    : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                }`}
              >
                Khẩn cấp toàn trường (Đỏ chớp)
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Nội dung thông điệp phát sóng <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={3}
              required
              value={broadcastMessage}
              onChange={(e) => setBroadcastMessage(e.target.value)}
              placeholder="VD: Phòng Tâm lý học đường mở cửa tăng cường tiếp nhận hỗ trợ các bạn học sinh gặp khó khăn tâm lý trước kỳ thi tốt nghiệp..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-purple-500 focus:outline-none"
            />
          </div>

          {/* Live Preview */}
          <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
            <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block mb-2">
              Xem trước banner phát sóng trên Navbar:
            </span>
            <div
              className={`p-2.5 rounded-lg text-xs text-white font-medium flex items-center justify-between gap-3 ${
                broadcastLevel === 'emergency'
                  ? 'bg-red-600'
                  : broadcastLevel === 'warning'
                  ? 'bg-amber-600'
                  : 'bg-emerald-600'
              }`}
            >
              <div className="flex items-center gap-2 truncate">
                <span className="px-2 py-0.5 rounded bg-black/20 text-[10px] font-bold shrink-0">
                  {broadcastLevel.toUpperCase()}
                </span>
                <span className="truncate">{broadcastMessage || '(Chưa nhập nội dung phát sóng)'}</span>
              </div>
              <span className="text-[10px] opacity-75 shrink-0">vừa xong</span>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={isProcessing}
              className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs transition-all flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>{isProcessing ? 'Đang phát sóng...' : 'Bắt đầu Phát sóng Toàn trường'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* Module 2: Real-time Sync Engine Settings */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-6">
        <div>
          <h4 className="font-bold text-base text-stone-900 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-purple-600" />
            <span>Cấu hình Động cơ Đồng bộ (Sync Engine)</span>
          </h4>
          <p className="text-xs text-stone-500 mt-0.5">
            Tối ưu hóa băng thông và độ mượt mà khi trao đổi tin nhắn trực tiếp giữa các phòng tư vấn
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Tần suất Quét & Cập nhật Dữ liệu (Polling Interval)
            </label>
            <select
              value={pollingInterval}
              onChange={(e) => setPollingInterval(Number(e.target.value))}
              className="w-full px-3.5 py-2 rounded-lg border border-stone-300 text-xs font-medium"
            >
              <option value={1500}>1.5 giây / lần (Cực nhanh - Đòi hỏi mạng ổn định)</option>
              <option value={3000}>3.0 giây / lần (Khuyến nghị chuẩn)</option>
              <option value={5000}>5.0 giây / lần (Tiết kiệm băng thông)</option>
              <option value={10000}>10 giây / lần (Chế độ tiết kiệm tối đa)</option>
            </select>
          </div>

          <div className="space-y-3 pt-1">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={enableLiveSync}
                onChange={(e) => setEnableLiveSync(e.target.checked)}
                className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
              />
              <div>
                <span className="text-xs font-bold text-stone-800 block">
                  Tự động đồng bộ tin nhắn Live Chat
                </span>
                <span className="text-[11px] text-stone-400">
                  Cập nhật liên tục tin nhắn trong phòng tư vấn và phòng tích cực Vovakier
                </span>
              </div>
            </label>

            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={enableNotifications}
                onChange={(e) => setEnableNotifications(e.target.checked)}
                className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
              />
              <div>
                <span className="text-xs font-bold text-stone-800 block">
                  Thông báo phiên khẩn cấp mới
                </span>
                <span className="text-[11px] text-stone-400">
                  Phát chuông thông báo cho giáo viên khi có học sinh yêu cầu can thiệp khẩn
                </span>
              </div>
            </label>
          </div>
        </div>

        <div className="pt-4 border-t border-stone-200 flex justify-end">
          <button
            type="button"
            onClick={handleSaveSettings}
            disabled={isProcessing}
            className="px-6 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs shadow-xs transition-all"
          >
            {isProcessing ? 'Đang lưu...' : 'Áp dụng Cấu hình Real-time'}
          </button>
        </div>
      </div>
    </div>
  );
};
