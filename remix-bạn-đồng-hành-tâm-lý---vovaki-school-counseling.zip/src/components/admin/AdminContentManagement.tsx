import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Article, PsychologicalTest } from '../../types';
import {
  FileText,
  Palette,
  Globe,
  Plus,
  Trash2,
  Edit2,
  Check,
  CheckCircle2,
  AlertCircle,
  X,
  Sparkles,
  ClipboardList,
  Eye,
  Sliders,
  RotateCcw,
} from 'lucide-react';

export const AdminContentManagement: React.FC = () => {
  const {
    state,
    updateSharedState,
    createArticle,
    updateArticle,
    deleteArticle,
    createTest,
    deleteTest,
  } = useApp();

  const [subSection, setSubSection] = useState<'articles' | 'tests' | 'appearance' | 'site_info'>('articles');
  const [toastMsg, setToastMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Article management state
  const [showAddArticleModal, setShowAddArticleModal] = useState(false);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [articleToDelete, setArticleToDelete] = useState<Article | null>(null);
  const [newArticle, setNewArticle] = useState({
    title: '',
    category: 'Áp lực học tập',
    author: 'Ban Tư vấn Tâm lý Trường',
    readTime: '4 phút',
    summary: '',
    content: '',
    imageUrl: 'https://images.unsplash.com/photo-1516534775068-ba3e7458af70?auto=format&fit=crop&w=800&q=80',
  });

  // Psychological Test management state
  const [showAddTestModal, setShowAddTestModal] = useState(false);
  const [testToDelete, setTestToDelete] = useState<PsychologicalTest | null>(null);
  const [newTest, setNewTest] = useState({
    title: '',
    targetGrade: 'Khối 10, 11, 12 (Toàn trường)',
    description: '',
    totalQuestions: 15,
  });

  // Appearance state
  const [primaryColor, setPrimaryColor] = useState(state.siteSettings.primaryColor);
  const [fontFamily, setFontFamily] = useState(state.siteSettings.fontFamily);
  const [theme, setTheme] = useState(state.siteSettings.theme);
  const [navButtonPosition, setNavButtonPosition] = useState(state.siteSettings.navButtonPosition);

  // Site info state
  const [siteName, setSiteName] = useState(state.siteSettings.siteName);
  const [bannerUrl, setBannerUrl] = useState(state.siteSettings.bannerUrl);
  const [backdropUrl, setBackdropUrl] = useState(state.siteSettings.backdropUrl);
  const [footerPhone, setFooterPhone] = useState(state.siteSettings.footerInfo.phone);
  const [footerHotline, setFooterHotline] = useState(state.siteSettings.footerInfo.hotline);
  const [footerEmail, setFooterEmail] = useState(state.siteSettings.footerInfo.email);
  const [footerFacebook, setFooterFacebook] = useState(state.siteSettings.footerInfo.facebook);
  const [footerZalo, setFooterZalo] = useState(state.siteSettings.footerInfo.zalo);
  const [footerAddress, setFooterAddress] = useState(state.siteSettings.footerInfo.address);

  const [isProcessing, setIsProcessing] = useState(false);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMsg({ type, text });
    setTimeout(() => setToastMsg(null), 4000);
  };

  // Article handlers
  const handleCreateArticleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newArticle.title.trim() || !newArticle.summary.trim()) {
      showToast('Vui lòng nhập đầy đủ tiêu đề và tóm tắt bài viết', 'error');
      return;
    }
    setIsProcessing(true);
    const res = await createArticle(newArticle);
    setIsProcessing(false);

    if (res.success) {
      showToast(`Đã xuất bản bài viết cẩm nang: "${newArticle.title}"`);
      setShowAddArticleModal(false);
      setNewArticle({
        title: '',
        category: 'Áp lực học tập',
        author: 'Ban Tư vấn Tâm lý Trường',
        readTime: '4 phút',
        summary: '',
        content: '',
        imageUrl: 'https://images.unsplash.com/photo-1516534775068-ba3e7458af70?auto=format&fit=crop&w=800&q=80',
      });
    } else {
      showToast(res.error || 'Thêm bài viết thất bại', 'error');
    }
  };

  const handleUpdateArticleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingArticle) return;
    setIsProcessing(true);
    const res = await updateArticle(editingArticle.id, editingArticle);
    setIsProcessing(false);

    if (res.success) {
      showToast(`Đã lưu cập nhật bài viết: "${editingArticle.title}"`);
      setEditingArticle(null);
    } else {
      showToast(res.error || 'Cập nhật bài viết thất bại', 'error');
    }
  };

  const handleDeleteArticle = async () => {
    if (!articleToDelete) return;
    setIsProcessing(true);
    const res = await deleteArticle(articleToDelete.id);
    setIsProcessing(false);

    if (res.success) {
      showToast(`Đã xóa bài viết "${articleToDelete.title}"`);
      setArticleToDelete(null);
    } else {
      showToast(res.error || 'Xóa bài viết thất bại', 'error');
    }
  };

  // Test handlers
  const handleCreateTestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTest.title.trim() || !newTest.description.trim()) {
      showToast('Vui lòng nhập tiêu đề và mô tả bài khảo sát', 'error');
      return;
    }
    setIsProcessing(true);
    const res = await createTest({
      ...newTest,
      totalQuestions: Number(newTest.totalQuestions) || 10,
    });
    setIsProcessing(false);

    if (res.success) {
      showToast(`Đã thêm bài khảo sát mới: "${newTest.title}"`);
      setShowAddTestModal(false);
      setNewTest({
        title: '',
        targetGrade: 'Khối 10, 11, 12 (Toàn trường)',
        description: '',
        totalQuestions: 15,
      });
    } else {
      showToast(res.error || 'Thêm bài test thất bại', 'error');
    }
  };

  const handleDeleteTest = async () => {
    if (!testToDelete) return;
    setIsProcessing(true);
    const res = await deleteTest(testToDelete.id);
    setIsProcessing(false);

    if (res.success) {
      showToast(`Đã gỡ bỏ bài khảo sát: "${testToDelete.title}"`);
      setTestToDelete(null);
    } else {
      showToast(res.error || 'Xóa bài test thất bại', 'error');
    }
  };

  // Appearance handlers
  const handleSaveAppearance = () => {
    updateSharedState({
      siteSettings: {
        ...state.siteSettings,
        primaryColor,
        fontFamily,
        theme,
        navButtonPosition,
      },
    });
    showToast('Đã lưu cấu hình giao diện & theme Front-end thành công!');
  };

  // Site info handlers
  const handleSaveSiteInfo = () => {
    updateSharedState({
      siteSettings: {
        ...state.siteSettings,
        siteName,
        bannerUrl,
        backdropUrl,
        footerInfo: {
          phone: footerPhone,
          hotline: footerHotline,
          email: footerEmail,
          facebook: footerFacebook,
          zalo: footerZalo,
          address: footerAddress,
        },
      },
    });
    showToast('Đã cập nhật thông tin thương hiệu và liên hệ chân trang!');
  };

  return (
    <div className="space-y-6">
      {/* Toast Notice */}
      {toastMsg && (
        <div
          className={`p-4 rounded-xl text-xs font-semibold flex items-center justify-between shadow-xs transition-all ${
            toastMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {toastMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span>{toastMsg.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setToastMsg(null)}
            className="p-1 hover:bg-black/5 rounded text-stone-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Sub-navigation tabs */}
      <div className="flex flex-wrap gap-2 border-b border-stone-200 pb-3">
        <button
          type="button"
          onClick={() => setSubSection('articles')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
            subSection === 'articles'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Cẩm nang & Bài viết ({state.articles.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setSubSection('tests')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
            subSection === 'tests'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          <span>Bài khảo sát tâm lý ({state.psychologicalTests.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setSubSection('appearance')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
            subSection === 'appearance'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <Palette className="w-4 h-4" />
          <span>Theme & Giao diện Front-end</span>
        </button>

        <button
          type="button"
          onClick={() => setSubSection('site_info')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
            subSection === 'site_info'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <Globe className="w-4 h-4" />
          <span>Thông tin Website & Chân trang</span>
        </button>
      </div>

      {/* 1. ARTICLES SUB-SECTION */}
      {subSection === 'articles' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
            <div>
              <h4 className="font-bold text-sm text-stone-900">
                Danh mục Cẩm nang & Kiến thức Tâm lý học đường
              </h4>
              <p className="text-xs text-stone-500">
                Toàn quyền thêm bài viết mới, chỉnh sửa nội dung và gỡ bỏ bài viết khỏi trang chủ
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowAddArticleModal(true)}
              className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-semibold text-xs flex items-center gap-2 shadow-xs transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm bài viết mới</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {state.articles.map((art) => (
              <div
                key={art.id}
                className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-shadow flex flex-col"
              >
                <div className="h-40 relative bg-stone-100 overflow-hidden">
                  <img
                    src={art.imageUrl}
                    alt={art.title}
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute top-3 left-3 px-2.5 py-1 rounded-md text-[10px] font-bold bg-purple-600 text-white shadow-xs">
                    {art.category}
                  </span>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h5 className="font-bold text-sm text-stone-900 line-clamp-2">{art.title}</h5>
                    <p className="text-xs text-stone-500 mt-1 line-clamp-2">{art.summary}</p>
                  </div>

                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                    <span className="text-[11px] text-stone-400 font-medium">
                      {art.author} • {art.readTime}
                    </span>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setEditingArticle(art)}
                        className="p-1.5 text-stone-500 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                        title="Chỉnh sửa bài viết"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setArticleToDelete(art)}
                        className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Xóa bài viết"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. TESTS SUB-SECTION */}
      {subSection === 'tests' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
            <div>
              <h4 className="font-bold text-sm text-stone-900">
                Các bài Khảo sát & Đánh giá Tâm lý
              </h4>
              <p className="text-xs text-stone-500">
                Quản lý các công cụ trắc nghiệm tâm lý (DASS-21, MBTI, Sức khỏe tinh thần)
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowAddTestModal(true)}
              className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-semibold text-xs flex items-center gap-2 shadow-xs transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Tạo bài test mới</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {state.psychologicalTests.map((t) => (
              <div
                key={t.id}
                className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                      {t.targetGrade}
                    </span>
                    <button
                      type="button"
                      onClick={() => setTestToDelete(t)}
                      className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Gỡ bài test này"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <h5 className="font-bold text-base text-stone-900">{t.title}</h5>
                  <p className="text-xs text-stone-600 leading-relaxed">{t.description}</p>
                </div>

                <div className="pt-4 mt-4 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500">
                  <span>Số câu hỏi: <strong className="text-stone-800">{t.totalQuestions}</strong> câu</span>
                  <span className="text-[11px] bg-stone-100 px-2 py-0.5 rounded font-mono font-semibold">
                    Định danh: {t.id}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. APPEARANCE SUB-SECTION */}
      {subSection === 'appearance' && (
        <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-6">
          <div>
            <h4 className="font-bold text-base text-stone-900">Tùy biến Giao diện & Chủ đề Front-end</h4>
            <p className="text-xs text-stone-500">
              Thay đổi màu sắc chủ đạo, phông chữ và cách bố trí các thành phần trang
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-2">
                Màu sắc chủ đạo (Primary Color)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="w-12 h-10 rounded-lg border border-stone-300 p-1 cursor-pointer"
                />
                <input
                  type="text"
                  value={primaryColor}
                  onChange={(e) => setPrimaryColor(e.target.value)}
                  className="px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono w-32 uppercase"
                />
              </div>
              <div className="flex gap-2 mt-2">
                {['#7e22ce', '#059669', '#2563eb', '#d97706', '#dc2626', '#0f766e'].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setPrimaryColor(c)}
                    className="w-6 h-6 rounded-full border border-stone-300 shadow-2xs"
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-2">
                Phông chữ hiển thị
              </label>
              <select
                value={fontFamily}
                onChange={(e) => setFontFamily(e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg border border-stone-300 text-xs font-medium"
              >
                <option value="Be Vietnam Pro, sans-serif">Be Vietnam Pro (Chuẩn tiếng Việt)</option>
                <option value="Inter, sans-serif">Inter (Hiện đại)</option>
                <option value="Merriweather, serif">Merriweather (Ấm áp, Nhân văn)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-2">
                Vị trí Nút hỗ trợ Khẩn cấp
              </label>
              <select
                value={navButtonPosition}
                onChange={(e) => setNavButtonPosition(e.target.value as any)}
                className="w-full px-3.5 py-2 rounded-lg border border-stone-300 text-xs font-medium"
              >
                <option value="right">Góc phải màn hình (Khuyến nghị)</option>
                <option value="left">Góc trái màn hình</option>
                <option value="bottom">Thanh cố định cạnh dưới</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-2">
                Chế độ màu (Theme)
              </label>
              <select
                value={theme}
                onChange={(e) => setTheme(e.target.value as any)}
                className="w-full px-3.5 py-2 rounded-lg border border-stone-300 text-xs font-medium"
              >
                <option value="light">Sáng thanh lịch (Light - Mặc định)</option>
                <option value="dark">Tối dịu mắt (Dark Night)</option>
                <option value="warm">Ấm áp bảo vệ mắt (Warm Daylight)</option>
              </select>
            </div>
          </div>

          <div className="pt-4 border-t border-stone-200 flex justify-end">
            <button
              type="button"
              onClick={handleSaveAppearance}
              className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs transition-all flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>Áp dụng Giao diện Front-end</span>
            </button>
          </div>
        </div>
      )}

      {/* 4. SITE INFO SUB-SECTION */}
      {subSection === 'site_info' && (
        <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-6">
          <div>
            <h4 className="font-bold text-base text-stone-900">Thông tin Website & Cấu hình Chân trang</h4>
            <p className="text-xs text-stone-500">
              Cập nhật tên cổng thông tin, ảnh bìa trường học và thông tin liên hệ cứu hộ khẩn cấp
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                Tên Cổng Thông tin / Hệ thống
              </label>
              <input
                type="text"
                value={siteName}
                onChange={(e) => setSiteName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-stone-300 text-xs font-bold text-stone-900"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Đường dẫn Banner chính (Hero Banner URL)
                </label>
                <input
                  type="url"
                  value={bannerUrl}
                  onChange={(e) => setBannerUrl(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Đường dẫn Phông nền phụ (Backdrop URL)
                </label>
                <input
                  type="url"
                  value={backdropUrl}
                  onChange={(e) => setBackdropUrl(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Hotline Hỗ trợ 24/7 (Khẩn cấp)
                </label>
                <input
                  type="text"
                  value={footerHotline}
                  onChange={(e) => setFooterHotline(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-bold text-red-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Số điện thoại Phòng Tư vấn
                </label>
                <input
                  type="text"
                  value={footerPhone}
                  onChange={(e) => setFooterPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Email tư vấn trực tuyến
                </label>
                <input
                  type="email"
                  value={footerEmail}
                  onChange={(e) => setFooterEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Địa chỉ liên hệ thực tế
                </label>
                <input
                  type="text"
                  value={footerAddress}
                  onChange={(e) => setFooterAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Fanpage Facebook
                </label>
                <input
                  type="text"
                  value={footerFacebook}
                  onChange={(e) => setFooterFacebook(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Zalo OA kết nối
                </label>
                <input
                  type="text"
                  value={footerZalo}
                  onChange={(e) => setFooterZalo(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-stone-200 flex justify-end">
            <button
              type="button"
              onClick={handleSaveSiteInfo}
              className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs transition-all flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>Cập nhật Thông tin Trang</span>
            </button>
          </div>
        </div>
      )}

      {/* Modal: Add Article */}
      {showAddArticleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-stone-200 overflow-hidden">
            <div className="px-6 py-4 bg-purple-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                <h4 className="font-bold text-base">Thêm Bài viết Cẩm nang Mới</h4>
              </div>
              <button
                type="button"
                onClick={() => setShowAddArticleModal(false)}
                className="p-1 rounded hover:bg-purple-800 text-purple-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateArticleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Tiêu đề bài viết <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newArticle.title}
                  onChange={(e) => setNewArticle({ ...newArticle, title: e.target.value })}
                  placeholder="VD: 5 Cách điều hòa cảm xúc trước mùa thi tuyển sinh..."
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-semibold focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Chuyên mục
                  </label>
                  <select
                    value={newArticle.category}
                    onChange={(e) => setNewArticle({ ...newArticle, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-medium"
                  >
                    <option value="Áp lực học tập">Áp lực học tập</option>
                    <option value="Tâm lý lứa tuổi">Tâm lý lứa tuổi</option>
                    <option value="Giao tiếp bạn bè">Giao tiếp bạn bè</option>
                    <option value="Mối quan hệ gia đình">Mối quan hệ gia đình</option>
                    <option value="Thư giãn tinh thần">Thư giãn tinh thần</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Tác giả
                  </label>
                  <input
                    type="text"
                    value={newArticle.author}
                    onChange={(e) => setNewArticle({ ...newArticle, author: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Thời gian đọc
                  </label>
                  <input
                    type="text"
                    value={newArticle.readTime}
                    onChange={(e) => setNewArticle({ ...newArticle, readTime: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Link ảnh bìa (Cover Image URL)
                </label>
                <input
                  type="url"
                  value={newArticle.imageUrl}
                  onChange={(e) => setNewArticle({ ...newArticle, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Đoạn tóm tắt (Hiển thị ngoài trang chủ) <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  value={newArticle.summary}
                  onChange={(e) => setNewArticle({ ...newArticle, summary: e.target.value })}
                  placeholder="Tóm tắt ngắn gọn 1-2 câu về nội dung bài viết..."
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nội dung chi tiết bài viết
                </label>
                <textarea
                  rows={6}
                  value={newArticle.content}
                  onChange={(e) => setNewArticle({ ...newArticle, content: e.target.value })}
                  placeholder="Nhập nội dung đầy đủ của bài viết..."
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs leading-relaxed"
                />
              </div>

              <div className="pt-3 flex justify-end gap-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setShowAddArticleModal(false)}
                  className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-5 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs"
                >
                  {isProcessing ? 'Đang xuất bản...' : 'Xuất bản bài viết'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit Article */}
      {editingArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-stone-200 overflow-hidden">
            <div className="px-6 py-4 bg-stone-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Edit2 className="w-5 h-5 text-purple-400" />
                <h4 className="font-bold text-base">Chỉnh sửa Bài viết</h4>
              </div>
              <button
                type="button"
                onClick={() => setEditingArticle(null)}
                className="p-1 rounded hover:bg-stone-800 text-stone-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateArticleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Tiêu đề bài viết
                </label>
                <input
                  type="text"
                  required
                  value={editingArticle.title}
                  onChange={(e) => setEditingArticle({ ...editingArticle, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-semibold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Chuyên mục
                  </label>
                  <input
                    type="text"
                    value={editingArticle.category}
                    onChange={(e) => setEditingArticle({ ...editingArticle, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Tác giả
                  </label>
                  <input
                    type="text"
                    value={editingArticle.author}
                    onChange={(e) => setEditingArticle({ ...editingArticle, author: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Thời gian đọc
                  </label>
                  <input
                    type="text"
                    value={editingArticle.readTime}
                    onChange={(e) => setEditingArticle({ ...editingArticle, readTime: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Ảnh bìa (URL)
                </label>
                <input
                  type="url"
                  value={editingArticle.imageUrl}
                  onChange={(e) => setEditingArticle({ ...editingArticle, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Tóm tắt
                </label>
                <textarea
                  rows={2}
                  value={editingArticle.summary}
                  onChange={(e) => setEditingArticle({ ...editingArticle, summary: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Nội dung chi tiết
                </label>
                <textarea
                  rows={6}
                  value={editingArticle.content || ''}
                  onChange={(e) => setEditingArticle({ ...editingArticle, content: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs leading-relaxed"
                />
              </div>

              <div className="pt-3 flex justify-end gap-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setEditingArticle(null)}
                  className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-5 py-2 rounded-lg bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs"
                >
                  Lưu thay đổi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Add Test */}
      {showAddTestModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-stone-200 overflow-hidden">
            <div className="px-6 py-4 bg-purple-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                <h4 className="font-bold text-base">Tạo Bài Trắc nghiệm Tâm lý Mới</h4>
              </div>
              <button
                type="button"
                onClick={() => setShowAddTestModal(false)}
                className="p-1 rounded hover:bg-purple-800 text-purple-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTestSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Tên bài trắc nghiệm / khảo sát <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newTest.title}
                  onChange={(e) => setNewTest({ ...newTest, title: e.target.value })}
                  placeholder="VD: Đánh giá Mức độ Thích ứng Môi trường Lớp 10..."
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-semibold focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Đối tượng / Khối lớp
                  </label>
                  <input
                    type="text"
                    value={newTest.targetGrade}
                    onChange={(e) => setNewTest({ ...newTest, targetGrade: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Số câu hỏi trắc nghiệm
                  </label>
                  <input
                    type="number"
                    min={3}
                    max={50}
                    value={newTest.totalQuestions}
                    onChange={(e) => setNewTest({ ...newTest, totalQuestions: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Mô tả hướng dẫn làm bài <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={3}
                  required
                  value={newTest.description}
                  onChange={(e) => setNewTest({ ...newTest, description: e.target.value })}
                  placeholder="Hướng dẫn học sinh các bước trả lời trung thực..."
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                />
              </div>

              <div className="pt-3 flex justify-end gap-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setShowAddTestModal(false)}
                  className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-5 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs"
                >
                  {isProcessing ? 'Đang tạo...' : 'Tạo bài khảo sát'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Confirm Delete Article */}
      {articleToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-stone-200 p-6 space-y-4">
            <h4 className="font-bold text-base text-red-600 flex items-center gap-2">
              <Trash2 className="w-5 h-5" />
              <span>Xác nhận Xóa Bài viết</span>
            </h4>
            <p className="text-xs text-stone-700 leading-relaxed">
              Bạn có chắc chắn muốn xóa bài viết{' '}
              <strong className="text-stone-900 font-bold">"{articleToDelete.title}"</strong> khỏi cổng thông tin?
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setArticleToDelete(null)}
                className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={handleDeleteArticle}
                disabled={isProcessing}
                className="px-5 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs"
              >
                {isProcessing ? 'Đang xóa...' : 'Xóa bài viết'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Confirm Delete Test */}
      {testToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-stone-200 p-6 space-y-4">
            <h4 className="font-bold text-base text-red-600 flex items-center gap-2">
              <Trash2 className="w-5 h-5" />
              <span>Xác nhận Gỡ bỏ Bài Khảo sát</span>
            </h4>
            <p className="text-xs text-stone-700 leading-relaxed">
              Bạn có chắc chắn muốn gỡ bỏ bài khảo sát{' '}
              <strong className="text-stone-900 font-bold">"{testToDelete.title}"</strong>? Học sinh sẽ không thể tiếp tục làm bài này.
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setTestToDelete(null)}
                className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={handleDeleteTest}
                disabled={isProcessing}
                className="px-5 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs"
              >
                {isProcessing ? 'Đang xóa...' : 'Gỡ bỏ bài test'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
