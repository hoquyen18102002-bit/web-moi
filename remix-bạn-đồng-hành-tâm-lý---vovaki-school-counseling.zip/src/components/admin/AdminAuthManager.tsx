import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AuthSecuritySettings, AuthLog } from '../../types';
import {
  ShieldCheck,
  Lock,
  KeyRound,
  UserCheck,
  UserX,
  History,
  Trash2,
  CheckCircle2,
  AlertCircle,
  X,
  Search,
  Filter,
  Check,
  Eye,
  Sliders,
} from 'lucide-react';

export const AdminAuthManager: React.FC = () => {
  const { state, updateAuthSettings, updateSharedState } = useApp();

  const authSettings: AuthSecuritySettings = state.authSettings || {
    minPasswordLength: 6,
    requireSpecialChars: false,
    sessionTimeoutMinutes: 60,
    allowStudentRegistration: false,
    forceAnonymousStudentMode: true,
    maxLoginAttempts: 5,
  };

  const [minPasswordLength, setMinPasswordLength] = useState<number>(authSettings.minPasswordLength);
  const [requireSpecialChars, setRequireSpecialChars] = useState<boolean>(authSettings.requireSpecialChars);
  const [sessionTimeoutMinutes, setSessionTimeoutMinutes] = useState<number>(authSettings.sessionTimeoutMinutes);
  const [allowStudentRegistration, setAllowStudentRegistration] = useState<boolean>(authSettings.allowStudentRegistration);
  const [forceAnonymousStudentMode, setForceAnonymousStudentMode] = useState<boolean>(authSettings.forceAnonymousStudentMode);
  const [maxLoginAttempts, setMaxLoginAttempts] = useState<number>(authSettings.maxLoginAttempts);

  const [logSearch, setLogSearch] = useState('');
  const [logActionFilter, setLogActionFilter] = useState<string>('all');
  const [toastMsg, setToastMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMsg({ type, text });
    setTimeout(() => setToastMsg(null), 4000);
  };

  // Save authentication security settings
  const handleSaveAuthSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    const res = await updateAuthSettings({
      minPasswordLength,
      requireSpecialChars,
      sessionTimeoutMinutes,
      allowStudentRegistration,
      forceAnonymousStudentMode,
      maxLoginAttempts,
    });
    setIsProcessing(false);

    if (res.success) {
      showToast('Đã cập nhật chính sách bảo mật xác thực (Authentication) thành công!');
    } else {
      showToast(res.error || 'Cập nhật chính sách thất bại', 'error');
    }
  };

  // Clear auth logs
  const handleClearAuthLogs = () => {
    if (!confirm('Bạn có chắc chắn muốn xóa sạch toàn bộ nhật ký xác thực?')) {
      return;
    }
    updateSharedState({ authLogs: [] });
    showToast('Đã xóa sạch toàn bộ nhật ký xác thực');
  };

  // Filter logs
  const authLogs = state.authLogs || [];
  const filteredLogs = authLogs.filter((log) => {
    const matchSearch =
      log.username.toLowerCase().includes(logSearch.toLowerCase()) ||
      (log.details && log.details.toLowerCase().includes(logSearch.toLowerCase())) ||
      (log.ipAddress && log.ipAddress.includes(logSearch));

    const matchAction = logActionFilter === 'all' || log.action === logActionFilter;
    return matchSearch && matchAction;
  });

  const getActionBadge = (action: string) => {
    switch (action) {
      case 'LOGIN':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">Đăng nhập</span>;
      case 'LOGOUT':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-stone-100 text-stone-700">Đăng xuất</span>;
      case 'PROVISION_USER':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800">Cấp tài khoản</span>;
      case 'DELETE_USER':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-800">Xóa tài khoản</span>;
      case 'UPDATE_USER':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800">Cập nhật tài khoản</span>;
      case 'PASSWORD_RESET':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">Đổi mật khẩu</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-stone-100 text-stone-600">{action}</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notice */}
      {toastMsg && (
        <div
          className={`p-4 rounded-xl text-xs font-semibold flex items-center justify-between shadow-xs transition-all ${
            toastMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {toastMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span>{toastMsg.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setToastMsg(null)}
            className="p-1 hover:bg-black/5 rounded text-stone-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center font-bold">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-stone-900">
              Quản lý Xác thực & Chính sách Bảo mật (Authentication & Security)
            </h3>
            <p className="text-xs text-stone-500">
              Cấu hình độ mạnh mật khẩu, thời hạn phiên đăng nhập và theo dõi nhật ký kiểm toán hệ thống
            </p>
          </div>
        </div>
      </div>

      {/* Module 1: Authentication Security Policy */}
      <form onSubmit={handleSaveAuthSettings} className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-6">
        <div>
          <h4 className="font-bold text-base text-stone-900 flex items-center gap-2">
            <KeyRound className="w-5 h-5 text-purple-600" />
            <span>Chính sách Mật khẩu & Quản lý Phiên làm việc</span>
          </h4>
          <p className="text-xs text-stone-500 mt-0.5">
            Áp dụng các tiêu chuẩn an toàn thông tin bắt buộc cho toàn bộ tài khoản
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Độ dài mật khẩu tối thiểu
            </label>
            <select
              value={minPasswordLength}
              onChange={(e) => setMinPasswordLength(Number(e.target.value))}
              className="w-full px-3.5 py-2 rounded-lg border border-stone-300 text-xs font-medium"
            >
              <option value={4}>4 ký tự (Bản thử nghiệm)</option>
              <option value={6}>6 ký tự (Tiêu chuẩn trường học)</option>
              <option value={8}>8 ký tự (Khuyến nghị an toàn)</option>
              <option value={12}>12 ký tự (Độ bảo mật cao)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Thời gian hết hạn phiên (Phút)
            </label>
            <input
              type="number"
              min={15}
              max={1440}
              value={sessionTimeoutMinutes}
              onChange={(e) => setSessionTimeoutMinutes(Number(e.target.value))}
              className="w-full px-3.5 py-2 rounded-lg border border-stone-300 text-xs font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Số lần đăng nhập sai tối đa
            </label>
            <select
              value={maxLoginAttempts}
              onChange={(e) => setMaxLoginAttempts(Number(e.target.value))}
              className="w-full px-3.5 py-2 rounded-lg border border-stone-300 text-xs font-medium"
            >
              <option value={3}>3 lần (Khóa sau 3 lần sai)</option>
              <option value={5}>5 lần (Khuyến nghị)</option>
              <option value={10}>10 lần</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-stone-100">
          <label className="flex items-start gap-3 p-3 bg-stone-50 rounded-xl cursor-pointer hover:bg-stone-100/80 transition-colors">
            <input
              type="checkbox"
              checked={requireSpecialChars}
              onChange={(e) => setRequireSpecialChars(e.target.checked)}
              className="mt-0.5 w-4 h-4 text-purple-600 rounded"
            />
            <div>
              <span className="text-xs font-bold text-stone-800 block">Bắt buộc ký tự đặc biệt</span>
              <span className="text-[11px] text-stone-500">Mật khẩu phải chứa ít nhất một ký tự @, #, $, %...</span>
            </div>
          </label>

          <label className="flex items-start gap-3 p-3 bg-stone-50 rounded-xl cursor-pointer hover:bg-stone-100/80 transition-colors">
            <input
              type="checkbox"
              checked={allowStudentRegistration}
              onChange={(e) => setAllowStudentRegistration(e.target.checked)}
              className="mt-0.5 w-4 h-4 text-purple-600 rounded"
            />
            <div>
              <span className="text-xs font-bold text-stone-800 block">Cho phép học sinh tự đăng ký</span>
              <span className="text-[11px] text-stone-500">Mở cổng đăng ký tài khoản tự do ngoài trang chủ</span>
            </div>
          </label>

          <label className="flex items-start gap-3 p-3 bg-stone-50 rounded-xl cursor-pointer hover:bg-stone-100/80 transition-colors">
            <input
              type="checkbox"
              checked={forceAnonymousStudentMode}
              onChange={(e) => setForceAnonymousStudentMode(e.target.checked)}
              className="mt-0.5 w-4 h-4 text-purple-600 rounded"
            />
            <div>
              <span className="text-xs font-bold text-stone-800 block">Bắt buộc ẩn danh học sinh</span>
              <span className="text-[11px] text-stone-500">Tự động tạo mã ẩn danh khi tham vấn để bảo vệ học sinh</span>
            </div>
          </label>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            type="submit"
            disabled={isProcessing}
            className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs transition-all flex items-center gap-2"
          >
            <Check className="w-4 h-4" />
            <span>Lưu Cấu hình Xác thực</span>
          </button>
        </div>
      </form>

      {/* Module 2: Authentication Audit & Activity Logs */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-stone-50 border-b border-stone-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-purple-600" />
            <div>
              <h4 className="font-bold text-sm text-stone-900">
                Nhật ký Kiểm toán & Hoạt động Xác thực ({filteredLogs.length}/{authLogs.length})
              </h4>
              <p className="text-[11px] text-stone-500">
                Theo dõi minh bạch mọi sự kiện đăng nhập, cấp và xóa tài khoản của người dùng
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleClearAuthLogs}
            className="px-3 py-1.5 rounded-lg bg-red-100 hover:bg-red-200 text-red-700 text-xs font-semibold flex items-center gap-1.5"
            title="Xóa toàn bộ bản ghi nhật ký"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Xóa sạch nhật ký</span>
          </button>
        </div>

        {/* Filters */}
        <div className="p-3.5 border-b border-stone-100 flex flex-wrap items-center justify-between gap-3">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={logSearch}
              onChange={(e) => setLogSearch(e.target.value)}
              placeholder="Tìm theo tên người dùng, chi tiết hành động hoặc IP..."
              className="w-full pl-9 pr-4 py-1.5 rounded-lg border border-stone-200 text-xs focus:ring-2 focus:ring-purple-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-stone-400" />
            <select
              value={logActionFilter}
              onChange={(e) => setLogActionFilter(e.target.value)}
              className="px-3 py-1.5 rounded-lg border border-stone-200 text-xs font-medium bg-stone-50"
            >
              <option value="all">Tất cả hành động</option>
              <option value="LOGIN">Đăng nhập (LOGIN)</option>
              <option value="LOGOUT">Đăng xuất (LOGOUT)</option>
              <option value="PROVISION_USER">Cấp tài khoản (PROVISION_USER)</option>
              <option value="DELETE_USER">Xóa tài khoản (DELETE_USER)</option>
              <option value="UPDATE_USER">Cập nhật tài khoản (UPDATE_USER)</option>
              <option value="PASSWORD_RESET">Đổi mật khẩu (PASSWORD_RESET)</option>
            </select>
          </div>
        </div>

        {/* Logs Table */}
        <div className="overflow-x-auto max-h-[420px]">
          {filteredLogs.length === 0 ? (
            <div className="p-8 text-center text-stone-400 text-xs">
              <History className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p>Chưa có bản ghi nhật ký xác thực nào.</p>
            </div>
          ) : (
            <table className="w-full text-left text-xs text-stone-700">
              <thead className="bg-stone-50 border-b border-stone-200 text-[11px] font-bold text-stone-500 uppercase tracking-wider sticky top-0">
                <tr>
                  <th className="px-4 py-3">Thời gian</th>
                  <th className="px-4 py-3">Tài khoản</th>
                  <th className="px-4 py-3">Hành vi</th>
                  <th className="px-4 py-3">Chi tiết</th>
                  <th className="px-4 py-3">Địa chỉ IP</th>
                  <th className="px-4 py-3 text-right">Trạng thái</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-stone-50/80 transition-colors">
                    <td className="px-4 py-2.5 font-mono text-[11px] text-stone-500">
                      {log.timestamp}
                    </td>

                    <td className="px-4 py-2.5 font-bold font-mono text-stone-800">
                      {log.username}
                    </td>

                    <td className="px-4 py-2.5">
                      {getActionBadge(log.action)}
                    </td>

                    <td className="px-4 py-2.5 text-stone-600 text-xs">
                      {log.details || '—'}
                    </td>

                    <td className="px-4 py-2.5 font-mono text-[11px] text-stone-400">
                      {log.ipAddress || '127.0.0.1'}
                    </td>

                    <td className="px-4 py-2.5 text-right">
                      {log.status === 'SUCCESS' ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-100/80 px-2 py-0.5 rounded-full">
                          <CheckCircle2 className="w-3 h-3" />
                          Thành công
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-700 bg-red-100/80 px-2 py-0.5 rounded-full">
                          <AlertCircle className="w-3 h-3" />
                          Thất bại
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
