import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SentimentAnalysisResult } from '../../types';
import {
  Brain,
  Sparkles,
  Activity,
  AlertTriangle,
  RefreshCw,
  Search,
  Eye,
  CheckCircle2,
  X,
} from 'lucide-react';

export const AdminSentimentManager: React.FC = () => {
  const { state, runBatchSentimentAnalysis, analyzeSentiment } = useApp();

  const [isBatchAnalyzing, setIsBatchAnalyzing] = useState(false);
  const [batchResultMsg, setBatchResultMsg] = useState<string | null>(null);

  // Live sandbox tester
  const [testerText, setTesterText] = useState(
    'Dạo này em rất mệt mỏi, áp lực thi cử khiến em không thể ngủ được, nhiều lúc em cảm thấy kiệt sức và bế tắc.'
  );
  const [testerStudent, setTesterStudent] = useState('HS-2026-09');
  const [testerType, setTesterType] = useState<'counselor_booking' | 'emergency_session' | 'positive_room'>('emergency_session');
  const [isTestingSentiment, setIsTestingSentiment] = useState(false);
  const [testerResult, setTesterResult] = useState<any | null>(null);

  // Filters
  const [sentimentFilter, setSentimentFilter] = useState<string>('all');
  const [urgencyFilter, setUrgencyFilter] = useState<string>('all');
  const [sentimentSearch, setSentimentSearch] = useState<string>('');

  // Detail Modal
  const [selectedReportSentiment, setSelectedReportSentiment] = useState<SentimentAnalysisResult | null>(null);

  const handleRunBatchSentiment = async () => {
    setIsBatchAnalyzing(true);
    setBatchResultMsg(null);
    try {
      const res = await runBatchSentimentAnalysis();
      if (res.success) {
        setBatchResultMsg(`Đã hoàn tất phân tích ${res.analyzedCount || 0} phiên mới! Dữ liệu cảm xúc đã được cập nhật.`);
      } else {
        setBatchResultMsg(res.error || 'Có lỗi khi chạy phân tích');
      }
    } catch (err: any) {
      setBatchResultMsg(err.message || 'Lỗi phân tích batch');
    } finally {
      setIsBatchAnalyzing(false);
    }
  };

  const handleTestSentiment = async () => {
    if (!testerText.trim()) return;
    setIsTestingSentiment(true);
    setTesterResult(null);
    try {
      const res = await analyzeSentiment({
        text: testerText.trim(),
        studentIdentifier: testerStudent || 'HS-TEST-01',
        sessionType: testerType,
      });

      if (res.success && res.analysis) {
        setTesterResult(res.analysis);
      } else {
        alert(res.error || 'Không thể phân tích');
      }
    } catch (err: any) {
      alert(err.message || 'Lỗi khi gọi AI');
    } finally {
      setIsTestingSentiment(false);
    }
  };

  const analyses = state.sentimentAnalyses || [];
  const total = analyses.length || 1;
  const posCount = analyses.filter((a) => a.sentiment === 'positive').length;
  const negCount = analyses.filter((a) => a.sentiment === 'negative').length;
  const neuCount = analyses.filter((a) => a.sentiment === 'neutral').length;
  const urgentCount = analyses.filter((a) => a.urgencyLevel === 'Báo động khẩn cấp').length;
  const attentionCount = analyses.filter((a) => a.urgencyLevel === 'Cần chú ý').length;
  const avgScore = analyses.length
    ? (analyses.reduce((acc, a) => acc + (a.sentimentScore || 0), 0) / analyses.length).toFixed(2)
    : '0.00';

  const filteredAnalyses = analyses.filter((item) => {
    if (sentimentFilter !== 'all' && item.sentiment !== sentimentFilter) return false;
    if (urgencyFilter !== 'all' && item.urgencyLevel !== urgencyFilter) return false;
    if (sentimentSearch.trim()) {
      const q = sentimentSearch.toLowerCase();
      const matchStudent = item.studentIdentifier.toLowerCase().includes(q);
      const matchState = item.emotionalState.toLowerCase().includes(q);
      const matchSum = item.summary.toLowerCase().includes(q);
      if (!matchStudent && !matchState && !matchSum) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Sentiment Header */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
              Trí tuệ Nhân tạo & Cảm xúc
            </span>
            <span className="text-xs text-stone-500">Gemini 2.5 Flash Sentiment Engine</span>
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-stone-900 mt-1">
            Mô-đun Phân tích Cảm xúc & Tâm lý Học sinh Tự động
          </h3>
          <p className="text-xs text-stone-600 mt-0.5">
            Quét nhật ký các buổi tư vấn 1-1, phòng tích cực và hội thoại khẩn cấp để nhận diện trạng thái cảm xúc, mức độ bất an và đưa ra khuyến nghị can thiệp kịp thời.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleRunBatchSentiment}
            disabled={isBatchAnalyzing}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-2 shadow-xs transition-all"
          >
            {isBatchAnalyzing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                Đang phân tích hàng loạt...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Phân tích hàng loạt phiên mới
              </>
            )}
          </button>
        </div>
      </div>

      {batchResultMsg && (
        <div className="p-3.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
          <span>{batchResultMsg}</span>
        </div>
      )}

      {/* Sentiment Statistics Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <div className="text-xs text-stone-500 font-semibold">Tổng phiên đã phân tích</div>
          <div className="text-2xl font-bold text-stone-900 mt-1">{analyses.length}</div>
          <div className="text-[11px] text-stone-400 mt-1">Bao gồm 1-1, Khẩn cấp & Vovakier</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-emerald-200 shadow-xs">
          <div className="text-xs text-emerald-700 font-semibold flex items-center justify-between">
            <span>Tích cực (Positive)</span>
            <span className="font-bold">{Math.round((posCount / total) * 100)}%</span>
          </div>
          <div className="text-2xl font-bold text-emerald-700 mt-1">{posCount} phiên</div>
          <div className="w-full bg-emerald-100 h-1.5 rounded-full mt-2 overflow-hidden">
            <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${(posCount / total) * 100}%` }} />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-rose-200 shadow-xs">
          <div className="text-xs text-rose-700 font-semibold flex items-center justify-between">
            <span>Tiêu cực (Negative)</span>
            <span className="font-bold">{Math.round((negCount / total) * 100)}%</span>
          </div>
          <div className="text-2xl font-bold text-rose-700 mt-1">{negCount} phiên</div>
          <div className="w-full bg-rose-100 h-1.5 rounded-full mt-2 overflow-hidden">
            <div className="bg-rose-500 h-full rounded-full" style={{ width: `${(negCount / total) * 100}%` }} />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <div className="text-xs text-stone-600 font-semibold flex items-center justify-between">
            <span>Trung tính (Neutral)</span>
            <span className="font-bold">{Math.round((neuCount / total) * 100)}%</span>
          </div>
          <div className="text-2xl font-bold text-stone-700 mt-1">{neuCount} phiên</div>
          <div className="w-full bg-stone-200 h-1.5 rounded-full mt-2 overflow-hidden">
            <div className="bg-stone-500 h-full rounded-full" style={{ width: `${(neuCount / total) * 100}%` }} />
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-amber-200 shadow-xs">
          <div className="text-xs text-amber-800 font-semibold flex items-center justify-between">
            <span>Cảnh báo can thiệp</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
          </div>
          <div className="text-xl font-bold text-amber-900 mt-1">
            {urgentCount} Khẩn / {attentionCount} Chú ý
          </div>
          <div className="text-[11px] text-amber-700 mt-1">Chỉ số cảm xúc TB: {avgScore} (-1 đến +1)</div>
        </div>
      </div>

      {/* Interactive Live Sentiment Sandbox Analyzer */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-stone-100 pb-3">
          <div>
            <h4 className="font-bold text-sm text-stone-900 flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-600" />
              Không gian Thực nghiệm Phân tích Tâm lý Tức thì (Live Sentiment Analyzer)
            </h4>
            <p className="text-xs text-stone-500 mt-0.5">
              Nhập hoặc dán bất kỳ văn bản tâm sự / đối thoại nào của học sinh để AI trích xuất điểm số, sắc thái cảm xúc và các tín hiệu nguy cơ.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2">
            <label className="block text-xs font-bold text-stone-700 mb-1">
              Đoạn văn bản / Tin nhắn học sinh cần phân tích:
            </label>
            <textarea
              rows={3}
              value={testerText}
              onChange={(e) => setTesterText(e.target.value)}
              placeholder="Dán đoạn chat hoặc ghi chú tâm sự của học sinh tại đây..."
              className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="space-y-2 text-xs">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Mã định danh học sinh:</label>
              <input
                type="text"
                value={testerStudent}
                onChange={(e) => setTesterStudent(e.target.value)}
                className="w-full px-3 py-1.5 rounded-lg border border-stone-300 font-mono"
              />
            </div>

            <div>
              <label className="block font-bold text-stone-700 mb-1">Phân hệ phiên:</label>
              <select
                value={testerType}
                onChange={(e) => setTesterType(e.target.value as any)}
                className="w-full px-3 py-1.5 rounded-lg border border-stone-300"
              >
                <option value="counselor_booking">Tư vấn đặt lịch 1-1</option>
                <option value="emergency_session">Hội thoại Khẩn cấp</option>
                <option value="positive_room">Phòng tích cực Vovakier</option>
              </select>
            </div>

            <button
              type="button"
              onClick={handleTestSentiment}
              disabled={isTestingSentiment || !testerText.trim()}
              className="w-full mt-2 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold flex items-center justify-center gap-2 shadow-xs transition-all"
            >
              {isTestingSentiment ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  AI đang phân tích...
                </>
              ) : (
                <>
                  <Brain className="w-3.5 h-3.5" />
                  Chạy phân tích AI ngay
                </>
              )}
            </button>
          </div>
        </div>

        {/* Tester Result Box */}
        {testerResult && (
          <div className="p-4 rounded-xl border border-indigo-200 bg-indigo-50/40 space-y-3 animate-fade-in text-xs">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-indigo-100 pb-2">
              <div className="flex items-center gap-2">
                <span
                  className={`px-2.5 py-1 rounded-full font-bold text-xs ${
                    testerResult.sentiment === 'positive'
                      ? 'bg-emerald-100 text-emerald-800'
                      : testerResult.sentiment === 'negative'
                      ? 'bg-rose-100 text-rose-800'
                      : 'bg-stone-100 text-stone-800'
                  }`}
                >
                  {testerResult.sentiment === 'positive'
                    ? 'Tích cực'
                    : testerResult.sentiment === 'negative'
                    ? 'Tiêu cực'
                    : 'Trung tính'}
                </span>
                <span className="font-bold text-stone-800">{testerResult.emotionalState}</span>
                <span className="font-mono text-stone-500">
                  (Điểm số: {testerResult.sentimentScore > 0 ? `+${testerResult.sentimentScore}` : testerResult.sentimentScore} | Độ tin cậy: {Math.round(testerResult.confidence * 100)}%)
                </span>
              </div>

              <span
                className={`px-2.5 py-0.5 rounded-full font-bold text-[11px] ${
                  testerResult.urgencyLevel === 'Báo động khẩn cấp'
                    ? 'bg-red-600 text-white animate-pulse'
                    : testerResult.urgencyLevel === 'Cần chú ý'
                    ? 'bg-amber-500 text-white'
                    : 'bg-emerald-600 text-white'
                }`}
              >
                Mức độ can thiệp: {testerResult.urgencyLevel}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <span className="font-bold text-stone-800 block mb-1">Tóm tắt tâm lý:</span>
                <p className="text-stone-600 leading-relaxed">{testerResult.summary}</p>
              </div>
              <div>
                <span className="font-bold text-stone-800 block mb-1">Khuyến nghị can thiệp:</span>
                <p className="text-indigo-900 leading-relaxed font-medium">{testerResult.clinicalRecommendation}</p>
              </div>
            </div>

            {testerResult.distressSignals && testerResult.distressSignals.length > 0 && (
              <div>
                <span className="font-bold text-rose-800 block mb-1">Dấu hiệu bất an được phát hiện:</span>
                <div className="flex flex-wrap gap-1.5">
                  {testerResult.distressSignals.map((signal: string, idx: number) => (
                    <span key={idx} className="px-2 py-0.5 rounded bg-rose-100 text-rose-700 text-[11px] font-semibold">
                      ⚠️ {signal}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* List of All Sentiment Analyses */}
      <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 className="font-bold text-sm text-stone-900 flex items-center gap-2">
              <Brain className="w-4 h-4 text-purple-600" />
              Danh mục Toàn bộ Báo cáo Cảm xúc Hệ thống ({analyses.length})
            </h4>
            <p className="text-xs text-stone-500 mt-0.5">
              Nhấp vào từng phiên để xem bảng đánh giá tâm lý chuyên sâu và các khuyến nghị hỗ trợ học sinh
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-stone-400" />
              <input
                type="text"
                placeholder="Tìm theo Mã HS, từ khóa..."
                value={sentimentSearch}
                onChange={(e) => setSentimentSearch(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-lg border border-stone-300 text-xs w-48"
              />
            </div>

            <select
              value={sentimentFilter}
              onChange={(e) => setSentimentFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs font-semibold"
            >
              <option value="all">Mọi cảm xúc</option>
              <option value="negative">Tiêu cực (Negative)</option>
              <option value="positive">Tích cực (Positive)</option>
              <option value="neutral">Trung tính (Neutral)</option>
            </select>

            <select
              value={urgencyFilter}
              onChange={(e) => setUrgencyFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-stone-300 text-xs font-semibold"
            >
              <option value="all">Mọi mức độ can thiệp</option>
              <option value="Báo động khẩn cấp">Báo động khẩn cấp</option>
              <option value="Cần chú ý">Cần chú ý</option>
              <option value="Bình thường">Bình thường</option>
            </select>
          </div>
        </div>

        {/* List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredAnalyses.map((analysis) => (
            <div
              key={analysis.id}
              className="p-4 rounded-2xl border border-stone-200 bg-stone-50/50 hover:bg-white hover:shadow-md transition-all flex flex-col justify-between space-y-3"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-stone-800 bg-stone-200 px-2 py-0.5 rounded">
                    {analysis.studentIdentifier}
                  </span>
                  <span
                    className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                      analysis.urgencyLevel === 'Báo động khẩn cấp'
                        ? 'bg-rose-600 text-white animate-pulse'
                        : analysis.urgencyLevel === 'Cần chú ý'
                        ? 'bg-amber-500 text-white'
                        : 'bg-emerald-600 text-white'
                    }`}
                  >
                    {analysis.urgencyLevel}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                      analysis.sentiment === 'positive'
                        ? 'bg-emerald-100 text-emerald-800'
                        : analysis.sentiment === 'negative'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-stone-200 text-stone-800'
                    }`}
                  >
                    {analysis.sentiment === 'positive'
                      ? 'Tích cực'
                      : analysis.sentiment === 'negative'
                      ? 'Tiêu cực'
                      : 'Trung tính'}
                  </span>
                  <h5 className="font-bold text-sm text-stone-900">{analysis.emotionalState}</h5>
                </div>

                <p className="text-xs text-stone-600 line-clamp-2">{analysis.summary}</p>

                {analysis.distressSignals && analysis.distressSignals.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {analysis.distressSignals.map((sig, i) => (
                      <span key={i} className="text-[10px] bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded border border-rose-200">
                        ⚠️ {sig}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-2 border-t border-stone-200/70 flex items-center justify-between text-[11px]">
                <span className="text-stone-400 font-mono">
                  {analysis.analyzedAt.replace('T', ' ').substring(0, 16)}
                </span>

                <button
                  type="button"
                  onClick={() => setSelectedReportSentiment(analysis)}
                  className="px-3 py-1.5 rounded-lg bg-purple-100 hover:bg-purple-200 text-purple-800 font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Eye className="w-3.5 h-3.5" />
                  Xem Báo cáo Chi tiết
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal: Detailed Psychological & Sentiment Report */}
      {selectedReportSentiment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-base text-stone-900">
                  Báo cáo Phân tích Tâm lý & Cảm xúc Chuyên sâu
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedReportSentiment(null)}
                className="text-stone-400 hover:text-stone-700 text-sm font-bold"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-200">
                  <span className="text-[10px] text-stone-400 block">Học sinh:</span>
                  <span className="font-bold text-stone-900 font-mono">{selectedReportSentiment.studentIdentifier}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-200">
                  <span className="text-[10px] text-stone-400 block">Điểm số cảm xúc:</span>
                  <span className="font-bold text-stone-900">
                    {selectedReportSentiment.sentimentScore > 0 ? `+${selectedReportSentiment.sentimentScore}` : selectedReportSentiment.sentimentScore} / 1.0
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-200">
                  <span className="text-[10px] text-stone-400 block">Độ tin cậy:</span>
                  <span className="font-bold text-stone-900">
                    {Math.round(selectedReportSentiment.confidence * 100)}%
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-200">
                  <span className="text-[10px] text-stone-400 block">Mức độ can thiệp:</span>
                  <span className="font-bold text-rose-700">{selectedReportSentiment.urgencyLevel}</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200">
                <span className="font-bold text-stone-800 block mb-1">Trạng thái tâm lý chủ đạo:</span>
                <p className="text-sm font-bold text-indigo-900">{selectedReportSentiment.emotionalState}</p>
              </div>

              <div>
                <span className="font-bold text-stone-800 block mb-1">Tóm lược đánh giá của AI:</span>
                <p className="text-stone-700 leading-relaxed bg-stone-50 p-3 rounded-xl border border-stone-200">
                  {selectedReportSentiment.summary}
                </p>
              </div>

              {selectedReportSentiment.distressSignals && selectedReportSentiment.distressSignals.length > 0 && (
                <div>
                  <span className="font-bold text-rose-800 block mb-1">Dấu hiệu tâm lý bất an (Distress Signals):</span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedReportSentiment.distressSignals.map((sig: string, i: number) => (
                      <span key={i} className="px-2.5 py-1 rounded-lg bg-rose-50 text-rose-800 border border-rose-200 font-semibold">
                        ⚠️ {sig}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {selectedReportSentiment.keyPhrases && selectedReportSentiment.keyPhrases.length > 0 && (
                <div>
                  <span className="font-bold text-stone-800 block mb-1">Các cụm từ then chốt được trích xuất:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedReportSentiment.keyPhrases.map((phrase: string, i: number) => (
                      <span key={i} className="px-2.5 py-0.5 rounded-md bg-stone-100 text-stone-700 border border-stone-200 font-mono">
                        "{phrase}"
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-200">
                <span className="font-bold text-indigo-950 block mb-1 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                  Khuyến nghị chuyên môn cho Giáo viên Tư vấn:
                </span>
                <p className="text-indigo-900 leading-relaxed font-medium">
                  {selectedReportSentiment.clinicalRecommendation}
                </p>
              </div>
            </div>

            <div className="pt-3 border-t border-stone-100 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedReportSentiment(null)}
                className="px-5 py-2 rounded-xl bg-stone-800 hover:bg-stone-900 text-white font-bold text-xs"
              >
                Đóng Báo cáo
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
