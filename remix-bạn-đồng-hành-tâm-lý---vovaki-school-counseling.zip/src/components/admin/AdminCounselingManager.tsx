import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CounselingBooking, EmergencySession, PositiveRoomSession } from '../../types';
import {
  MessageSquareHeart,
  Calendar,
  Clock,
  Sparkles,
  AlertTriangle,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Eye,
  User,
  PhoneCall,
  Activity,
  Heart,
  Radio,
  Send,
  X,
  MessageCircle,
} from 'lucide-react';

interface AdminCounselingManagerProps {
  initialSubTab?: 'bookings' | 'sessions' | 'positive_room' | 'emergency';
}

export const AdminCounselingManager: React.FC<AdminCounselingManagerProps> = ({
  initialSubTab = 'bookings',
}) => {
  const { state, updateSharedState, steerPositiveRoom } = useApp();

  const [activeTab, setActiveTab] = useState<'bookings' | 'sessions' | 'positive_room' | 'emergency'>(
    initialSubTab
  );

  React.useEffect(() => {
    if (initialSubTab) {
      setActiveTab(initialSubTab);
    }
  }, [initialSubTab]);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedBooking, setSelectedBooking] = useState<CounselingBooking | null>(null);
  const [selectedEmergency, setSelectedEmergency] = useState<EmergencySession | null>(null);
  const [selectedPositiveSession, setSelectedPositiveSession] = useState<PositiveRoomSession | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Update Booking Status
  const handleUpdateBookingStatus = async (
    bookingId: string,
    newStatus: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled'
  ) => {
    const updated = state.bookings.map((b) => (b.id === bookingId ? { ...b, status: newStatus } : b));
    await updateSharedState({ bookings: updated });
    showToast(`Đã cập nhật trạng thái lịch hẹn thành: ${newStatus}`);
    if (selectedBooking && selectedBooking.id === bookingId) {
      setSelectedBooking({ ...selectedBooking, status: newStatus });
    }
  };

  // Close Emergency Session
  const handleCloseEmergency = async (sessionId: string) => {
    const updated = state.emergencySessions.map((s) =>
      s.id === sessionId ? { ...s, status: 'closed' as const } : s
    );
    await updateSharedState({ emergencySessions: updated });
    showToast('Đã đóng phiên hỗ trợ khẩn cấp');
    if (selectedEmergency && selectedEmergency.id === sessionId) {
      setSelectedEmergency({ ...selectedEmergency, status: 'closed' });
    }
  };

  // Filtered Bookings
  const filteredBookings = (state.bookings || []).filter((b) => {
    const matchSearch =
      (b.nickname && b.nickname.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (b.studentAnonymousCode && b.studentAnonymousCode.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (b.topic && b.topic.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchStatus = statusFilter === 'all' || b.status === statusFilter;
    return matchSearch && matchStatus;
  });

  // Completed sessions for "Phiên tư vấn"
  const completedSessions = (state.bookings || []).filter(
    (b) => b.status === 'completed' || (b.messages && b.messages.length > 0)
  );

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-white px-5 py-3 rounded-2xl shadow-xl border border-stone-700 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-blue-100 text-blue-700">
              <MessageSquareHeart className="w-5 h-5" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-700">
              Quản trị Vận hành
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight">
            Tư Vấn Tâm Lý & Phòng Hỗ Trợ
          </h2>
          <p className="text-xs text-stone-600 max-w-2xl">
            Quản lý các lịch đăng ký tư vấn 1-1 của học sinh, giám sát các phiên tư vấn đã diễn ra, điều phối Phòng suy nghĩ tích cực và can thiệp kịp thời các phiên SOS khẩn cấp.
          </p>
        </div>

        {/* Sub-tab Navigation */}
        <div className="flex flex-wrap items-center gap-1.5 bg-stone-100 p-1.5 rounded-2xl border border-stone-200">
          <button
            type="button"
            onClick={() => setActiveTab('bookings')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'bookings'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Lịch hẹn ({state.bookings?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('sessions')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'sessions'
                ? 'bg-white text-blue-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Phiên tư vấn ({completedSessions.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('positive_room')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'positive_room'
                ? 'bg-white text-emerald-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>Phòng tích cực ({state.positiveRoomSessions?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('emergency')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'emergency'
                ? 'bg-red-600 text-white shadow-xs'
                : 'text-red-700 hover:bg-red-50'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Tư vấn khẩn cấp ({state.emergencySessions?.filter((e) => e.status === 'active').length || 0})</span>
          </button>
        </div>
      </div>

      {/* ================= 1. LỊCH HẸN TƯ VẤN ================= */}
      {activeTab === 'bookings' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-1 min-w-[240px] max-w-md bg-stone-50 px-3 py-2 rounded-xl border border-stone-200">
              <Search className="w-4 h-4 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Tìm theo biệt danh, mã HS, hoặc chủ đề..."
                className="w-full bg-transparent text-xs text-stone-800 outline-none font-medium"
              />
            </div>

            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-stone-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 rounded-xl border border-stone-200 text-xs font-semibold bg-stone-50 text-stone-700 outline-none"
              >
                <option value="all">Tất cả trạng thái</option>
                <option value="pending">Chờ duyệt</option>
                <option value="confirmed">Đã duyệt</option>
                <option value="in_progress">Đang diễn ra</option>
                <option value="completed">Đã hoàn thành</option>
                <option value="cancelled">Đã hủy</option>
              </select>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="px-5 py-3.5">Học sinh</th>
                    <th className="px-4 py-3.5">Ngày & Khung giờ</th>
                    <th className="px-4 py-3.5">Chủ đề tư vấn</th>
                    <th className="px-4 py-3.5">Trạng thái</th>
                    <th className="px-4 py-3.5 text-center">Tin nhắn</th>
                    <th className="px-4 py-3.5 text-right">Thao tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {filteredBookings.map((b) => (
                    <tr key={b.id} className="hover:bg-blue-50/30 transition-colors">
                      <td className="px-5 py-3.5">
                        <div className="font-bold text-stone-900">{b.nickname || 'Học sinh ẩn danh'}</div>
                        <div className="text-[11px] text-stone-400 font-mono">{b.studentAnonymousCode}</div>
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-semibold text-stone-800">{b.date}</div>
                        <div className="text-[10px] text-stone-500">{b.timeSlot}</div>
                      </td>
                      <td className="px-4 py-3.5 font-medium text-stone-700 max-w-xs truncate">
                        {b.topic}
                      </td>
                      <td className="px-4 py-3.5">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            b.status === 'confirmed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : b.status === 'completed'
                              ? 'bg-stone-100 text-stone-700'
                              : b.status === 'in_progress'
                              ? 'bg-purple-100 text-purple-800 animate-pulse'
                              : b.status === 'cancelled'
                              ? 'bg-red-100 text-red-700'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {b.status === 'confirmed'
                            ? 'Đã duyệt'
                            : b.status === 'completed'
                            ? 'Đã xong'
                            : b.status === 'in_progress'
                            ? 'Đang tư vấn'
                            : b.status === 'cancelled'
                            ? 'Đã hủy'
                            : 'Chờ duyệt'}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-center">
                        <span className="font-mono text-stone-600 bg-stone-100 px-2 py-0.5 rounded-md">
                          {b.messages?.length || 0}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-right">
                        <button
                          type="button"
                          onClick={() => setSelectedBooking(b)}
                          className="px-3 py-1.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs inline-flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Chi tiết</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= 2. PHIÊN TƯ VẤN ================= */}
      {activeTab === 'sessions' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs space-y-2">
            <h3 className="font-bold text-base text-stone-900">
              Nhật Ký & Biên Bản Các Phiên Tư Vấn Đã Diễn Ra
            </h3>
            <p className="text-xs text-stone-500">
              Lưu giữ an toàn lịch sử đối thoại giữa chuyên viên tâm lý và học sinh với cơ chế bảo mật ẩn danh hoàn toàn.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {completedSessions.map((session) => (
              <div
                key={session.id}
                className="bg-white rounded-3xl p-5 border border-stone-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                      Phiên: {session.date} ({session.timeSlot})
                    </span>
                    <span className="text-xs font-mono text-stone-400">{session.studentAnonymousCode}</span>
                  </div>
                  <h4 className="font-bold text-base text-stone-900">{session.topic}</h4>
                  <p className="text-xs text-stone-600">
                    Học sinh: <strong>{session.nickname}</strong>
                  </p>
                  <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100 text-xs text-stone-600 space-y-1">
                    <div className="flex items-center gap-1.5 text-stone-500 font-semibold">
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>{session.messages?.length || 0} tin nhắn trao đổi</span>
                    </div>
                    {session.sentimentAnalysis && (
                      <div className="text-purple-700 font-medium">
                        Cảm xúc sau phiên: {session.sentimentAnalysis.emotionalState}
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-3 border-t border-stone-100 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setSelectedBooking(session)}
                    className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Xem nội dung phiên</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= 3. PHÒNG TÍCH CỰC ================= */}
      {activeTab === 'positive_room' && (
        <div className="space-y-4">
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-3xl p-6 flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
              <Sparkles className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-extrabold text-emerald-950 text-base">
                Giám Sát Phòng Suy Nghĩ Tích Cực (Positive Room)
              </h3>
              <p className="text-xs text-emerald-800 leading-relaxed max-w-2xl">
                Không gian giải tỏa áp lực tự động dành cho học sinh. Quản trị viên và GV tư vấn có thể can thiệp từ xa, gợi ý câu hỏi để AI đồng hành sâu sắc hơn.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {state.positiveRoomSessions?.map((session) => (
              <div
                key={session.id}
                className="bg-white rounded-3xl p-5 border border-stone-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                      <span>{session.status === 'active' ? 'Đang hoạt động' : 'Đã kết thúc'}</span>
                    </span>
                    <span className="text-xs text-stone-400 font-mono">{session.studentAnonymousCode}</span>
                  </div>
                  <h4 className="font-bold text-stone-900 text-base">
                    Học sinh: {session.studentNickname || 'Ẩn danh'}
                  </h4>
                  <div className="text-xs text-stone-500">Bắt đầu: {session.startedAt}</div>

                  <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100 text-xs space-y-1">
                    <div className="text-stone-500">Số lượt tương tác: {session.messages?.length || 0}</div>
                    {session.counselorGuidancePrompt && (
                      <div className="text-emerald-700 italic">
                        Chỉ đạo từ GV: "{session.counselorGuidancePrompt}"
                      </div>
                    )}
                  </div>
                </div>

                <div className="pt-3 border-t border-stone-100 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setSelectedPositiveSession(session)}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Xem & Can thiệp từ xa</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= 4. TƯ VẤN KHẨN CẤP ================= */}
      {activeTab === 'emergency' && (
        <div className="space-y-4">
          <div className="bg-red-50 border border-red-200 rounded-3xl p-6 flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-700 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-extrabold text-red-950 text-base">
                Hotline & Phiên Yêu Cầu Hỗ Trợ SOS Khẩn Cấp
              </h3>
              <p className="text-xs text-red-800 leading-relaxed max-w-2xl">
                Kênh tiếp nhận trực ban 24/7 khi học sinh có dấu hiệu khủng hoảng tâm lý nghiêm trọng, ý nghĩ tiêu cực hoặc hoảng loạn.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {state.emergencySessions?.map((session) => (
              <div
                key={session.id}
                className={`bg-white rounded-3xl p-5 border-2 transition-all flex flex-col justify-between space-y-4 ${
                  session.status === 'active'
                    ? 'border-red-400 shadow-md ring-2 ring-red-200'
                    : 'border-stone-200 shadow-2xs'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${
                        session.status === 'active'
                          ? 'bg-red-600 text-white animate-pulse'
                          : 'bg-stone-100 text-stone-600'
                      }`}
                    >
                      <PhoneCall className="w-3 h-3" />
                      <span>{session.status === 'active' ? 'Yêu cầu SOS đang mở' : 'Đã đóng phiên'}</span>
                    </span>
                    <span className="text-xs text-stone-400 font-mono">{session.studentAnonymousCode}</span>
                  </div>

                  <h4 className="font-black text-stone-900 text-base">
                    {session.studentNickname || 'Học sinh khẩn cấp'}
                  </h4>
                  <div className="text-xs text-stone-500">Kích hoạt lúc: {session.startedAt}</div>

                  {session.counselorNotes && (
                    <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200 text-xs text-stone-700 italic">
                      Ghi chú: {session.counselorNotes}
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t border-stone-100 flex items-center justify-between">
                  {session.status === 'active' && (
                    <button
                      type="button"
                      onClick={() => handleCloseEmergency(session.id)}
                      className="text-xs font-bold text-stone-500 hover:text-stone-700"
                    >
                      Đóng phiên
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setSelectedEmergency(session)}
                    className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Mở hội thoại can thiệp</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= MODAL: BOOKING DETAIL & STATUS CHANGE ================= */}
      {selectedBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 space-y-5 border border-stone-200 shadow-2xl max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="font-extrabold text-stone-900 text-base">Chi Tiết Lịch Hẹn Tư Vấn</h3>
                <p className="text-xs text-stone-400 font-mono">{selectedBooking.studentAnonymousCode}</p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedBooking(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="overflow-y-auto space-y-4 text-xs flex-1">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100">
                  <span className="text-stone-400 block">Học sinh:</span>
                  <span className="font-bold text-stone-800 text-sm mt-0.5 block">
                    {selectedBooking.nickname}
                  </span>
                </div>
                <div className="p-3 rounded-2xl bg-stone-50 border border-stone-100">
                  <span className="text-stone-400 block">Thời gian:</span>
                  <span className="font-bold text-stone-800 text-sm mt-0.5 block">
                    {selectedBooking.date} ({selectedBooking.timeSlot})
                  </span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-100">
                <span className="font-bold text-blue-900 block mb-1">Chủ đề chia sẻ:</span>
                <p className="text-stone-700 leading-relaxed">{selectedBooking.topic}</p>
              </div>

              <div className="space-y-2">
                <span className="font-bold text-stone-800 block">Cập nhật trạng thái duyệt:</span>
                <div className="flex flex-wrap gap-2">
                  {(['pending', 'confirmed', 'in_progress', 'completed', 'cancelled'] as const).map(
                    (st) => (
                      <button
                        key={st}
                        type="button"
                        onClick={() => handleUpdateBookingStatus(selectedBooking.id, st)}
                        className={`px-3 py-1.5 rounded-xl font-bold transition-all ${
                          selectedBooking.status === st
                            ? 'bg-blue-600 text-white shadow-xs'
                            : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                        }`}
                      >
                        {st === 'pending' && 'Chờ duyệt'}
                        {st === 'confirmed' && 'Xác nhận'}
                        {st === 'in_progress' && 'Đang diễn ra'}
                        {st === 'completed' && 'Hoàn thành'}
                        {st === 'cancelled' && 'Hủy bỏ'}
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Chat messages */}
              <div className="space-y-2 pt-2 border-t border-stone-100">
                <span className="font-bold text-stone-800 block">
                  Lịch sử trao đổi ({selectedBooking.messages?.length || 0} tin nhắn):
                </span>
                <div className="max-h-48 overflow-y-auto space-y-2 p-3 bg-stone-50 rounded-2xl border border-stone-200">
                  {selectedBooking.messages?.length === 0 ? (
                    <p className="text-stone-400 italic text-center py-4">Chưa có tin nhắn nào</p>
                  ) : (
                    selectedBooking.messages?.map((msg) => (
                      <div
                        key={msg.id}
                        className={`p-2.5 rounded-xl max-w-[85%] ${
                          msg.sender === 'student'
                            ? 'bg-white border border-stone-200 ml-auto text-right'
                            : 'bg-blue-600 text-white mr-auto text-left'
                        }`}
                      >
                        <div className="text-[10px] opacity-75 font-semibold mb-0.5">
                          {msg.senderName} • {msg.timestamp}
                        </div>
                        <div>{msg.text}</div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-stone-100 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedBooking(null)}
                className="px-5 py-2 rounded-xl bg-stone-900 text-white font-bold text-xs"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: EMERGENCY SESSION CHAT ================= */}
      {selectedEmergency && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 space-y-4 border border-stone-200 shadow-2xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2 text-red-600">
                <AlertTriangle className="w-5 h-5" />
                <h3 className="font-extrabold text-stone-900 text-base">
                  Phiên Tư Vấn SOS: {selectedEmergency.studentNickname}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedEmergency(null)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-64 overflow-y-auto space-y-2 p-3 bg-red-50/40 rounded-2xl border border-red-200 text-xs">
              {selectedEmergency.messages?.map((m) => (
                <div
                  key={m.id}
                  className={`p-2.5 rounded-xl max-w-[85%] ${
                    m.sender === 'student'
                      ? 'bg-white border border-red-200 ml-auto'
                      : 'bg-red-600 text-white mr-auto'
                  }`}
                >
                  <div className="text-[10px] opacity-75 mb-0.5 font-bold">{m.senderName}</div>
                  <div>{m.text}</div>
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center pt-3 border-t border-stone-100">
              <button
                type="button"
                onClick={() => handleCloseEmergency(selectedEmergency.id)}
                className="px-4 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-800 font-bold text-xs"
              >
                Đánh dấu Đã xử lý & Đóng phiên
              </button>
              <button
                type="button"
                onClick={() => setSelectedEmergency(null)}
                className="px-4 py-2 rounded-xl bg-stone-900 text-white font-bold text-xs"
              >
                Xong
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
