import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Article } from '../../types';
import {
  FileText,
  Bell,
  BookOpen,
  Image as ImageIcon,
  Plus,
  Trash2,
  Edit2,
  Eye,
  CheckCircle2,
  Search,
  ExternalLink,
  Download,
  Copy,
  Check,
  X,
  Pin,
  Calendar,
  Sparkles,
} from 'lucide-react';

interface AdminContentHubProps {
  initialSubTab?: 'articles' | 'announcements' | 'documents' | 'media';
}

export const AdminContentHub: React.FC<AdminContentHubProps> = ({
  initialSubTab = 'articles',
}) => {
  const { state, createArticle, updateArticle, deleteArticle } = useApp();

  const [activeTab, setActiveTab] = useState<'articles' | 'announcements' | 'documents' | 'media'>(
    initialSubTab
  );

  React.useEffect(() => {
    if (initialSubTab) {
      setActiveTab(initialSubTab);
    }
  }, [initialSubTab]);

  const [searchQuery, setSearchQuery] = useState('');
  const [showAddArticleModal, setShowAddArticleModal] = useState(false);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // New Article Form
  const [newArticle, setNewArticle] = useState({
    title: '',
    category: 'Áp lực học tập',
    author: 'Ban Tư vấn Tâm lý Trường',
    readTime: '4 phút',
    summary: '',
    content: '',
    imageUrl:
      'https://images.unsplash.com/photo-1516534775068-ba3e7458af70?auto=format&fit=crop&w=800&q=80',
  });

  // Announcements state
  const [announcements, setAnnouncements] = useState([
    {
      id: 'ann-1',
      title: 'Thông báo: Lịch sinh hoạt Chuyên đề Tâm lý "Vượt qua áp lực thi cử" khối 12',
      date: '14/09/2026',
      author: 'Phòng Tư Vấn Tâm Lý',
      isPinned: true,
      content:
        'Nhằm hỗ trợ các em học sinh khối 12 giải tỏa căng thẳng trước các kỳ thi khảo sát, Phòng Tư vấn tổ chức buổi tọa đàm vào sáng Thứ Bảy tại Hội trường lớn.',
    },
    {
      id: 'ann-2',
      title: 'Khai trương Phòng Suy Nghĩ Tích Cực (Positive Room) trực tuyến',
      date: '10/09/2026',
      author: 'Ban Giám Hiệu & Tổ Tư Vấn',
      isPinned: true,
      content:
        'Học sinh có thể truy cập không gian thư giãn ảo với âm thanh thiên nhiên, giọng nói đồng cảm và hỗ trợ tâm lý 24/7.',
    },
    {
      id: 'ann-3',
      title: 'Triển khai làm trắc nghiệm DASS-21 định kỳ đầu học kỳ 1',
      date: '05/09/2026',
      author: 'Ban Tư Vấn Tâm Lý',
      isPinned: false,
      content:
        'Đề nghị tất cả học sinh các khối 10, 11, 12 hoàn thành bài trắc nghiệm sức khỏe tâm thần trong tuần này.',
    },
  ]);

  // Documents state
  const documents = [
    {
      id: 'doc-1',
      title: 'Sổ tay Kỹ năng Ứng phó Căng thẳng Học đường dành cho Học sinh THPT',
      size: '3.4 MB',
      type: 'PDF',
      category: 'Kỹ năng sống',
      downloads: 482,
    },
    {
      id: 'doc-2',
      title: 'Cẩm nang Phòng ngừa & Xử lý Bạo lực Học đường trong Kỷ nguyên Số',
      size: '2.1 MB',
      type: 'PDF',
      category: 'An toàn học đường',
      downloads: 319,
    },
    {
      id: 'doc-3',
      title: 'Hướng dẫn Phụ huynh: Lắng nghe và Đồng hành Cảm xúc cùng Tuổi Dậy thì',
      size: '4.8 MB',
      type: 'PDF',
      category: 'Tài liệu Phụ huynh',
      downloads: 590,
    },
    {
      id: 'doc-4',
      title: 'Bộ phiếu tự đánh giá và Nhật ký Cảm xúc Hằng ngày (Mood Journal)',
      size: '1.2 MB',
      type: 'DOCX',
      category: 'Thực hành tâm lý',
      downloads: 275,
    },
  ];

  // Media Library presets
  const mediaLibrary = [
    {
      id: 'm1',
      name: 'Banner Học sinh Vui vẻ',
      url: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=800&q=80',
      category: 'Banner',
    },
    {
      id: 'm2',
      name: 'Không gian Thiền & Thư giãn',
      url: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=800&q=80',
      category: 'Positive Room',
    },
    {
      id: 'm3',
      name: 'Chuyên viên Tâm lý Lắng nghe',
      url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80',
      category: 'Counselor',
    },
    {
      id: 'm4',
      name: 'Sách & Áp lực Học tập',
      url: 'https://images.unsplash.com/photo-1516534775068-ba3e7458af70?auto=format&fit=crop&w=800&q=80',
      category: 'Article',
    },
    {
      id: 'm5',
      name: 'Thiên nhiên Tĩnh lặng',
      url: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?auto=format&fit=crop&w=800&q=80',
      category: 'Wallpaper',
    },
    {
      id: 'm6',
      name: 'Học sinh Thảo luận Nhóm',
      url: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=800&q=80',
      category: 'Community',
    },
  ];

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Handle Add Article
  const handleCreateArticleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newArticle.title.trim()) return;

    const res = await createArticle({
      title: newArticle.title.trim(),
      category: newArticle.category,
      author: newArticle.author,
      readTime: newArticle.readTime,
      excerpt: newArticle.summary,
      content: newArticle.content,
      imageUrl: newArticle.imageUrl,
      date: new Date().toLocaleDateString('vi-VN'),
    });

    if (res.success) {
      showToast('Đã xuất bản bài viết mới thành công');
      setShowAddArticleModal(false);
      setNewArticle({
        title: '',
        category: 'Áp lực học tập',
        author: 'Ban Tư vấn Tâm lý Trường',
        readTime: '4 phút',
        summary: '',
        content: '',
        imageUrl:
          'https://images.unsplash.com/photo-1516534775068-ba3e7458af70?auto=format&fit=crop&w=800&q=80',
      });
    } else {
      alert('Lỗi: ' + res.error);
    }
  };

  const filteredArticles = (state.articles || []).filter((art) =>
    art.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-white px-5 py-3 rounded-2xl shadow-xl border border-stone-700 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-100 text-emerald-700">
              <FileText className="w-5 h-5" />
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              Quản Trị Nội Dung
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight">
            Nội Dung, Tin Tức & Thư Viện Học Liệu
          </h2>
          <p className="text-xs text-stone-600 max-w-2xl">
            Quản trị các bài viết chia sẻ cẩm nang tâm lý, phát hành thông báo chính thức, quản lý tài liệu hướng dẫn kỹ năng sống và lưu trữ kho ảnh truyền thông.
          </p>
        </div>

        {/* Sub-tab Navigation */}
        <div className="flex flex-wrap items-center gap-1.5 bg-stone-100 p-1.5 rounded-2xl border border-stone-200">
          <button
            type="button"
            onClick={() => setActiveTab('articles')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'articles'
                ? 'bg-white text-emerald-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Bài viết ({state.articles?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('announcements')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'announcements'
                ? 'bg-white text-emerald-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Thông báo ({announcements.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('documents')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'documents'
                ? 'bg-white text-emerald-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Tài liệu ({documents.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('media')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'media'
                ? 'bg-white text-emerald-700 shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Media Library ({mediaLibrary.length})</span>
          </button>
        </div>
      </div>

      {/* ================= 1. BÀI VIẾT ================= */}
      {activeTab === 'articles' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-stone-200 shadow-2xs">
            <div className="flex items-center gap-2 flex-1 min-w-[240px] max-w-md bg-stone-50 px-3 py-2 rounded-xl border border-stone-200">
              <Search className="w-4 h-4 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Tìm bài viết theo tiêu đề..."
                className="w-full bg-transparent text-xs text-stone-800 outline-none font-medium"
              />
            </div>
            <button
              type="button"
              onClick={() => setShowAddArticleModal(true)}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Viết bài mới</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredArticles.map((article) => (
              <div
                key={article.id}
                className="bg-white rounded-3xl overflow-hidden border border-stone-200 shadow-2xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <img
                    src={article.imageUrl}
                    alt={article.title}
                    className="w-full h-44 object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="p-5 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        {article.category}
                      </span>
                      <span className="text-[11px] text-stone-400">{article.date}</span>
                    </div>
                    <h4 className="font-bold text-stone-900 text-base line-clamp-2 leading-snug">
                      {article.title}
                    </h4>
                    <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                      {article.excerpt || article.content}
                    </p>
                  </div>
                </div>

                <div className="p-4 border-t border-stone-100 bg-stone-50/50 flex items-center justify-between">
                  <span className="text-[11px] text-stone-400">{article.author}</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(`Bạn có chắc muốn xóa bài viết "${article.title}"?`)) {
                          deleteArticle(article.id);
                          showToast('Đã xóa bài viết');
                        }
                      }}
                      className="p-1.5 rounded-xl hover:bg-red-50 text-red-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= 2. THÔNG BÁO ================= */}
      {activeTab === 'announcements' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-stone-900 text-base">Bảng Thông Báo Trường Học & Phòng Tư Vấn</h3>
            <button
              type="button"
              onClick={() => {
                const title = prompt('Nhập tiêu đề thông báo mới:');
                if (title) {
                  setAnnouncements([
                    {
                      id: `ann-${Date.now()}`,
                      title,
                      date: new Date().toLocaleDateString('vi-VN'),
                      author: 'Quản trị viên',
                      isPinned: false,
                      content: 'Nội dung thông báo mới được phát hành.',
                    },
                    ...announcements,
                  ]);
                  showToast('Đã tạo thông báo mới');
                }
              }}
              className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Tạo thông báo mới</span>
            </button>
          </div>

          <div className="space-y-3">
            {announcements.map((ann) => (
              <div
                key={ann.id}
                className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs flex items-start justify-between gap-4"
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2">
                    {ann.isPinned && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-800 flex items-center gap-1">
                        <Pin className="w-3 h-3 fill-current" />
                        <span>Đã ghim</span>
                      </span>
                    )}
                    <span className="text-xs text-stone-400">{ann.date}</span>
                    <span className="text-xs text-stone-400">• Bởi: {ann.author}</span>
                  </div>
                  <h4 className="font-bold text-stone-900 text-base">{ann.title}</h4>
                  <p className="text-xs text-stone-600 leading-relaxed">{ann.content}</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setAnnouncements(
                        announcements.map((a) => (a.id === ann.id ? { ...a, isPinned: !a.isPinned } : a))
                      );
                      showToast(`Đã ${!ann.isPinned ? 'ghim' : 'bỏ ghim'} thông báo`);
                    }}
                    className={`p-2 rounded-xl border text-xs font-semibold ${
                      ann.isPinned
                        ? 'border-red-200 bg-red-50 text-red-700'
                        : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <Pin className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAnnouncements(announcements.filter((a) => a.id !== ann.id));
                      showToast('Đã xóa thông báo');
                    }}
                    className="p-2 rounded-xl border border-stone-200 text-stone-400 hover:text-red-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= 3. TÀI LIỆU ================= */}
      {activeTab === 'documents' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs space-y-1">
            <h3 className="font-bold text-stone-900 text-base">Thư Viện Tài Liệu Sức Khỏe Tinh Thần</h3>
            <p className="text-xs text-stone-500">
              Cung cấp các cẩm nang, sổ tay hướng dẫn kỹ năng sống và tài liệu tâm lý học đường cho học sinh, phụ huynh và giáo viên.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {documents.map((doc) => (
              <div
                key={doc.id}
                className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs hover:shadow-md transition-all flex items-start justify-between gap-4"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-xs shrink-0">
                    {doc.type}
                  </div>
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-100 text-stone-600">
                      {doc.category}
                    </span>
                    <h4 className="font-bold text-stone-900 text-sm leading-snug">{doc.title}</h4>
                    <p className="text-[11px] text-stone-400">
                      Dung lượng: {doc.size} • {doc.downloads} lượt tải về
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => showToast(`Bắt đầu tải xuống: ${doc.title}`)}
                  className="p-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 shrink-0 transition-colors"
                  title="Tải tài liệu"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= 4. MEDIA LIBRARY ================= */}
      {activeTab === 'media' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-stone-900 text-base">Thư Viện Hình Ảnh (Media Assets)</h3>
              <p className="text-xs text-stone-500">
                Kho hình ảnh bản quyền chất lượng cao sử dụng cho Banner, Bài viết và Phòng tích cực.
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                const url = prompt('Dán URL hình ảnh bạn muốn thêm vào thư viện:');
                if (url) {
                  showToast('Đã thêm hình ảnh mới vào thư viện media');
                }
              }}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm ảnh mới</span>
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {mediaLibrary.map((item) => (
              <div
                key={item.id}
                className="group relative rounded-2xl overflow-hidden border border-stone-200 bg-stone-100 aspect-video shadow-2xs"
              >
                <img
                  src={item.url}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-3 text-white">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-black/40 self-start">
                    {item.category}
                  </span>
                  <div className="space-y-1">
                    <p className="text-xs font-bold leading-snug">{item.name}</p>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(item.url);
                        showToast('Đã sao chép link ảnh vào bộ nhớ tạm');
                      }}
                      className="text-[11px] font-semibold bg-white/20 hover:bg-white/30 px-2 py-1 rounded-md flex items-center gap-1 w-full justify-center"
                    >
                      <Copy className="w-3 h-3" />
                      <span>Sao chép URL</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= MODAL: ADD ARTICLE ================= */}
      {showAddArticleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 space-y-4 border border-stone-200 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <h3 className="font-extrabold text-stone-900 text-base">Đăng Bài Viết Cẩm Nang Mới</h3>
              <button
                type="button"
                onClick={() => setShowAddArticleModal(false)}
                className="text-stone-400 hover:text-stone-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateArticleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-stone-700 mb-1">Tiêu đề bài viết *</label>
                <input
                  type="text"
                  required
                  value={newArticle.title}
                  onChange={(e) => setNewArticle({ ...newArticle, title: e.target.value })}
                  placeholder="Ví dụ: 5 Phút Thở Chánh Niệm Giúp Giảm Căng Thẳng Trong Phòng Thi"
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 font-medium outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Chuyên mục:</label>
                  <select
                    value={newArticle.category}
                    onChange={(e) => setNewArticle({ ...newArticle, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 font-medium"
                  >
                    <option value="Áp lực học tập">Áp lực học tập</option>
                    <option value="Mối quan hệ bạn bè">Mối quan hệ bạn bè</option>
                    <option value="Quản lý cảm xúc">Quản lý cảm xúc</option>
                    <option value="Định hướng tương lai">Định hướng tương lai</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Thời lượng đọc:</label>
                  <input
                    type="text"
                    value={newArticle.readTime}
                    onChange={(e) => setNewArticle({ ...newArticle, readTime: e.target.value })}
                    placeholder="4 phút"
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 font-medium outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Tóm tắt ngắn (Excerpt):</label>
                <textarea
                  rows={2}
                  value={newArticle.summary}
                  onChange={(e) => setNewArticle({ ...newArticle, summary: e.target.value })}
                  placeholder="Một đoạn mô tả ngắn hiển thị trên thẻ bài viết..."
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 font-medium outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">Nội dung bài viết *</label>
                <textarea
                  rows={6}
                  required
                  value={newArticle.content}
                  onChange={(e) => setNewArticle({ ...newArticle, content: e.target.value })}
                  placeholder="Nội dung chi tiết bài viết..."
                  className="w-full p-3 rounded-xl border border-stone-300 font-medium outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-700 mb-1">URL Ảnh bìa:</label>
                <input
                  type="text"
                  value={newArticle.imageUrl}
                  onChange={(e) => setNewArticle({ ...newArticle, imageUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 font-medium outline-none"
                />
              </div>

              <div className="pt-3 border-t border-stone-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddArticleModal(false)}
                  className="px-4 py-2 rounded-xl text-stone-600 font-bold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-700"
                >
                  Xuất bản ngay
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
