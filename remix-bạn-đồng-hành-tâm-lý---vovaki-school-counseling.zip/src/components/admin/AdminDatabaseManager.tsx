import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Database,
  Download,
  Upload,
  RotateCcw,
  Trash2,
  Plus,
  Search,
  Eye,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  X,
  FileSpreadsheet,
  Server,
  Layers,
  Code,
  ShieldCheck,
} from 'lucide-react';

export const AdminDatabaseManager: React.FC = () => {
  const {
    state,
    clearDatabaseTable,
    deleteDatabaseRow,
    addDatabaseRow,
    restoreDatabase,
    exportSecureData,
  } = useApp();

  const [selectedTable, setSelectedTable] = useState<
    | 'users'
    | 'articles'
    | 'bookings'
    | 'emergencySessions'
    | 'positiveRoomSessions'
    | 'studentRecords'
    | 'testSubmissions'
    | 'sentimentAnalyses'
  >('users');

  const [searchQuery, setSearchQuery] = useState('');
  const [toastMsg, setToastMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Row inspection modal
  const [inspectingRow, setInspectingRow] = useState<any | null>(null);

  // Add row modal
  const [showAddRowModal, setShowAddRowModal] = useState(false);
  const [newRowJson, setNewRowJson] = useState('{\n  "title": "Bản ghi mới",\n  "createdAt": "2026-09-11"\n}');

  // Table clear confirm modal
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Restore DB modal
  const [showRestoreModal, setShowRestoreModal] = useState(false);
  const [restoreJsonInput, setRestoreJsonInput] = useState('');

  // Secure export state
  const [exportFormat, setExportFormat] = useState<'csv' | 'json'>('csv');
  const [exportDateFrom, setExportDateFrom] = useState('2026-09-01');
  const [exportDateTo, setExportDateTo] = useState('2026-09-30');
  const [isExporting, setIsExporting] = useState(false);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMsg({ type, text });
    setTimeout(() => setToastMsg(null), 4500);
  };

  // Get raw items of the selected table
  const getTableRows = (): any[] => {
    switch (selectedTable) {
      case 'users':
        return state.users || [];
      case 'articles':
        return state.articles || [];
      case 'bookings':
        return state.bookings || [];
      case 'emergencySessions':
        return state.emergencySessions || [];
      case 'positiveRoomSessions':
        return state.positiveRoomSessions || [];
      case 'studentRecords':
        return state.studentRecords || [];
      case 'testSubmissions':
        return state.testSubmissions || [];
      case 'sentimentAnalyses':
        return state.sentimentAnalyses || [];
      default:
        return [];
    }
  };

  const rows = getTableRows();

  // Filtered rows
  const filteredRows = rows.filter((r) => {
    if (!searchQuery.trim()) return true;
    const jsonString = JSON.stringify(r).toLowerCase();
    return jsonString.includes(searchQuery.toLowerCase());
  });

  // Table metadata description
  const tableDescriptions: Record<string, { label: string; count: number; desc: string }> = {
    users: {
      label: 'Tài khoản (users)',
      count: state.users?.length || 0,
      desc: 'Bảng quản lý tài khoản học sinh, giáo viên và quản trị viên',
    },
    articles: {
      label: 'Bài viết Cẩm nang (articles)',
      count: state.articles?.length || 0,
      desc: 'Kho bài viết kiến thức tâm lý học đường trên trang chủ',
    },
    bookings: {
      label: 'Lịch hẹn Tư vấn (bookings)',
      count: state.bookings?.length || 0,
      desc: 'Các buổi tham vấn 1-1 giữa học sinh và giáo viên tâm lý',
    },
    emergencySessions: {
      label: 'Phiên Khẩn cấp (emergencySessions)',
      count: state.emergencySessions?.length || 0,
      desc: 'Các phiên hỗ trợ tâm lý khẩn cấp ẩn danh 24/7',
    },
    positiveRoomSessions: {
      label: 'Phòng Tích cực Vovakier (positiveRoomSessions)',
      count: state.positiveRoomSessions?.length || 0,
      desc: 'Nhật ký trò chuyện cùng trợ lý AI Vovakier và người điều phối',
    },
    studentRecords: {
      label: 'Hồ sơ Sức khỏe Tâm lý (studentRecords)',
      count: state.studentRecords?.length || 0,
      desc: 'Hồ sơ theo dõi sức khỏe tâm thần và lịch sử can thiệp',
    },
    testSubmissions: {
      label: 'Kết quả Khảo sát (testSubmissions)',
      count: state.testSubmissions?.length || 0,
      desc: 'Kết quả trắc nghiệm tâm lý học sinh gửi lên',
    },
    sentimentAnalyses: {
      label: 'Báo cáo Cảm xúc AI (sentimentAnalyses)',
      count: state.sentimentAnalyses?.length || 0,
      desc: 'Nhật ký phân tích cảm xúc và phát hiện cảnh báo nguy cơ bằng AI',
    },
  };

  // Delete single row
  const handleDeleteRow = async (rowId: string) => {
    if (!confirm(`Bạn có chắc chắn muốn xóa bản ghi ID "${rowId}" khỏi bảng ${selectedTable}?`)) {
      return;
    }
    setIsProcessing(true);
    const res = await deleteDatabaseRow(selectedTable, rowId);
    setIsProcessing(false);

    if (res.success) {
      showToast(`Đã xóa thành công bản ghi khỏi bảng ${selectedTable}`);
    } else {
      showToast(res.error || 'Xóa bản ghi thất bại', 'error');
    }
  };

  // Clear table
  const handleClearTable = async () => {
    setIsProcessing(true);
    const res = await clearDatabaseTable(selectedTable);
    setIsProcessing(false);
    setShowClearConfirm(false);

    if (res.success) {
      showToast(`Đã xóa sạch toàn bộ dữ liệu của bảng ${selectedTable}`);
    } else {
      showToast(res.error || 'Xóa bảng thất bại', 'error');
    }
  };

  // Add new row via JSON
  const handleAddRowSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const parsedData = JSON.parse(newRowJson);
      setIsProcessing(true);
      const res = await addDatabaseRow(selectedTable, parsedData);
      setIsProcessing(false);

      if (res.success) {
        showToast(`Đã thêm thành công bản ghi mới vào bảng ${selectedTable}`);
        setShowAddRowModal(false);
      } else {
        showToast(res.error || 'Thêm bản ghi thất bại', 'error');
      }
    } catch (err: any) {
      showToast(`Dữ liệu JSON không hợp lệ: ${err.message}`, 'error');
    }
  };

  // Download entire database as JSON backup
  const handleDownloadFullDatabaseBackup = () => {
    const fullBackup = {
      exportTimestamp: new Date().toISOString(),
      version: '2.0.0',
      system: 'VoVaKi Mental Health Portal',
      database: {
        users: state.users,
        articles: state.articles,
        bookings: state.bookings,
        emergencySessions: state.emergencySessions,
        positiveRoomSessions: state.positiveRoomSessions,
        studentRecords: state.studentRecords,
        testSubmissions: state.testSubmissions,
        sentimentAnalyses: state.sentimentAnalyses,
        psychologicalTests: state.psychologicalTests,
        siteSettings: state.siteSettings,
        classes: state.classes,
        realtimeSettings: state.realtimeSettings,
        authSettings: state.authSettings,
      },
    };

    const blob = new Blob([JSON.stringify(fullBackup, null, 2)], {
      type: 'application/json;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vovaki_full_database_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    showToast('Đã tải xuống file sao lưu toàn bộ cơ sở dữ liệu thành công!');
  };

  // Restore database from JSON
  const handleRestoreSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const parsed = JSON.parse(restoreJsonInput);
      const dbPayload = parsed.database || parsed;
      setIsProcessing(true);
      const res = await restoreDatabase(dbPayload);
      setIsProcessing(false);

      if (res.success) {
        showToast('Đã khôi phục toàn bộ Cơ sở dữ liệu thành công!');
        setShowRestoreModal(false);
        setRestoreJsonInput('');
      } else {
        showToast(res.error || 'Khôi phục CSDL thất bại', 'error');
      }
    } catch (err: any) {
      showToast(`Lỗi định dạng JSON: ${err.message}`, 'error');
    }
  };

  // Run secure data export
  const handleRunSecureExport = async () => {
    setIsExporting(true);
    try {
      const res = await exportSecureData({
        format: exportFormat,
        subset: selectedTable,
        dateFrom: exportDateFrom || undefined,
        dateTo: exportDateTo || undefined,
      });

      if (!res.success || !res.dataString) {
        showToast(res.error || 'Trích xuất thất bại', 'error');
        setIsExporting(false);
        return;
      }

      const blob = new Blob([res.dataString], {
        type: res.mimeType || (exportFormat === 'csv' ? 'text/csv;charset=utf-8;' : 'application/json;charset=utf-8;'),
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = res.filename || `vovaki_${selectedTable}_export.${exportFormat}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);

      showToast(`Đã xuất an toàn ${res.recordCount ?? 0} bản ghi (Định dạng: ${exportFormat.toUpperCase()})`);
    } catch (err: any) {
      showToast(err.message || 'Lỗi mạng khi xuất dữ liệu', 'error');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notice */}
      {toastMsg && (
        <div
          className={`p-4 rounded-xl text-xs font-semibold flex items-center justify-between shadow-xs transition-all ${
            toastMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {toastMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span>{toastMsg.text}</span>
          </div>
          <button
            type="button"
            onClick={() => setToastMsg(null)}
            className="p-1 hover:bg-black/5 rounded text-stone-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Database Header & Global Action Bar */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center font-bold">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-stone-900">
              Quản lý Cơ sở Dữ liệu Toàn diện (Full Database Management)
            </h3>
            <p className="text-xs text-stone-500">
              Toàn quyền duyệt bảng, thêm/xóa từng bản ghi, xóa sạch bảng, sao lưu và phục hồi CSDL
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleDownloadFullDatabaseBackup}
            className="px-3.5 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold flex items-center gap-2 shadow-xs transition-all"
            title="Tải toàn bộ cơ sở dữ liệu về máy dưới dạng JSON"
          >
            <Download className="w-4 h-4" />
            <span>Sao lưu JSON Toàn CSDL</span>
          </button>

          <button
            type="button"
            onClick={() => setShowRestoreModal(true)}
            className="px-3.5 py-2 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-900 text-xs font-semibold flex items-center gap-2 transition-all"
            title="Khôi phục dữ liệu từ bản sao lưu JSON"
          >
            <Upload className="w-4 h-4" />
            <span>Khôi phục CSDL</span>
          </button>
        </div>
      </div>

      {/* Table Selector Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {Object.entries(tableDescriptions).map(([key, info]) => {
          const isSelected = selectedTable === key;
          return (
            <button
              key={key}
              type="button"
              onClick={() => {
                setSelectedTable(key as any);
                setSearchQuery('');
              }}
              className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                isSelected
                  ? 'bg-purple-600 text-white border-purple-700 shadow-xs'
                  : 'bg-white hover:bg-stone-50 text-stone-800 border-stone-200'
              }`}
            >
              <div className="flex items-center justify-between gap-1">
                <span className={`text-[11px] font-mono font-bold truncate ${isSelected ? 'text-purple-100' : 'text-stone-500'}`}>
                  {key}
                </span>
                <span
                  className={`text-[11px] px-2 py-0.5 rounded-full font-bold shrink-0 ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-800'
                  }`}
                >
                  {info.count}
                </span>
              </div>
              <p className={`text-xs font-bold mt-2 truncate ${isSelected ? 'text-white' : 'text-stone-900'}`}>
                {info.label.split('(')[0].trim()}
              </p>
            </button>
          );
        })}
      </div>

      {/* Selected Table Explorer Card */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
        {/* Table Header Bar */}
        <div className="p-4 bg-stone-50 border-b border-stone-200 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-600" />
              <h4 className="font-bold text-sm text-stone-900">
                Bảng: <span className="font-mono text-purple-700">{selectedTable}</span> ({filteredRows.length}/{rows.length} bản ghi)
              </h4>
            </div>
            <p className="text-[11px] text-stone-500 mt-0.5">
              {tableDescriptions[selectedTable]?.desc}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setShowAddRowModal(true);
                setNewRowJson('{\n  "title": "Bản ghi mới",\n  "createdAt": "' + new Date().toISOString().slice(0, 10) + '"\n}');
              }}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center gap-1.5 shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Thêm dòng mới</span>
            </button>

            <button
              type="button"
              onClick={() => setShowClearConfirm(true)}
              className="px-3 py-1.5 rounded-lg bg-red-100 hover:bg-red-200 text-red-700 font-semibold text-xs flex items-center gap-1.5"
              title="Xóa toàn bộ các dòng của bảng này"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Xóa sạch bảng</span>
            </button>
          </div>
        </div>

        {/* Search & Export Toolbar */}
        <div className="p-3.5 border-b border-stone-100 bg-white flex flex-wrap items-center justify-between gap-3">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`Tìm kiếm bất kỳ nội dung nào trong bảng ${selectedTable}...`}
              className="w-full pl-9 pr-4 py-1.5 rounded-lg border border-stone-200 text-xs focus:ring-2 focus:ring-purple-500 focus:outline-none"
            />
          </div>

          {/* Quick Export for this table */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-stone-500 font-medium">Xuất dữ liệu:</span>
            <select
              value={exportFormat}
              onChange={(e) => setExportFormat(e.target.value as any)}
              className="px-2 py-1 rounded border border-stone-200 text-xs font-mono"
            >
              <option value="csv">CSV (UTF-8)</option>
              <option value="json">JSON</option>
            </select>
            <button
              type="button"
              onClick={handleRunSecureExport}
              disabled={isExporting}
              className="px-3 py-1 rounded bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold flex items-center gap-1"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>{isExporting ? 'Đang xuất...' : 'Tải về'}</span>
            </button>
          </div>
        </div>

        {/* Records Table / List */}
        <div className="overflow-x-auto max-h-[500px]">
          {filteredRows.length === 0 ? (
            <div className="p-8 text-center text-stone-400 text-xs">
              <Database className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p>Bảng "{selectedTable}" hiện chưa có dữ liệu hoặc không có bản ghi khớp với tìm kiếm.</p>
            </div>
          ) : (
            <table className="w-full text-left text-xs text-stone-700">
              <thead className="bg-stone-50 border-b border-stone-200 text-[11px] font-bold text-stone-500 uppercase tracking-wider sticky top-0 z-10">
                <tr>
                  <th className="px-4 py-3">STT / ID</th>
                  <th className="px-4 py-3">Nội dung chính</th>
                  <th className="px-4 py-3">Thời gian</th>
                  <th className="px-4 py-3 text-right">Thao tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredRows.map((row, idx) => {
                  const rowId = row.id || row.studentCode || `record_${idx}`;
                  const title =
                    row.fullName ||
                    row.title ||
                    row.studentNickname ||
                    row.studentName ||
                    row.topic ||
                    row.username ||
                    `Bản ghi #${idx + 1}`;
                  const time = row.createdAt || row.bookingDate || row.timestamp || row.date || '—';

                  return (
                    <tr key={rowId} className="hover:bg-stone-50/80 transition-colors">
                      <td className="px-4 py-3 font-mono text-[11px] text-stone-500">
                        <span className="font-bold text-stone-800 mr-2">#{idx + 1}</span>
                        <span>{rowId}</span>
                      </td>

                      <td className="px-4 py-3">
                        <div className="font-semibold text-stone-900">{title}</div>
                        <div className="text-[11px] text-stone-400 truncate max-w-md">
                          {JSON.stringify(row).slice(0, 100)}...
                        </div>
                      </td>

                      <td className="px-4 py-3 text-stone-500 font-mono text-[11px]">
                        {time}
                      </td>

                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => setInspectingRow(row)}
                            className="p-1.5 text-stone-500 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
                            title="Xem chi tiết dữ liệu JSON"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteRow(rowId)}
                            className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Xóa bản ghi này khỏi CSDL"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Modal 1: Inspect Row Details */}
      {inspectingRow && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[85vh]">
            <div className="px-6 py-4 bg-stone-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Code className="w-5 h-5 text-purple-400" />
                <h4 className="font-bold text-base">Chi tiết Bản ghi ({selectedTable})</h4>
              </div>
              <button
                type="button"
                onClick={() => setInspectingRow(null)}
                className="p-1 rounded hover:bg-stone-800 text-stone-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto">
              <pre className="p-4 bg-stone-900 text-emerald-400 font-mono text-xs rounded-xl overflow-x-auto leading-relaxed">
                {JSON.stringify(inspectingRow, null, 2)}
              </pre>
            </div>

            <div className="p-4 bg-stone-50 border-t border-stone-200 flex justify-end">
              <button
                type="button"
                onClick={() => setInspectingRow(null)}
                className="px-4 py-2 rounded-lg bg-stone-900 text-white text-xs font-semibold"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 2: Add Row via JSON */}
      {showAddRowModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-stone-200 overflow-hidden">
            <div className="px-6 py-4 bg-emerald-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                <h4 className="font-bold text-base">Thêm Dòng Mới vào Bảng "{selectedTable}"</h4>
              </div>
              <button
                type="button"
                onClick={() => setShowAddRowModal(false)}
                className="p-1 rounded hover:bg-emerald-800 text-emerald-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddRowSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Dữ liệu bản ghi (Định dạng JSON)
                </label>
                <textarea
                  rows={8}
                  required
                  value={newRowJson}
                  onChange={(e) => setNewRowJson(e.target.value)}
                  className="w-full p-3 font-mono text-xs rounded-xl border border-stone-300 bg-stone-50 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddRowModal(false)}
                  className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs"
                >
                  {isProcessing ? 'Đang thêm...' : 'Lưu bản ghi vào CSDL'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 3: Confirm Clear Table */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-stone-200 p-6 space-y-4">
            <div className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="w-6 h-6" />
              <h4 className="font-bold text-base">Cảnh báo Xóa Sạch Bảng</h4>
            </div>

            <p className="text-xs text-stone-700 leading-relaxed">
              Bạn có chắc chắn muốn xóa toàn bộ tất cả bản ghi của bảng{' '}
              <strong className="text-red-600 font-mono font-bold">{selectedTable}</strong>?
            </p>

            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
              Dữ liệu trong bảng sẽ được làm trống ngay lập tức. Hãy chắc chắn bạn đã tải file sao lưu JSON trước khi thực hiện.
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={handleClearTable}
                disabled={isProcessing}
                className="px-5 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-xs"
              >
                {isProcessing ? 'Đang xóa...' : 'Xác nhận Xóa sạch'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 4: Restore Database from JSON */}
      {showRestoreModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-stone-200 overflow-hidden">
            <div className="px-6 py-4 bg-purple-700 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Upload className="w-5 h-5" />
                <h4 className="font-bold text-base">Khôi phục Toàn bộ CSDL từ JSON</h4>
              </div>
              <button
                type="button"
                onClick={() => setShowRestoreModal(false)}
                className="p-1 rounded hover:bg-purple-800 text-purple-200 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRestoreSubmit} className="p-6 space-y-4">
              <p className="text-xs text-stone-600">
                Dán nội dung JSON từ file sao lưu (backup) vào ô dưới đây để ghi đè và phục hồi dữ liệu:
              </p>

              <div>
                <textarea
                  rows={10}
                  required
                  value={restoreJsonInput}
                  onChange={(e) => setRestoreJsonInput(e.target.value)}
                  placeholder="Dán mã JSON backup ở đây..."
                  className="w-full p-3 font-mono text-xs rounded-xl border border-stone-300 bg-stone-50 focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRestoreModal(false)}
                  className="px-4 py-2 rounded-lg border border-stone-200 text-xs font-medium"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-5 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs"
                >
                  {isProcessing ? 'Đang khôi phục...' : 'Bắt đầu Khôi phục'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
