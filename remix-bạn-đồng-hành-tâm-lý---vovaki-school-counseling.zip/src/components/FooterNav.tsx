import React from 'react';
import { useApp } from '../context/AppContext';
import { ArrowLeft, Home, LayoutDashboard, LogIn, Phone, Mail, Globe, MessageSquare, MapPin } from 'lucide-react';

export const FooterNav: React.FC<{ onOpenLogin: () => void }> = ({ onOpenLogin }) => {
  const { state, currentUser, currentView, setCurrentView } = useApp();
  const { siteSettings } = state;

  const handleBack = () => {
    if (currentView === 'home') return;
    if (currentView === 'urgent_chat' || currentView === 'booking_chat' || currentView === 'positive_room' || currentView === 'test_taker') {
      setCurrentView(currentUser ? 'dashboard' : 'home');
    } else {
      setCurrentView('home');
    }
  };

  const getPositionClasses = () => {
    switch (siteSettings.navButtonPosition) {
      case 'bottom-left':
        return 'justify-start';
      case 'bottom-right':
        return 'justify-end';
      case 'bottom-center':
      default:
        return 'justify-center';
    }
  };

  return (
    <footer className="mt-auto border-t border-stone-200 bg-stone-900 text-stone-300">
      {/* Footer information section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 text-sm">
          {/* Col 1: About */}
          <div className="md:col-span-2 space-y-3">
            <h3 className="text-white font-bold text-base tracking-tight">
              {siteSettings.siteName}
            </h3>
            <p className="text-stone-400 text-xs leading-relaxed max-w-lg">
              Không gian lắng nghe, thấu cảm và hỗ trợ tâm lý học đường toàn diện. Nơi mọi khó khăn tuổi học trò đều được đón nhận bằng sự ấm áp, bảo mật và đồng hành khoa học.
            </p>
            <div className="flex items-start gap-2 text-xs text-stone-400 pt-1">
              <MapPin className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
              <span>{siteSettings.footerInfo.address}</span>
            </div>
          </div>

          {/* Col 2: Hotline & Contacts */}
          <div className="space-y-2.5">
            <h4 className="text-white font-semibold text-xs uppercase tracking-wider">
              Kênh liên lạc hỗ trợ
            </h4>
            <ul className="space-y-2 text-xs text-stone-400">
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Hotline: <strong className="text-stone-200">{siteSettings.footerInfo.hotline}</strong></span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-stone-400" />
                <span>Điện thoại bàn: {siteSettings.footerInfo.phone}</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-stone-400" />
                <span>Email: {siteSettings.footerInfo.email}</span>
              </li>
            </ul>
          </div>

          {/* Col 3: Social & Zalo */}
          <div className="space-y-2.5">
            <h4 className="text-white font-semibold text-xs uppercase tracking-wider">
              Mạng xã hội & Trực tuyến
            </h4>
            <ul className="space-y-2 text-xs text-stone-400">
              <li className="flex items-center gap-2">
                <Globe className="w-3.5 h-3.5 text-blue-400" />
                <a
                  href={siteSettings.footerInfo.facebook}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white transition-colors underline"
                >
                  Facebook Tư vấn VoVaKi
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
                <span>Zalo hỗ trợ: <strong className="text-stone-200">{siteSettings.footerInfo.zalo}</strong></span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-stone-800 pt-6 text-center text-xs text-stone-400">
          © {new Date().getFullYear()} {siteSettings.siteName}. Bản quyền thuộc Phòng Tư vấn Tâm lý Học đường VoVaKi.
        </div>
      </div>

      {/* Floating Bottom Navigation Bar (Website có nút điều hướng: quay về, trang chủ nằm ở cuối website) */}
      <aside aria-label="Điều hướng nhanh cuối trang" className="sticky bottom-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200/90 shadow-lg py-2.5 px-4">
        <div className={`max-w-7xl mx-auto flex items-center gap-2.5 ${getPositionClasses()}`}>
          {/* Nút Quay về */}
          <button
            type="button"
            onClick={handleBack}
            disabled={currentView === 'home'}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
              currentView === 'home'
                ? 'opacity-40 cursor-not-allowed bg-stone-100 text-stone-400'
                : 'bg-stone-100 hover:bg-stone-200 text-stone-800 active:scale-95'
            }`}
            title="Quay về trang trước"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Quay về</span>
          </button>

          {/* Nút Trang chủ */}
          <button
            type="button"
            onClick={() => setCurrentView('home')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
              currentView === 'home'
                ? 'text-white shadow-xs'
                : 'bg-stone-100 hover:bg-stone-200 text-stone-800'
            }`}
            style={{
              backgroundColor: currentView === 'home' ? siteSettings.primaryColor : undefined,
            }}
            title="Về Trang chủ"
          >
            <Home className="w-4 h-4" />
            <span>Trang chủ</span>
          </button>

          {/* Nút Bàn làm việc (khi đã đăng nhập) */}
          {currentUser ? (
            <button
              type="button"
              onClick={() => setCurrentView('dashboard')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
                currentView === 'dashboard'
                  ? 'bg-stone-900 text-white shadow-xs'
                  : 'bg-stone-100 hover:bg-stone-200 text-stone-800'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>Khu vực làm việc ({currentUser.role === 'admin' ? 'Admin' : currentUser.role === 'counselor' ? 'Tư vấn' : currentUser.role === 'homeroom' ? 'GVCN' : 'Học sinh'})</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={onOpenLogin}
              className="px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs"
            >
              <LogIn className="w-4 h-4" />
              <span>Đăng nhập hệ thống</span>
            </button>
          )}
        </div>
      </aside>
    </footer>
  );
};
