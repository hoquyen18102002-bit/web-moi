import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  X,
  Send,
  Sparkles,
  Heart,
  Wind,
  Shield,
  Headphones,
  CheckCircle2,
  Square,
  Hand,
  MessageCircleHeart,
  CornerUpRight,
  FastForward,
  LogOut,
} from 'lucide-react';
import { ChatMessage } from '../../types';

export const PositiveRoomModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => {
  const {
    state,
    currentUser,
    sendVovakierChat,
    generateVietnameseSpeech,
    sendPositiveRoomMessage,
    refreshState,
  } = useApp();

  const [isListening, setIsListening] = useState(true);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [ttsEnabled, setTtsEnabled] = useState(true);
  const [textInput, setTextInput] = useState('');
  const [speechTranscript, setSpeechTranscript] = useState('');
  const [activeSessionId, setActiveSessionId] = useState<string>(() => state.positiveRoomSessions[0]?.id || 'pos-1');
  const [breathingPhase, setBreathingPhase] = useState<'hít vào' | 'giữ hơi' | 'thở ra'>('hít vào');
  const [playingMessageId, setPlayingMessageId] = useState<string | null>(null);
  const [voiceStatusText, setVoiceStatusText] = useState<string>('AI luôn lắng nghe bạn • Nói "Bỏ qua" để ngắt lời lập tức');

  // Strict Acoustic Isolation & Anti-Feedback Refs
  const isAiSpeakingRef = useRef<boolean>(false);
  const isListeningRef = useRef<boolean>(true);
  const wasListeningBeforeAiSpeechRef = useRef<boolean>(true);
  const lastAiSpeechEndTimeRef = useRef<number>(0);
  const lastSpokenAiTextRef = useRef<string>('');
  const mediaStreamRef = useRef<MediaStream | null>(null);

  const recognitionRef = useRef<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  // Sync isListeningRef
  useEffect(() => {
    isListeningRef.current = isListening;
  }, [isListening]);

  // Request browser & hardware Acoustic Echo Cancellation (AEC)
  useEffect(() => {
    if (!isOpen || typeof window === 'undefined') return;

    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        })
        .then((stream) => {
          mediaStreamRef.current = stream;
        })
        .catch((err) => {
          console.warn('Microphone AEC notice:', err);
        });
    }

    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
        mediaStreamRef.current = null;
      }
    };
  }, [isOpen]);

  // Current session from shared state
  const currentSession =
    state.positiveRoomSessions.find((s) => s.id === activeSessionId) ||
    state.positiveRoomSessions[0];

  // Keep activeSessionId aligned
  useEffect(() => {
    if (state.positiveRoomSessions.length > 0 && !state.positiveRoomSessions.some((s) => s.id === activeSessionId)) {
      setActiveSessionId(state.positiveRoomSessions[0].id);
    }
  }, [state.positiveRoomSessions, activeSessionId]);

  // Real-time synchronization polling
  useEffect(() => {
    if (!isOpen) return;
    refreshState();
    const pollInterval = setInterval(() => {
      refreshState();
    }, 2500);
    return () => clearInterval(pollInterval);
  }, [isOpen, refreshState]);

  // Auto-scroll messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentSession?.messages]);

  // Breathing rhythm timer
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setBreathingPhase((prev) => {
        if (prev === 'hít vào') return 'giữ hơi';
        if (prev === 'giữ hơi') return 'thở ra';
        return 'hít vào';
      });
    }, 4000);
    return () => clearInterval(interval);
  }, [isOpen]);

  // Stop any playing audio immediately (User Barge-In / Stop)
  const stopAllAudio = useCallback((interruptedByUser: boolean = false) => {
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      audioPlayerRef.current.currentTime = 0;
      audioPlayerRef.current.src = '';
      audioPlayerRef.current = null;
    }
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }

    isAiSpeakingRef.current = false;
    lastAiSpeechEndTimeRef.current = Date.now();
    setIsAiSpeaking(false);
    setPlayingMessageId(null);

    if (interruptedByUser) {
      setVoiceStatusText('Đã ngắt lời AI • Đang lắng nghe bạn...');
    } else {
      setVoiceStatusText('Sẵn sàng trò chuyện');
    }
  }, []);

  // Interrupt AI and immediately start listening to the user
  const handleUserInterrupt = useCallback(() => {
    // 1. Instantly silence AI audio
    stopAllAudio(true);

    // 2. Immediately enable listening for student
    isListeningRef.current = true;
    setIsListening(true);
    wasListeningBeforeAiSpeechRef.current = false;

    try {
      if (recognitionRef.current) {
        recognitionRef.current.start();
      }
    } catch (e) {
      // recognition might already be starting
    }

    setVoiceStatusText('Đã ngắt lời AI • Micro đang mở để lắng nghe bạn nói...');
  }, [stopAllAudio]);

  // Keyboard shortcuts: Spacebar or Escape to interrupt AI immediately
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      const target = e.target as HTMLElement;
      const isInput = target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA');

      if (e.key === 'Escape' && isAiSpeakingRef.current) {
        e.preventDefault();
        handleUserInterrupt();
      } else if (e.key === ' ' && !isInput && isAiSpeakingRef.current) {
        e.preventDefault();
        handleUserInterrupt();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, handleUserInterrupt]);

  // Tự động phát hiện từ khóa "bỏ qua" trong cuộc trò chuyện (hỗ trợ cả có dấu và không dấu)
  const isSkipKeywordPresent = useCallback((text: string): boolean => {
    if (!text) return false;
    const normalized = text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd');

    return (
      normalized.includes('bo qua') ||
      normalized.includes('bo wa') ||
      normalized.includes('thoi bo') ||
      normalized.includes('bo di') ||
      normalized.includes('cho qua') ||
      normalized.includes('qua di') ||
      normalized.includes('ngat loi') ||
      normalized.includes('chuyen chu de') ||
      normalized.includes('doi chu de') ||
      normalized.includes('dung lai')
    );
  }, []);

  // Skip topic / Barge-in trigger handler
  const handleSkipTopic = useCallback((customPrompt?: string) => {
    stopAllAudio(true);
    const msg = customPrompt || 'Bỏ qua chuyện vừa rồi, mình muốn bạn lắng nghe và cho mình lời khuyên thực tế về chủ đề khác.';
    handleSendUserMessage(msg);
  }, [stopAllAudio]);

  // Play audio strictly via HTML5 Audio with Acoustic Echo Filter & "Bỏ qua" Voice Interrupt
  const playAiVoice = useCallback(
    (audioDataUrl: string | null | undefined, text: string, messageId?: string) => {
      if (!ttsEnabled) return;

      // Stop any existing sound completely first
      stopAllAudio();

      if (!text || !text.trim()) return;

      const cleanText = text.trim();
      lastSpokenAiTextRef.current = cleanText.toLowerCase();

      isAiSpeakingRef.current = true;
      setIsAiSpeaking(true);
      if (messageId) {
        setPlayingMessageId(messageId);
      }
      setVoiceStatusText('Vovakier đang phản hồi bằng giọng nói • Nói "Bỏ qua" để ngắt lời lập tức...');

      const onAudioFinished = () => {
        isAiSpeakingRef.current = false;
        lastAiSpeechEndTimeRef.current = Date.now();
        setIsAiSpeaking(false);
        setPlayingMessageId(null);
        audioPlayerRef.current = null;
        setVoiceStatusText('AI luôn lắng nghe bạn • Nói "Bỏ qua" để chuyển hướng bất kỳ lúc nào');
      };

      // Native Vietnamese MP3 stream synthesized on server
      if (audioDataUrl && audioDataUrl.startsWith('data:audio/')) {
        try {
          const audio = new Audio(audioDataUrl);
          audioPlayerRef.current = audio;

          audio.onended = onAudioFinished;
          audio.onerror = () => {
            onAudioFinished();
          };

          audio.play().catch((err) => {
            console.warn('Notice: Audio playback notice:', err);
            onAudioFinished();
          });
          return;
        } catch (err) {
          console.warn('Failed to play audio:', err);
          onAudioFinished();
          return;
        }
      }

      onAudioFinished();
    },
    [ttsEnabled, stopAllAudio]
  );

  // Setup Continuous Web Speech Recognition: AI LUÔN LẮNG NGHE, CHỐNG DỘI LOA, TỰ ĐỘNG PHÁT HIỆN TỪ KHÓA "BỎ QUA"
  useEffect(() => {
    if (!isOpen || typeof window === 'undefined') return;

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = 'vi-VN'; // 100% Tiếng Việt
    recognition.continuous = true;
    recognition.interimResults = true;

    recognition.onresult = (event: any) => {
      let interim = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interim += event.results[i][0].transcript;
        }
      }

      const rawActive = (finalTranscript || interim).trim();
      if (!rawActive) return;

      const hasSkip = isSkipKeywordPresent(rawActive);

      // === 1. CHỐNG DỘI LOA KHI AI ĐANG NÓI & PHÁT HIỆN KHẨU LỆNH "BỎ QUA" ===
      if (isAiSpeakingRef.current) {
        if (hasSkip) {
          // Người nói hô "Bỏ qua" khi AI đang nói:
          // LẬP TỨC NGẮT LỜI AI TRONG 0 MILI-GIÂY!
          stopAllAudio(true);
          isAiSpeakingRef.current = false;
          setVoiceStatusText('Đã nhận khẩu lệnh "Bỏ qua" • Đã ngắt lời AI lập tức, chuyển hướng theo phản hồi của bạn...');

          const trimmedFinal = finalTranscript.trim();
          if (trimmedFinal) {
            handleSendUserMessage(trimmedFinal);
            setSpeechTranscript('');
          } else {
            setSpeechTranscript(rawActive);
          }
        } else {
          // CHỐNG DỘI LOA TUYỆT ĐỐI:
          // Loa máy tính/điện thoại đang phát giọng AI; âm thanh micro thu được lúc này
          // không chứa từ khóa "bỏ qua" chính là âm thanh phát ra từ loa của máy!
          // HỦY BỎ 100%, KHÔNG XỬ LÝ ĐỂ TRÁNH DỘI TIẾNG VÀ VÒNG LẶP ÂM THANH!
          return;
        }
        return;
      }

      // === 2. VÙNG ĐỆM CHỐNG VANG ÂM PHÒNG (350ms sau khi AI dừng nói) ===
      if (Date.now() - lastAiSpeechEndTimeRef.current < 350) {
        if (hasSkip) {
          stopAllAudio(true);
        } else {
          return;
        }
      }

      // === 3. AI LUÔN LẮNG NGHE (NGƯỜI DÙNG ĐANG NÓI TRONG CUỘC TRÒ CHUYỆN) ===
      const trimmedFinal = finalTranscript.trim();
      if (trimmedFinal) {
        if (hasSkip) {
          setVoiceStatusText('Đã phát hiện từ khóa "Bỏ qua" • Đang chuyển hướng câu chuyện...');
        }
        handleSendUserMessage(trimmedFinal);
        setSpeechTranscript('');
      } else {
        setSpeechTranscript(interim);
      }
    };

    recognition.onerror = (event: any) => {
      console.log('Speech recognition status:', event.error);
      if (event.error === 'not-allowed') {
        setIsListening(false);
        isListeningRef.current = false;
        setVoiceStatusText('Vui lòng cho phép quyền Micro để AI luôn lắng nghe bạn');
      }
      // Các lỗi như 'no-speech' hay 'aborted' không tắt micro, onend sẽ tự khởi động lại liên tục
    };

    recognition.onend = () => {
      // AI LUÔN LẮNG NGHE: Tự động khởi động lại ngay khi phiên nhận diện kết thúc
      if (isListeningRef.current && isOpen) {
        try {
          recognition.start();
        } catch (e) {
          setTimeout(() => {
            if (isListeningRef.current && isOpen) {
              try {
                recognition.start();
              } catch (err) {}
            }
          }, 150);
        }
      }
    };

    recognitionRef.current = recognition;

    // Tự động bật nhận diện ngay khi mở phòng
    try {
      recognition.start();
      isListeningRef.current = true;
      setIsListening(true);
      setVoiceStatusText('AI luôn lắng nghe bạn • Nói "Bỏ qua" để ngắt lời lập tức');
    } catch (e) {}

    // Kích hoạt khi có tương tác đầu tiên của người dùng nếu trình duyệt yêu cầu gesture
    const handleFirstUserGesture = () => {
      if (isListeningRef.current && recognitionRef.current) {
        try {
          recognitionRef.current.start();
        } catch (e) {}
      }
    };
    window.addEventListener('click', handleFirstUserGesture, { once: true });
    window.addEventListener('keydown', handleFirstUserGesture, { once: true });

    return () => {
      window.removeEventListener('click', handleFirstUserGesture);
      window.removeEventListener('keydown', handleFirstUserGesture);
      try {
        recognition.stop();
      } catch (e) {}
      stopAllAudio();
    };
  }, [isOpen, stopAllAudio, isSkipKeywordPresent]);

  // Toggle listening
  const toggleListening = () => {
    if (!recognitionRef.current) {
      alert('Trình duyệt hiện tại chưa hỗ trợ nhận diện giọng nói Tiếng Việt. Bạn có thể gõ tin nhắn vào ô chat bên dưới nhé!');
      return;
    }

    // If AI is currently speaking and user clicks the mic button, treat as instant interrupt & listen!
    if (isAiSpeakingRef.current) {
      handleUserInterrupt();
      return;
    }

    if (isListening) {
      // Turn off listening
      isListeningRef.current = false;
      wasListeningBeforeAiSpeechRef.current = false;
      setIsListening(false);
      try {
        recognitionRef.current.stop();
      } catch (e) {}
      setVoiceStatusText('Đã tắt micro');
    } else {
      // Turn on listening
      isListeningRef.current = true;
      setIsListening(true);
      try {
        recognitionRef.current.start();
      } catch (err) {
        console.warn('Khởi động micro notice:', err);
      }
      setVoiceStatusText('Micro đang mở • Đang lắng nghe giọng nói của bạn...');
    }
  };

  // Send message to Vovakier AI
  const handleSendUserMessage = async (text: string) => {
    const cleanText = text.trim();
    if (!cleanText) return;

    // If AI is speaking, interrupt it before sending new user message
    if (isAiSpeakingRef.current) {
      stopAllAudio(true);
    }

    const userMsgId = `pmsg-${Date.now()}`;
    const timestamp = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });

    const studentMsg: ChatMessage = {
      id: userMsgId,
      sender: 'student',
      senderName: currentUser?.fullName || currentSession?.studentNickname || 'Học sinh',
      text: cleanText,
      timestamp,
    };

    const targetSessionId = currentSession?.id || activeSessionId;

    // Send student message to server in real-time
    sendPositiveRoomMessage(targetSessionId, studentMsg);
    setTextInput('');
    setSpeechTranscript('');

    // Call server AI endpoint (100% Pure Vietnamese with empathetic listening & caring response)
    setVoiceStatusText('Vovakier đang ân cần suy nghĩ để sẻ chia cùng bạn...');
    const result = await sendVovakierChat(
      cleanText,
      targetSessionId,
      currentSession?.messages?.slice(-6),
      currentUser?.fullName || currentSession?.studentNickname
    );

    const replyText = result.text || 'Mình luôn ở đây lắng nghe và quan tâm đến bạn.';

    // Read AI reply in authentic Vietnamese audio without redundant sounds
    if (result.audioDataUrl && ttsEnabled) {
      playAiVoice(result.audioDataUrl, replyText, `ai-reply-${Date.now()}`);
    } else {
      setVoiceStatusText('Vovakier đã phản hồi');
    }
  };

  // Re-read a specific message in Vietnamese
  const handleReplayMessage = async (m: ChatMessage) => {
    if (playingMessageId === m.id && isAiSpeaking) {
      handleUserInterrupt();
      return;
    }

    setVoiceStatusText('Đang tải giọng đọc Tiếng Việt chuẩn...');
    const audioUrl = await generateVietnameseSpeech(m.text);
    if (audioUrl) {
      playAiVoice(audioUrl, m.text, m.id);
    }
  };

  if (!isOpen) return null;

  return (
    <div id="positive-room-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-6 animate-fade-in">
      <div className="bg-stone-900 text-stone-100 rounded-3xl max-w-4xl w-full h-[92vh] shadow-2xl border border-stone-800 flex flex-col overflow-hidden relative">
        {/* Background Atmosphere */}
        <div className="absolute inset-0 pointer-events-none opacity-20 bg-gradient-to-br from-emerald-600 via-teal-900 to-indigo-950" />

        {/* Top Header */}
        <div className="relative z-10 px-6 py-4 bg-stone-950/85 border-b border-stone-800/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img
                src={
                  state.siteSettings.positiveRoomAvatar ||
                  'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=200&q=80'
                }
                alt="Ảnh đại diện Vovakier"
                className="w-10 h-10 rounded-full object-cover border-2 border-emerald-500 shadow-sm"
              />
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-stone-950 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-white">Phòng Tích Cực - Vovakier</h3>
                <span className="text-[10px] px-2.5 py-0.5 rounded-full font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <Heart className="w-3 h-3 text-red-400 fill-red-400/40" /> Lắng nghe & Đồng cảm chân thành
                </span>
              </div>
              <p className="text-xs text-stone-400 flex items-center gap-1.5 mt-0.5">
                <Headphones className="w-3.5 h-3.5 text-emerald-400" />
                Chống dội âm từ loa • Chỉ nghe người nói • Cho phép ngắt lời AI
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Breathing Rhythm Guide */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-stone-800/70 border border-stone-700/60 text-xs text-emerald-300">
              <Wind className="w-4 h-4 animate-spin" />
              <span className="capitalize font-medium">Nhịp thở: {breathingPhase}...</span>
            </div>

            {/* TTS sound toggle */}
            <button
              id="positive-room-toggle-tts"
              type="button"
              onClick={() => {
                if (ttsEnabled) {
                  stopAllAudio();
                }
                setTtsEnabled(!ttsEnabled);
              }}
              className={`p-2.5 rounded-xl border transition-colors flex items-center gap-1.5 text-xs font-semibold ${
                ttsEnabled
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-stone-800 text-stone-400 border-stone-700'
              }`}
              title={ttsEnabled ? 'Tắt đọc phản hồi âm thanh' : 'Bật đọc phản hồi bằng Tiếng Việt'}
            >
              {ttsEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              <span className="hidden md:inline">{ttsEnabled ? 'Giọng đọc Tiếng Việt' : 'Tắt âm thanh'}</span>
            </button>

            {/* Nút Kết thúc cuộc trò chuyện */}
            <button
              id="positive-room-end-session-btn"
              type="button"
              onClick={() => {
                if (window.confirm('Bạn có muốn kết thúc cuộc trò chuyện này không? Mọi nội dung tâm sự sẽ được lưu trữ an toàn.')) {
                  stopAllAudio();
                  if (recognitionRef.current) recognitionRef.current.stop();
                  onClose();
                }
              }}
              className="px-3 py-2 rounded-xl bg-red-600/80 hover:bg-red-600 text-white border border-red-500/50 text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
              title="Kết thúc cuộc trò chuyện an toàn"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Kết thúc trò chuyện</span>
            </button>

            {/* Close button */}
            <button
              id="positive-room-close-btn"
              type="button"
              onClick={() => {
                stopAllAudio();
                if (recognitionRef.current) recognitionRef.current.stop();
                onClose();
              }}
              className="p-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-white transition-colors"
              title="Đóng cửa sổ"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Center: Live Real-time Conversation Stream */}
        <div className="relative z-10 flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs sm:text-sm">
          {currentSession?.messages && currentSession.messages.length > 0 ? (
            currentSession.messages.map((m) => {
              const isStudent = m.sender === 'student';
              const isCounselor = m.sender === 'counselor' || m.isCounselorIntervention;

              return (
                <div
                  key={m.id}
                  className={`flex flex-col ${
                    isStudent ? 'items-end' : 'items-start'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1 px-1 text-[11px] text-stone-400">
                    <span className="font-semibold text-stone-300">{m.senderName}</span>
                    <span>• {m.timestamp}</span>
                    {isCounselor && (
                      <span className="px-1.5 py-0.5 rounded bg-purple-500/30 text-purple-300 text-[10px] font-bold">
                        Giáo viên tư vấn can thiệp
                      </span>
                    )}
                  </div>

                  <div
                    className={`p-4 rounded-2xl max-w-[88%] sm:max-w-[78%] leading-relaxed whitespace-pre-line shadow-sm relative ${
                      isStudent
                        ? 'bg-emerald-600 text-white rounded-tr-xs'
                        : isCounselor
                        ? 'bg-purple-900/80 text-purple-100 border border-purple-500/50 rounded-tl-xs'
                        : 'bg-stone-800/95 text-stone-100 border border-stone-700/70 rounded-tl-xs'
                    }`}
                  >
                    <p className="text-sm font-normal">{m.text}</p>

                    {/* AI audio replay button & empathetic badge */}
                    {!isStudent && (
                      <div className="mt-2.5 pt-2 border-t border-stone-700/50 flex flex-wrap items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => handleReplayMessage(m)}
                          className={`text-[11px] font-bold flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-colors ${
                            playingMessageId === m.id && isAiSpeaking
                              ? 'bg-emerald-500 text-stone-950 animate-pulse'
                              : 'bg-stone-700/80 hover:bg-stone-700 text-emerald-300 hover:text-emerald-200'
                          }`}
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>
                            {playingMessageId === m.id && isAiSpeaking
                              ? 'Đang phát âm thanh...'
                              : 'Nghe phát âm Tiếng Việt'}
                          </span>
                        </button>
                        <span className="text-[10px] text-emerald-400/90 flex items-center gap-1 font-medium">
                          <MessageCircleHeart className="w-3 h-3 text-emerald-400" /> Vovakier lắng nghe & sẻ chia
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center text-stone-400 space-y-3">
              <div className="w-16 h-16 rounded-full bg-emerald-950/60 border border-emerald-800/50 flex items-center justify-center text-emerald-400 shadow-inner">
                <Heart className="w-8 h-8 animate-pulse text-emerald-400" />
              </div>
              <h4 className="font-bold text-base text-stone-200">Chào mừng bạn đến với Phòng Tích Cực</h4>
              <p className="max-w-lg text-xs text-stone-400 leading-relaxed">
                Vovakier luôn lắng nghe chân thành, phân tích hoàn cảnh để <b>đưa ra lời khuyên thực tế, hữu ích</b>, chuẩn mực tư vấn sư phạm (tuyệt đối không nói bừa, nói bậy) và phản hồi bằng lời nói Tiếng Việt.
                <br /><br />
                Đặc biệt: Khi nghe bạn nói cụm từ <b>"Bỏ qua"</b> (hoặc bấm nút Bỏ qua), hệ thống sẽ <b>ngắt lời AI ngay lập tức</b> và chuyển hướng câu chuyện theo phản hồi mới của bạn!
              </p>
              <div className="pt-2 flex flex-wrap justify-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSkipTopic('Bỏ qua chuyện vừa rồi, mình muốn bạn lắng nghe và cho mình lời khuyên thực tế về cách quản lý thời gian học tập.')}
                  className="px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <CornerUpRight className="w-3.5 h-3.5" />
                  <span>Lời khuyên quản lý thời gian</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleSkipTopic('Bỏ qua chuyện đó đi, mình muốn hỏi cách giải tỏa căng thẳng trước kỳ thi.')}
                  className="px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <CornerUpRight className="w-3.5 h-3.5" />
                  <span>Cách giảm căng thẳng thi cử</span>
                </button>
              </div>
            </div>
          )}

          {/* Real-time interim speech transcript display */}
          {speechTranscript && (
            <div className="flex flex-col items-end animate-fade-in">
              <span className="text-[10px] text-emerald-400 mb-1 px-1 flex items-center gap-1">
                <Mic className="w-3 h-3 animate-pulse text-red-400" /> Đang lắng nghe giọng nói của bạn...
              </span>
              <div className="p-3.5 rounded-2xl bg-emerald-700/70 text-white border border-emerald-500/50 italic text-sm">
                "{speechTranscript}..."
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Bottom Interactive Control Center */}
        <div className="relative z-10 p-4 sm:p-5 bg-stone-950/95 border-t border-stone-800 space-y-3">
          {/* Audio Visualizer Waves, Status & Barge-in Quick Actions */}
          <div className="flex flex-wrap items-center justify-between gap-2 min-h-8 px-1">
            <div className="flex items-center gap-2">
              {isAiSpeaking ? (
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    {[...Array(10)].map((_, i) => (
                      <span
                        key={i}
                        className="w-1 rounded-full bg-emerald-400"
                        style={{
                          height: `${8 + ((i * 4) % 16)}px`,
                          animation: 'pulse 0.9s infinite alternate',
                          animationDelay: `${i * 0.08}s`,
                        }}
                      />
                    ))}
                  </div>
                  <span className="text-xs font-bold text-amber-300">
                    Vovakier đang nói • Chống dội loa • Nói "Bỏ qua" để ngắt lời lập tức
                  </span>
                </div>
              ) : isListening ? (
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    {[...Array(10)].map((_, i) => (
                      <span
                        key={i}
                        className="w-1 rounded-full bg-emerald-400"
                        style={{
                          height: `${8 + ((i * 5) % 18)}px`,
                          animation: 'pulse 0.7s infinite alternate',
                          animationDelay: `${i * 0.06}s`,
                        }}
                      />
                    ))}
                  </div>
                  <span className="text-xs font-bold text-emerald-400">
                    AI luôn lắng nghe • Chống dội loa • Tự phát hiện "Bỏ qua"
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-xs text-stone-400">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{voiceStatusText}</span>
                </div>
              )}
            </div>

            {/* Quick Barge-In / Interrupt & Skip Topic Actions */}
            <div className="flex items-center gap-2">
              {isAiSpeaking ? (
                <>
                  <button
                    id="positive-room-skip-voice-btn"
                    type="button"
                    onClick={() => handleSkipTopic()}
                    className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-extrabold text-xs flex items-center gap-1.5 transition-all shadow-md active:scale-95 animate-pulse"
                    title="Khẩu lệnh 'Bỏ qua': Ngắt lời AI ngay lập tức và chuyển hướng câu chuyện"
                  >
                    <FastForward className="w-4 h-4 fill-stone-950" />
                    <span>Nói "Bỏ qua" • Đổi chủ đề</span>
                  </button>

                  <button
                    id="positive-room-stop-audio-btn"
                    type="button"
                    onClick={() => stopAllAudio(false)}
                    className="px-2.5 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white text-xs font-semibold flex items-center gap-1 transition-colors border border-stone-700 shadow-sm shrink-0"
                    title="Dừng phát âm thanh"
                  >
                    <Square className="w-3 h-3 fill-current text-red-400" />
                    <span>Dừng</span>
                  </button>
                </>
              ) : (
                <button
                  id="positive-room-quick-skip-btn"
                  type="button"
                  onClick={() => handleSkipTopic()}
                  className="px-3 py-1.5 rounded-xl bg-stone-800/90 hover:bg-stone-800 text-amber-300 hover:text-amber-200 border border-amber-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                  title="Bấm hoặc nói 'Bỏ qua' để chuyển sang chủ đề khác"
                >
                  <CornerUpRight className="w-3.5 h-3.5" />
                  <span>Bỏ qua & Đổi chủ đề</span>
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Big Mic Button - Clicking while AI speaks immediately interrupts AI and starts listening */}
            <button
              id="positive-room-mic-btn"
              type="button"
              onClick={toggleListening}
              className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 transition-all shadow-lg active:scale-95 ${
                isAiSpeaking
                  ? 'bg-amber-500 hover:bg-amber-400 text-stone-950 ring-4 ring-amber-400/40 animate-pulse'
                  : isListening
                  ? 'bg-red-600 hover:bg-red-700 text-white ring-4 ring-red-500/40 animate-pulse'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white ring-4 ring-emerald-500/20'
              }`}
              title={
                isAiSpeaking
                  ? 'Nhấn để ngắt lời AI và mở micro nói ngay'
                  : isListening
                  ? 'Tắt micro'
                  : 'Bật micro để trò chuyện cùng Vovakier'
              }
            >
              {isAiSpeaking ? (
                <Hand className="w-6 h-6 fill-current" />
              ) : isListening ? (
                <MicOff className="w-6 h-6" />
              ) : (
                <Mic className="w-6 h-6" />
              )}
            </button>

            {/* Text Input Form - Typing interrupts AI immediately */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendUserMessage(textInput);
              }}
              className="flex-1 flex gap-2"
            >
              <input
                id="positive-room-text-input"
                type="text"
                value={textInput}
                onFocus={() => {
                  if (isAiSpeakingRef.current) {
                    stopAllAudio(true);
                  }
                }}
                onChange={(e) => {
                  if (isAiSpeakingRef.current) {
                    stopAllAudio(true);
                  }
                  setTextInput(e.target.value);
                }}
                placeholder="Gõ tâm sự với Vovakier tại đây (Vovakier luôn thấu cảm và sẻ chia)..."
                className="flex-1 px-4 py-3 rounded-2xl bg-stone-900 border border-stone-700 text-sm text-white placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />

              <button
                id="positive-room-send-btn"
                type="submit"
                disabled={!textInput.trim()}
                className="px-5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm active:scale-95"
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">Gửi</span>
              </button>
            </form>
          </div>

          <div className="flex flex-wrap items-center justify-between text-[11px] text-stone-400 px-1 pt-1 gap-2">
            <span className="flex items-center gap-1.5 text-stone-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Khẩu lệnh ngắt lời: Nói <b>"Bỏ qua"</b> (hoặc phím Space) để ngắt lời AI tức thì và chuyển hướng câu chuyện
            </span>
            <span className="flex items-center gap-1 text-emerald-400 font-semibold">
              <Shield className="w-3.5 h-3.5" /> Lời khuyên thực tế • Lắng nghe phân tích • Phản hồi bằng lời nói
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
