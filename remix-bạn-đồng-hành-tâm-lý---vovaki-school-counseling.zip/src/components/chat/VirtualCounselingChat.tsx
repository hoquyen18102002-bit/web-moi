import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import {
  MessageSquare,
  Send,
  X,
  Shield,
  Clock,
  Download,
  CheckCircle,
  AlertTriangle,
  User,
  Brain,
  Sparkles,
  RefreshCw,
  CheckCircle2,
  LogOut,
} from 'lucide-react';

interface Props {
  type: 'booking' | 'emergency';
  targetId: string;
  onClose: () => void;
}

export const VirtualCounselingChat: React.FC<Props> = ({ type, targetId, onClose }) => {
  const {
    state,
    currentUser,
    sendBookingMessage,
    sendEmergencyMessage,
    analyzeSessionSentiment,
  } = useApp();

  const [inputMessage, setInputMessage] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showSentimentDetail, setShowSentimentDetail] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Retrieve matching booking or emergency session
  const booking = type === 'booking' ? state.bookings.find((b) => b.id === targetId) : null;
  const emergency = type === 'emergency' ? state.emergencySessions.find((s) => s.id === targetId) : null;

  const messages = booking?.messages || emergency?.messages || [];
  const anonymousCode = booking?.studentAnonymousCode || emergency?.studentAnonymousCode || 'HS-ANON';
  const nickname = booking?.nickname || emergency?.studentNickname || 'Học sinh ẩn danh';
  const topic = booking?.topic || 'Tư vấn Khẩn cấp Trực tuyến';

  // Sentiment data
  const sentimentAnalysis =
    (type === 'booking' ? booking?.sentimentAnalysis : emergency?.sentimentAnalysis) ||
    state.sentimentAnalyses?.find((s) => s.targetId === targetId);

  const isCounselor = currentUser?.role === 'counselor' || currentUser?.role === 'admin';

  const handleRunSentimentAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      await analyzeSessionSentiment(
        targetId,
        type === 'booking' ? 'counselor_booking' : 'emergency_session',
        messages,
        anonymousCode,
        topic
      );
    } catch (err) {
      console.warn('Failed to analyze sentiment in chat:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const senderRole = isCounselor ? 'counselor' : 'student';
    const senderDisplayName = isCounselor
      ? currentUser?.fullName || 'ThS. Nguyễn Mai Phương (GV Tư vấn)'
      : nickname;

    if (type === 'booking' && booking) {
      await sendBookingMessage(
        booking.id,
        inputMessage.trim(),
        senderRole,
        senderDisplayName,
        anonymousCode
      );
    } else if (type === 'emergency' && emergency) {
      await sendEmergencyMessage(
        emergency.id,
        inputMessage.trim(),
        senderRole,
        senderDisplayName,
        anonymousCode
      );
    }

    setInputMessage('');
  };

  // Export chat transcript to text file (Requirement: Lưu trữ cơ sở dữ liệu dạng văn bản để lưu trữ, phân tích)
  const handleExportChatLog = () => {
    let transcript = `=== HỆ THỐNG TƯ VẤN HỌC ĐƯỜNG VOVAKI ===\n`;
    transcript += `LOẠI HÌNH: ${type === 'emergency' ? 'TƯ VẤN KHẨN CẤP' : 'BUỔI TƯ VẤN ẢO ĐẶT LỊCH'}\n`;
    transcript += `MÃ ẨN DANH HỌC SINH: ${anonymousCode}\n`;
    transcript += `BIỆT DANH: ${nickname}\n`;
    transcript += `CHỦ ĐỀ: ${topic}\n`;
    transcript += `THỜI GIAN XUẤT: ${new Date().toLocaleString('vi-VN')}\n`;
    transcript += `==========================================\n\n`;

    messages.forEach((m) => {
      transcript += `[${m.timestamp}] ${m.senderName}: ${m.text}\n`;
    });

    const blob = new Blob([transcript], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `vovaki_chat_${anonymousCode}_${Date.now()}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-6 animate-fade-in">
      <div className="bg-white rounded-2xl max-w-3xl w-full h-[88vh] shadow-2xl border border-stone-200 flex flex-col overflow-hidden">
        {/* Header */}
        <div
          className={`px-6 py-4 flex items-center justify-between text-white ${
            type === 'emergency' ? 'bg-red-800' : 'bg-stone-900'
          }`}
        >
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white shadow-xs ${
                type === 'emergency' ? 'bg-red-600' : 'bg-emerald-600'
              }`}
            >
              {type === 'emergency' ? <AlertTriangle className="w-5 h-5" /> : <MessageSquare className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base">
                  {type === 'emergency' ? 'Phòng Trò Chuyện Tư Vấn Khẩn Cấp' : 'Buổi Tham Vấn Ảo 1-1'}
                </h3>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-black/30 border border-white/20 font-bold">
                  {anonymousCode}
                </span>
              </div>
              <p className="text-xs text-stone-300">
                Đối tượng: <strong>{nickname}</strong> • Chủ đề: {topic}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportChatLog}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
              title="Trích xuất biên bản trò chuyện (Text file)"
            >
              <Download className="w-4 h-4" />
            </button>

            {/* Nút Kết thúc cuộc trò chuyện */}
            <button
              type="button"
              onClick={() => {
                if (window.confirm('Bạn có chắc muốn kết thúc cuộc trò chuyện này? Nội dung sẽ được lưu lại an toàn.')) {
                  onClose();
                }
              }}
              className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
              title="Kết thúc cuộc trò chuyện"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Kết thúc cuộc trò chuyện</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Confidentiality Notice Bar */}
        <div className="bg-stone-50 border-b border-stone-200 px-6 py-2 flex items-center justify-between text-xs text-stone-500">
          <span className="flex items-center gap-1.5 text-emerald-700 font-medium">
            <Shield className="w-3.5 h-3.5" />
            Mã hóa & Ẩn danh: Giáo viên không biết danh tính thật, chỉ thấy biệt danh và mã [{anonymousCode}].
          </span>
          <span className="text-[11px] text-stone-400">
            {messages.length} tin nhắn được lưu trữ
          </span>
        </div>

        {/* AI Sentiment Analysis Insights Banner */}
        <div className="px-6 py-2.5 bg-indigo-50/70 border-b border-indigo-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0">
              <Brain className="w-3.5 h-3.5" />
            </div>
            {sentimentAnalysis ? (
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-bold text-indigo-950">Chỉ số cảm xúc phiên:</span>
                <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                  sentimentAnalysis.sentiment === 'positive'
                    ? 'bg-emerald-100 text-emerald-800'
                    : sentimentAnalysis.sentiment === 'negative'
                    ? 'bg-rose-100 text-rose-800'
                    : 'bg-stone-200 text-stone-700'
                }`}>
                  {sentimentAnalysis.sentiment === 'positive' ? 'Tích cực' : sentimentAnalysis.sentiment === 'negative' ? 'Tiêu cực' : 'Trung tính'}
                </span>
                <span className="font-semibold text-indigo-900">
                  {sentimentAnalysis.emotionalState} ({sentimentAnalysis.sentimentScore}/100)
                </span>
                <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                  sentimentAnalysis.urgencyLevel === 'Báo động khẩn cấp'
                    ? 'bg-rose-600 text-white'
                    : sentimentAnalysis.urgencyLevel === 'Cần chú ý'
                    ? 'bg-amber-500 text-white'
                    : 'bg-emerald-600 text-white'
                }`}>
                  {sentimentAnalysis.urgencyLevel}
                </span>
              </div>
            ) : (
              <span className="text-stone-600">
                {isCounselor
                  ? 'Chưa chạy phân tích cảm xúc AI cho phiên trò chuyện này.'
                  : 'Không gian lắng nghe đồng cảm & an toàn tuyệt đối.'}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {sentimentAnalysis && (
              <button
                type="button"
                onClick={() => setShowSentimentDetail(true)}
                className="text-[11px] text-indigo-700 hover:underline font-bold"
              >
                Chi tiết đánh giá →
              </button>
            )}
            {isCounselor && (
              <button
                type="button"
                disabled={isAnalyzing}
                onClick={handleRunSentimentAnalysis}
                className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[11px] flex items-center gap-1.5 shadow-xs transition-colors"
              >
                {isAnalyzing ? (
                  <>
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    <span>Đang phân tích...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3 h-3" />
                    <span>{sentimentAnalysis ? 'Phân tích lại' : '⚡ Phân tích cảm xúc AI'}</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs sm:text-sm bg-stone-50/50">
          {messages.map((m) => {
            const isMe =
              (isCounselor && m.sender === 'counselor') ||
              (!isCounselor && m.sender === 'student');

            const isSystem = m.sender === 'system';

            if (isSystem) {
              return (
                <div key={m.id} className="text-center my-2">
                  <span className="inline-block px-3 py-1 rounded-full text-[11px] bg-stone-200 text-stone-700">
                    {m.text}
                  </span>
                </div>
              );
            }

            return (
              <div
                key={m.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div className="flex items-center gap-1.5 mb-1 text-[11px] text-stone-500 px-1">
                  <span className="font-bold text-stone-700">{m.senderName}</span>
                  <span>• {m.timestamp}</span>
                </div>
                <div
                  className={`p-3.5 rounded-2xl max-w-[80%] leading-relaxed shadow-xs ${
                    isMe
                      ? 'bg-emerald-600 text-white rounded-br-xs'
                      : m.sender === 'counselor'
                      ? 'bg-purple-900 text-purple-100 rounded-bl-xs'
                      : 'bg-white text-stone-900 border border-stone-200 rounded-bl-xs'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <form
          onSubmit={handleSend}
          className="p-4 bg-white border-t border-stone-200 flex items-center gap-3"
        >
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder={
              isCounselor
                ? `Nhập lời chia sẻ, lắng nghe tới học sinh [${anonymousCode}]...`
                : 'Nhập tâm sự của em để gửi tới Thầy/Cô tư vấn...'
            }
            className="flex-1 px-4 py-2.5 rounded-xl border border-stone-300 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
          <button
            type="submit"
            disabled={!inputMessage.trim()}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white font-bold text-xs flex items-center gap-2 shadow-xs transition-colors"
          >
            <Send className="w-4 h-4" />
            <span>Gửi</span>
          </button>
        </form>

        {/* Sentiment Analysis Modal within Chat */}
        {showSentimentDetail && sentimentAnalysis && (
          <div className="absolute inset-0 z-30 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-lg w-full p-5 shadow-2xl border border-stone-200 space-y-4 max-h-[85vh] overflow-y-auto">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-indigo-600" />
                  <h4 className="font-bold text-sm text-stone-900">
                    Phân Tích Cảm Xúc Phiên [{anonymousCode}]
                  </h4>
                </div>
                <button
                  type="button"
                  onClick={() => setShowSentimentDetail(false)}
                  className="w-7 h-7 rounded-full bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-xs font-bold text-stone-500"
                >
                  ✕
                </button>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2.5 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] text-stone-400 block font-bold uppercase">Xu hướng</span>
                  <span className="font-bold text-stone-800 capitalize">{sentimentAnalysis.sentiment}</span>
                </div>
                <div className="p-2.5 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] text-stone-400 block font-bold uppercase">Điểm số</span>
                  <span className="font-bold text-stone-900">{sentimentAnalysis.sentimentScore}/100</span>
                </div>
                <div className="p-2.5 bg-stone-50 rounded-xl border border-stone-200">
                  <span className="text-[10px] text-stone-400 block font-bold uppercase">Mức khẩn cấp</span>
                  <span className="font-bold text-stone-800">{sentimentAnalysis.urgencyLevel}</span>
                </div>
              </div>

              <div className="p-3 bg-indigo-50/60 rounded-xl text-xs space-y-1">
                <span className="font-bold text-indigo-950 block">Trạng thái: {sentimentAnalysis.emotionalState}</span>
                <p className="text-stone-700 leading-relaxed">{sentimentAnalysis.summary}</p>
              </div>

              {sentimentAnalysis.distressSignals && sentimentAnalysis.distressSignals.length > 0 && (
                <div className="space-y-1.5 text-xs">
                  <span className="font-bold text-rose-800 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" /> Dấu hiệu căng thẳng / áp lực:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {sentimentAnalysis.distressSignals.map((d, i) => (
                      <span key={i} className="px-2 py-0.5 rounded bg-rose-50 border border-rose-200 text-rose-800 font-medium">
                        {d}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="p-3 bg-emerald-50 rounded-xl text-xs space-y-1.5">
                <span className="font-bold text-emerald-950 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-700" /> Khuyến nghị tương tác:
                </span>
                <ul className="space-y-1 text-emerald-900">
                  {sentimentAnalysis.recommendations.map((r, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600 mt-0.5 shrink-0" />
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-1 flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowSentimentDetail(false)}
                  className="px-4 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold"
                >
                  Đóng
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
