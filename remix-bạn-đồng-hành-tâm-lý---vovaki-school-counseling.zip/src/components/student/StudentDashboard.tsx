import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Calendar,
  AlertTriangle,
  Sparkles,
  ClipboardList,
  MessageSquare,
  Mic,
  Clock,
  CheckCircle,
  ArrowRight,
  Shield,
  Heart,
  Plus,
  Brain,
} from 'lucide-react';
import { CounselingBooking } from '../../types';

export const StudentDashboard: React.FC<{
  onOpenPositiveRoom: () => void;
  onOpenTestTaker: (testId: string) => void;
  onOpenVirtualChat: (bookingId: string) => void;
  onOpenEmergencyChat: (sessionId: string) => void;
}> = ({ onOpenPositiveRoom, onOpenTestTaker, onOpenVirtualChat, onOpenEmergencyChat }) => {
  const { state, currentUser, addBooking, createEmergencySession } = useApp();

  const [activeTab, setActiveTab] = useState<'booking' | 'tests' | 'positive_room_portal'>('booking');

  // Booking form state
  const [bookingDate, setBookingDate] = useState('2026-09-15');
  const [bookingTime, setBookingTime] = useState('14:30 - 15:15');
  const [nickname, setNickname] = useState('Sao Băng Nhỏ');
  const [useAutoCode, setUseAutoCode] = useState(true);
  const [bookingTopic, setBookingTopic] = useState('Áp lực học tập và căng thẳng trước kỳ thi học kỳ');
  const [bookingType, setBookingType] = useState<'counselor' | 'positive_room'>('counselor');
  const [bookingSuccessMsg, setBookingSuccessMsg] = useState('');

  // Handle student submit booking
  const handleSubmitBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    const randomCode = `HS-ANON-${Math.floor(1000 + Math.random() * 9000)}`;
    const newB: CounselingBooking = {
      id: `bk-${Date.now()}`,
      studentId: currentUser?.id || `std-${Date.now()}`,
      studentAnonymousCode: randomCode,
      nickname: nickname.trim() || `Học sinh ${randomCode}`,
      date: bookingDate,
      timeSlot: bookingTime,
      type: bookingType,
      topic: bookingTopic,
      status: 'pending',
      createdAt: new Date().toISOString().split('T')[0],
      messages: [
        {
          id: `msg-init-${Date.now()}`,
          sender: 'system',
          senderName: 'Hệ thống VoVaKi',
          text: `Phiên tư vấn ẩn danh được tạo với mã số [${randomCode}]. Biệt danh: "${nickname}". Nội dung trao đổi được mã hóa và bảo mật hoàn toàn.`,
          timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        },
      ],
    };

    await addBooking(newB);
    setBookingSuccessMsg(`Đã đặt lịch hẹn thành công! Mã số ẩn danh của bạn là: ${randomCode}`);
    setTimeout(() => setBookingSuccessMsg(''), 6000);
  };

  // Handle emergency counseling launch
  const handleLaunchEmergency = async () => {
    const session = await createEmergencySession(nickname || 'Học sinh');
    onOpenEmergencyChat(session.id);
  };

  // Find tests and my submissions
  const activeTest = state.psychologicalTests[0];
  const mySubmissions = state.testSubmissions.filter(
    (s) => s.studentId === currentUser?.id || s.studentName === currentUser?.fullName
  );

  // Student's personal bookings
  const myBookings = state.bookings.filter(
    (b) => b.studentId === currentUser?.id || b.studentAnonymousCode === currentUser?.studentCode
  );

  return (
    <div className="space-y-6">
      {/* Top Banner with Emergency Action */}
      <div className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white rounded-2xl p-6 shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-white/20 text-emerald-200">
              Giao diện Học sinh
            </span>
            <span className="text-xs text-emerald-200 font-medium">
              Chào em, {currentUser?.fullName || 'Học sinh'} ({currentUser?.classId || '10A1'})
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight">
            Phòng Hỗ trợ Tâm lý & Đồng hành Tuổi học trò
          </h2>
          <p className="text-xs text-emerald-100 max-w-xl">
            Tất cả chia sẻ của em tại đây được bảo mật 100% bằng mã số ẩn danh riêng biệt. Thầy/Cô luôn ở đây lắng nghe em.
          </p>
        </div>

        {/* Emergency Counseling Button (Requirement 2) */}
        <button
          type="button"
          onClick={handleLaunchEmergency}
          className="px-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-lg flex items-center gap-2 transition-transform active:scale-95 animate-pulse"
        >
          <AlertTriangle className="w-4 h-4" />
          <span>Trao đổi khẩn cấp với Giáo viên tư vấn</span>
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-stone-200 pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('booking')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'booking'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Đặt lịch tư vấn ẩn danh ({myBookings.length} lịch)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('positive_room_portal')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'positive_room_portal'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Phòng tích cực - Vovakier (Trò chuyện giọng nói)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('tests')}
          className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all ${
            activeTab === 'tests'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white hover:bg-stone-100 text-stone-700 border border-stone-200'
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          <span>Thực hiện bài test tâm lý định kỳ</span>
        </button>
      </div>

      {/* TAB 1: BOOKING COUNSELING (Requirement 1) */}
      {activeTab === 'booking' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Booking Form */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-stone-200 p-6 shadow-xs space-y-4">
            <div>
              <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-emerald-600" />
                Đặt Lịch Tư vấn Tâm lý Ẩn danh
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                Em có thể chọn tự đặt biệt danh hoặc để hệ thống cấp mã số ẩn danh riêng biệt
              </p>
            </div>

            {bookingSuccessMsg && (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-semibold flex items-start gap-2 animate-fade-in">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <p>{bookingSuccessMsg}</p>
                  <p className="text-[11px] text-emerald-700 font-normal mt-1">
                    Lịch hẹn đã được chuyển đến Bàn làm việc của ThS. Nguyễn Mai Phương. Em có thể bấm "Vào phòng tư vấn ảo" bên dưới vào đúng khung giờ.
                  </p>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmitBooking} className="space-y-4 text-xs">
              {/* Type Selection */}
              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Chọn loại hình tư vấn:
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <div
                    onClick={() => setBookingType('counselor')}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      bookingType === 'counselor'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold'
                        : 'border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    <div className="text-sm">Tư vấn 1-1 với Giáo viên tâm lý</div>
                    <div className="text-[11px] text-stone-500 font-normal mt-0.5">
                      Trò chuyện trực tuyến ẩn danh cùng ThS. Nguyễn Mai Phương
                    </div>
                  </div>

                  <div
                    onClick={() => setBookingType('positive_room')}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      bookingType === 'positive_room'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold'
                        : 'border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    <div className="text-sm">Đặt lịch Phòng tích cực</div>
                    <div className="text-[11px] text-stone-500 font-normal mt-0.5">
                      Khung giờ riêng rèn luyện cảm xúc & thả lỏng cùng AI Vovakier
                    </div>
                  </div>
                </div>
              </div>

              {/* Nickname & Anonymous Identity */}
              <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                <label className="block font-bold text-stone-800">
                  Danh xưng của em trong buổi tư vấn:
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="text"
                    required
                    value={nickname}
                    onChange={(e) => setNickname(e.target.value)}
                    placeholder="Biệt danh tự chọn (Ví dụ: Sao Băng Nhỏ, Hạt Cát Biển...)"
                    className="flex-1 px-3 py-2 rounded-lg border border-stone-300 text-xs bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => setNickname(`Học sinh HS-ANON-${Math.floor(1000 + Math.random() * 9000)}`)}
                    className="px-3 py-2 rounded-lg bg-stone-200 hover:bg-stone-300 text-stone-800 text-[11px] font-semibold shrink-0"
                  >
                    Hệ thống tự cấp mã số
                  </button>
                </div>
                <p className="text-[11px] text-stone-500 italic">
                  * Giáo viên tư vấn chỉ nhìn thấy biệt danh này và mã số ẩn danh, không thấy họ tên thật hay tài khoản của em.
                </p>
              </div>

              {/* Date & Slot */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Ngày hẹn:</label>
                  <input
                    type="date"
                    required
                    value={bookingDate}
                    onChange={(e) => setBookingDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Khung giờ phù hợp:</label>
                  <select
                    value={bookingTime}
                    onChange={(e) => setBookingTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs bg-white"
                  >
                    <option value="09:00 - 09:45">09:00 - 09:45 (Buổi sáng)</option>
                    <option value="11:30 - 12:15">11:30 - 12:15 (Giờ nghỉ trưa)</option>
                    <option value="14:30 - 15:15">14:30 - 15:15 (Buổi chiều)</option>
                    <option value="16:45 - 17:30">16:45 - 17:30 (Sau giờ tan trường)</option>
                    <option value="19:30 - 20:15">19:30 - 20:15 (Buổi tối tại nhà)</option>
                  </select>
                </div>
              </div>

              {/* Topic */}
              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Vấn đề hoặc tâm sự em muốn chia sẻ:
                </label>
                <textarea
                  rows={3}
                  required
                  value={bookingTopic}
                  onChange={(e) => setBookingTopic(e.target.value)}
                  placeholder="Ví dụ: Em cảm thấy áp lực vì kỳ thi sắp tới, khó hòa nhập với các bạn trong lớp, hoặc chuyện gia đình..."
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition-transform active:scale-95 flex items-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  Xác nhận đặt lịch tư vấn
                </button>
              </div>
            </form>
          </div>

          {/* Right Column: Existing bookings & History */}
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-3">
              <h4 className="font-bold text-sm text-stone-900 flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-600" />
                Lịch hẹn Đã đăng ký của Em
              </h4>

              {myBookings.length === 0 ? (
                <div className="p-6 text-center text-stone-400 text-xs">
                  Em chưa có lịch hẹn nào. Hãy đăng ký một khung giờ bên cạnh khi cần người lắng nghe nhé!
                </div>
              ) : (
                <div className="space-y-3">
                  {myBookings.map((b) => (
                    <div
                      key={b.id}
                      className="p-3.5 rounded-xl border border-stone-200 bg-stone-50/70 space-y-2 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-stone-900">
                          {b.studentAnonymousCode}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-800">
                          {b.status === 'confirmed' ? 'Đã duyệt' : 'Chờ vào phòng'}
                        </span>
                      </div>

                      <div className="text-stone-600 font-medium">
                        Biệt danh: <strong>{b.nickname}</strong>
                      </div>

                      <div className="text-stone-500 flex items-center gap-2">
                        <Calendar className="w-3 h-3 text-emerald-600" />
                        <span>{b.date} • {b.timeSlot}</span>
                      </div>

                      <p className="text-[11px] text-stone-600 line-clamp-2">
                        {b.topic}
                      </p>

                      {/* AI Supportive Insight if analyzed */}
                      {(() => {
                        const analysis = b.sentimentAnalysis || state.sentimentAnalyses?.find(s => s.targetId === b.id);
                        if (analysis) {
                          return (
                            <div className="p-2.5 rounded-xl bg-teal-50 border border-teal-200 text-teal-950 space-y-1">
                              <div className="flex items-center gap-1.5 text-[11px] font-bold text-teal-800">
                                <Brain className="w-3.5 h-3.5 text-teal-600" />
                                <span>Góc nhìn cảm xúc: {analysis.emotionalState}</span>
                              </div>
                              <p className="text-[11px] text-stone-600 leading-snug">
                                {analysis.recommendations?.[0] || analysis.summary}
                              </p>
                            </div>
                          );
                        }
                        return null;
                      })()}

                      <div className="pt-2 border-t border-stone-200 flex justify-end">
                        <button
                          type="button"
                          onClick={() => onOpenVirtualChat(b.id)}
                          className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] flex items-center gap-1 shadow-xs"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          Vào phòng tư vấn ảo
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Quick emergency box */}
            <div className="bg-red-50 border border-red-200 rounded-2xl p-4 text-xs text-red-900 space-y-2">
              <div className="font-bold flex items-center gap-1.5 text-red-700">
                <AlertTriangle className="w-4 h-4" />
                Cần trao đổi khẩn cấp ngay bây giờ?
              </div>
              <p className="text-[11px] text-red-800 leading-relaxed">
                Nếu em đang trải qua khủng hoảng tâm lý nghiêm trọng hoặc cảm thấy cô độc, đừng ngần ngại bấm nút bên dưới để mở hộp thoại trực tiếp với giáo viên trực.
              </p>
              <button
                type="button"
                onClick={handleLaunchEmergency}
                className="w-full py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs text-center shadow-xs"
              >
                Mở phòng chat khẩn cấp ngay
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: POSITIVE ROOM PORTAL (Requirement 5) */}
      {activeTab === 'positive_room_portal' && (
        <div className="bg-white rounded-3xl border border-stone-200 p-8 shadow-xs space-y-6 max-w-3xl mx-auto text-center">
          <div className="w-20 h-20 rounded-full bg-emerald-500/10 border-2 border-emerald-500/30 flex items-center justify-center mx-auto text-emerald-600">
            <Mic className="w-10 h-10 animate-pulse" />
          </div>

          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-emerald-100 text-emerald-800">
              Trí tuệ Nhân tạo Lắng nghe Học đường
            </span>
            <h3 className="text-2xl font-bold text-stone-900">
              Phòng Tích cực - Người bạn Vovakier
            </h3>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed max-w-xl mx-auto">
              Vovakier là người bạn AI biết lắng nghe và phản hồi bằng giọng nói tiếng Việt theo thời gian thực.
              Em có thể trò chuyện tự do, chia sẻ mọi áp lực học tập hoặc thực hiện bài tập thở giải tỏa căng thẳng.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-left text-xs text-stone-700 max-w-xl mx-auto">
            <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200 space-y-1">
              <span className="font-bold text-emerald-700 block">🎙️ Giọng nói Tiếng Việt</span>
              <p className="text-stone-500 text-[11px]">Sử dụng microphone để đối thoại trực tiếp tự nhiên như người thật.</p>
            </div>
            <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200 space-y-1">
              <span className="font-bold text-emerald-700 block">🛑 Cho phép ngắt lời</span>
              <p className="text-stone-500 text-[11px]">Khi Vovakier đang nói, em cất tiếng thì AI lập tức dừng lại để lắng nghe em.</p>
            </div>
            <div className="p-3.5 rounded-xl bg-stone-50 border border-stone-200 space-y-1">
              <span className="font-bold text-emerald-700 block">🔒 Bảo mật & Lưu trữ</span>
              <p className="text-stone-500 text-[11px]">Nội dung được lưu trữ văn bản an toàn để hỗ trợ phân tích sức khỏe tinh thần.</p>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="button"
              onClick={onOpenPositiveRoom}
              className="px-8 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg hover:shadow-xl transition-all active:scale-95 inline-flex items-center gap-2"
            >
              <Sparkles className="w-5 h-5" />
              <span>Bước vào "Phòng tích cực" ngay</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: PSYCHOLOGICAL TESTS (Requirement 4) */}
      {activeTab === 'tests' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
            <div>
              <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-emerald-600" />
                Thực hiện Bài test Sức khỏe Tâm lý Định kỳ theo Tháng
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                Bài test do Giáo viên Tư vấn Tâm lý thiết kế. Sau khi hoàn thành sẽ có kết quả điểm số, đánh giá kèm lời khuyên và tự động lưu vào Hồ sơ sức khỏe của em.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {state.psychologicalTests.map((test) => {
                const isCompleted = mySubmissions.some((s) => s.testId === test.id);
                return (
                  <div
                    key={test.id}
                    className="p-5 rounded-2xl border border-stone-200 bg-white hover:border-emerald-300 transition-all flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                          Tháng {test.month}
                        </span>
                        {isCompleted && (
                          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 flex items-center gap-1">
                            <CheckCircle className="w-3 h-3 text-emerald-600" /> Đã hoàn thành
                          </span>
                        )}
                      </div>

                      <h4 className="font-bold text-base text-stone-900">{test.title}</h4>
                      <p className="text-xs text-stone-600 leading-relaxed">{test.description}</p>
                      <div className="text-[11px] text-stone-400">
                        Số câu hỏi: {test.questions.length} câu trắc nghiệm • Người tạo: {test.createdBy}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onOpenTestTaker(test.id)}
                      className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <span>{isCompleted ? 'Làm lại / Xem kết quả' : 'Bắt đầu làm bài test'}</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Previous Submissions History */}
          {mySubmissions.length > 0 && (
            <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-xs space-y-3">
              <h4 className="font-bold text-sm text-stone-900">
                Lịch sử Kết quả Đánh giá Tâm lý của Em
              </h4>

              <div className="space-y-3">
                {mySubmissions.map((sub) => (
                  <div
                    key={sub.id}
                    className="p-4 rounded-xl border border-stone-200 bg-stone-50 space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-stone-900">{sub.testTitle}</span>
                      <span className="text-stone-400 font-mono text-[11px]">{sub.submittedAt}</span>
                    </div>

                    <div className="flex items-center gap-4">
                      <span className="font-semibold">
                        Điểm số: <strong className="text-emerald-700 text-sm">{sub.totalScore} điểm</strong>
                      </span>
                      <span>
                        Xếp loại:{' '}
                        <span
                          className={`font-bold px-2 py-0.5 rounded ${
                            sub.evaluation === 'Bình thường'
                              ? 'bg-emerald-100 text-emerald-800'
                              : sub.evaluation === 'Cần lưu ý'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {sub.evaluation}
                        </span>
                      </span>
                    </div>

                    <p className="text-stone-600 bg-white p-2.5 rounded-lg border border-stone-200">
                      <strong>Lời khuyên dành cho em:</strong> {sub.advice}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
