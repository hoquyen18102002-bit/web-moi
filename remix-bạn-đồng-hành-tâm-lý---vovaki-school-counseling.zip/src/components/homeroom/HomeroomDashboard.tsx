import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  GraduationCap,
  Lock,
  Unlock,
  FolderHeart,
  Save,
  Check,
  Calendar,
  AlertCircle,
  Clock,
  UserCheck
} from 'lucide-react';

export const HomeroomDashboard: React.FC = () => {
  const { state, currentUser, updateSharedState } = useApp();

  // Selected teacher's class or default to their assigned class
  const defaultClass = currentUser?.classId || '10A1';
  const [selectedClass, setSelectedClass] = useState<string>(defaultClass);
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-09');
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');

  // Check if this class is unlocked by the Counselor
  const classAccess = state.classAccess.find((ca) => ca.classId === selectedClass);
  const isUnlocked = classAccess?.isUnlockedForHomeroom || false;

  // Filter students belonging to this class
  const classStudents = state.studentRecords.filter((r) => r.classId === selectedClass);

  // Local state for edits
  const [homeroomNotesMap, setHomeroomNotesMap] = useState<Record<string, string>>(() => {
    const initialMap: Record<string, string> = {};
    state.studentRecords.forEach((r) => {
      initialMap[r.id] = r.homeroomNotes || '';
    });
    return initialMap;
  });

  const handleSaveNotes = (recordId: string) => {
    const notes = homeroomNotesMap[recordId] || '';
    const updated = state.studentRecords.map((r) =>
      r.id === recordId ? { ...r, homeroomNotes: notes } : r
    );
    updateSharedState({ studentRecords: updated });
    setSaveSuccessMsg('Đã lưu nhận xét học sinh thành công!');
    setTimeout(() => setSaveSuccessMsg(''), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800">
              Giáo viên Chủ nhiệm
            </span>
            <span className="text-xs text-stone-500">{currentUser?.fullName || 'Thầy Trần Quốc Bảo'}</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-stone-900 mt-1">
            Theo dõi Sức khỏe Tâm lý Lớp Chủ nhiệm
          </h2>
          <p className="text-xs text-stone-600 mt-0.5">
            Xem hồ sơ sức khỏe tâm lý định kỳ theo tháng/năm khi được GV Tư vấn mở khóa và cập nhật quan sát hành vi học sinh
          </p>
        </div>

        {saveSuccessMsg && (
          <div className="px-3.5 py-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600" />
            {saveSuccessMsg}
          </div>
        )}
      </div>

      {/* Class & Month Selector */}
      <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <span className="font-bold text-stone-700">Lớp chủ nhiệm:</span>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="px-3 py-1.5 rounded-lg border border-stone-300 font-bold bg-white text-stone-900"
          >
            {state.classes.map((cls) => (
              <option key={cls} value={cls}>Lớp {cls}</option>
            ))}
          </select>

          <span className="text-stone-300">|</span>

          <span className="font-bold text-stone-700">Tháng theo dõi:</span>
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="px-3 py-1.5 rounded-lg border border-stone-300 bg-white text-stone-900"
          >
            <option value="2026-09">Tháng 09/2026 (Đầu năm học)</option>
            <option value="2026-10">Tháng 10/2026 (Giữa kỳ)</option>
            <option value="2026-11">Tháng 11/2026</option>
          </select>
        </div>

        {/* Lock / Unlock Status Indicator */}
        <div className="flex items-center gap-2">
          {isUnlocked ? (
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1.5 border border-emerald-200">
              <Unlock className="w-3.5 h-3.5 text-emerald-600" />
              Đã được GV Tư vấn Mở khóa xem & cập nhật
            </span>
          ) : (
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 flex items-center gap-1.5 border border-rose-200">
              <Lock className="w-3.5 h-3.5 text-rose-600" />
              Hồ sơ lớp hiện đang Khóa bởi GV Tư vấn
            </span>
          )}
        </div>
      </div>

      {/* Main Body: If Locked vs If Unlocked */}
      {!isUnlocked ? (
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center shadow-xs space-y-4 max-w-2xl mx-auto">
          <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto border border-rose-100">
            <Lock className="w-7 h-7" />
          </div>
          <h3 className="font-bold text-lg text-stone-900">
            Hồ sơ Sức khỏe Tâm lý Lớp {selectedClass} hiện đang được bảo mật
          </h3>
          <p className="text-xs text-stone-600 leading-relaxed max-w-lg mx-auto">
            Theo quy chế bảo mật thông tin sức khỏe tâm thần của nhà trường, Giáo viên Tư vấn Tâm lý học đường đang khóa quyền truy cập của lớp này để phục vụ đánh giá chuyên sâu.
          </p>
          <div className="p-3 bg-stone-50 rounded-xl text-xs text-stone-500 border border-stone-200 max-w-md mx-auto">
            Vui lòng liên hệ ThS. Nguyễn Mai Phương (Phòng Tư vấn Tâm lý) để được mở khóa tài liệu khi cần phối hợp hỗ trợ học sinh.
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-stone-200 bg-stone-50 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-stone-900 flex items-center gap-2">
                  <FolderHeart className="w-4 h-4 text-blue-600" />
                  Danh sách Hồ sơ Sức khỏe Tâm lý Học sinh Lớp {selectedClass}
                </h3>
                <p className="text-xs text-stone-500">
                  Thầy/Cô có quyền nhập nhận xét, quan sát hành vi trên lớp và ghi chú phối hợp trực tiếp vào hệ thống
                </p>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded bg-blue-50 text-blue-800 border border-blue-200">
                Sĩ số lớp theo dõi: {classStudents.length} học sinh
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-stone-700">
                <thead className="bg-stone-50 border-b border-stone-200 text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                  <tr>
                    <th className="px-4 py-3">Học sinh</th>
                    <th className="px-4 py-3">Mã số HS</th>
                    <th className="px-4 py-3">Điểm tâm lý</th>
                    <th className="px-4 py-3">Đánh giá chung</th>
                    <th className="px-4 py-3">Lưu ý từ GV Tư vấn</th>
                    <th className="px-4 py-3 min-w-[280px]">Nhận xét & Quan sát của GV Chủ nhiệm</th>
                    <th className="px-4 py-3 text-right">Lưu</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {classStudents.map((r) => (
                    <tr key={r.id} className="hover:bg-stone-50">
                      <td className="px-4 py-3 font-bold text-stone-900">
                        {r.studentName}
                      </td>
                      <td className="px-4 py-3 font-mono text-stone-500 text-[11px]">
                        {r.studentCode}
                      </td>
                      <td className="px-4 py-3 font-mono font-bold text-stone-900">
                        {r.latestScore}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2.5 py-1 rounded-full font-bold text-[11px] ${
                            r.status === 'Bình thường'
                              ? 'bg-emerald-100 text-emerald-800'
                              : r.status === 'Cần lưu ý'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {r.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-stone-600 max-w-xs text-[11px]">
                        {r.counselorNotes ? (
                          <div className="p-2 bg-emerald-50/60 rounded-lg border border-emerald-100 text-emerald-950">
                            {r.counselorNotes}
                          </div>
                        ) : (
                          <span className="text-stone-400 italic">Chưa có ghi chú đặc biệt</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <textarea
                          rows={2}
                          value={homeroomNotesMap[r.id] ?? r.homeroomNotes ?? ''}
                          onChange={(e) => {
                            const val = e.target.value;
                            setHomeroomNotesMap((prev) => ({ ...prev, [r.id]: val }));
                          }}
                          placeholder="Nhập quan sát biểu hiện trên lớp, tương tác với bạn bè..."
                          className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 text-xs focus:ring-1 focus:ring-blue-500 bg-white"
                        />
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          type="button"
                          onClick={() => handleSaveNotes(r.id)}
                          className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-[11px] shadow-xs flex items-center gap-1 ml-auto"
                        >
                          <Save className="w-3 h-3" />
                          Lưu
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
