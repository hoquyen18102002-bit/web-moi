import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ClipboardList,
  CheckCircle,
  X,
  AlertCircle,
  Award,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { TestSubmission } from '../../types';

interface Props {
  testId: string;
  onClose: () => void;
}

export const TestTakerModal: React.FC<Props> = ({ testId, onClose }) => {
  const { state, currentUser, submitTest } = useApp();

  const test = state.psychologicalTests.find((t) => t.id === testId) || state.psychologicalTests[0];

  // Selected answer map: questionId -> option index
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [resultSubmission, setResultSubmission] = useState<TestSubmission | null>(null);

  if (!test) return null;

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: optionIndex,
    }));
  };

  const isAllAnswered = test.questions.every((q) => selectedAnswers[q.id] !== undefined);

  const handleSubmit = async () => {
    if (!isAllAnswered) {
      alert('Vui lòng trả lời đầy đủ tất cả các câu hỏi trước khi hoàn thành bài khảo sát nhé!');
      return;
    }

    // Calculate score
    let total = 0;
    test.questions.forEach((q) => {
      const optIdx = selectedAnswers[q.id];
      if (optIdx !== undefined && q.options[optIdx]) {
        total += q.options[optIdx].score;
      }
    });

    // Evaluate tier
    let evalLabel: 'Bình thường' | 'Cần lưu ý' | 'Cần đặc biệt lưu ý' = 'Bình thường';
    let advice = 'Tâm lý của em đang rất ổn định. Hãy tiếp tục duy trì thói quen học tập khoa học và chia sẻ cùng bạn bè!';

    for (const tier of test.scoreTiers) {
      if (total >= tier.minScore && total <= tier.maxScore) {
        evalLabel = tier.label;
        advice = `${tier.description} ${tier.actionRecommendation}`;
        break;
      }
    }

    const submission: TestSubmission = {
      id: `sub-${Date.now()}`,
      testId: test.id,
      testTitle: test.title,
      month: test.month,
      studentId: currentUser?.id || `std-${Date.now()}`,
      studentName: currentUser?.fullName || 'Học sinh',
      studentCode: currentUser?.studentCode || 'VVK-10088',
      classId: currentUser?.classId || '10A1',
      grade: currentUser?.classId ? parseInt(currentUser.classId.substring(0, 2)) || 10 : 10,
      answers: selectedAnswers,
      totalScore: total,
      evaluation: evalLabel,
      advice,
      submittedAt: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
    };

    await submitTest(submission);
    setResultSubmission(submission);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fade-in">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] shadow-2xl border border-stone-200 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-emerald-900 text-white flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs px-2.5 py-0.5 rounded font-bold bg-emerald-700 text-emerald-100">
                Tháng {test.month}
              </span>
              <h3 className="font-bold text-base">{test.title}</h3>
            </div>
            <p className="text-xs text-emerald-200 mt-0.5">
              Học sinh: {currentUser?.fullName || 'Học sinh'} ({currentUser?.classId || '10A1'})
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-emerald-200 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {!resultSubmission ? (
            <div className="space-y-6">
              <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-900">
                <p className="font-bold">Hướng dẫn làm bài:</p>
                <p className="mt-1 leading-relaxed">
                  {test.description}. Em hãy chọn đáp án phản ánh đúng nhất cảm xúc và trạng thái của mình trong 2 tuần gần đây. Không có câu trả lời đúng hay sai.
                </p>
              </div>

              {/* Questions */}
              <div className="space-y-6">
                {test.questions.map((q, qIndex) => (
                  <div key={q.id} className="space-y-2.5 p-4 rounded-xl border border-stone-200 bg-stone-50/50">
                    <h4 className="font-bold text-xs sm:text-sm text-stone-900">
                      Câu {qIndex + 1}: {q.content}
                    </h4>

                    <div className="space-y-2 pt-1">
                      {q.options.map((opt, optIdx) => {
                        const isSelected = selectedAnswers[q.id] === optIdx;
                        return (
                          <div
                            key={optIdx}
                            onClick={() => handleSelectOption(q.id, optIdx)}
                            className={`p-3 rounded-xl border text-xs cursor-pointer transition-all flex items-center justify-between ${
                              isSelected
                                ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold shadow-xs'
                                : 'border-stone-200 bg-white hover:bg-stone-50 text-stone-700'
                            }`}
                          >
                            <span>{opt.text}</span>
                            <span className="text-[11px] font-mono text-stone-400">
                              ({opt.score} điểm)
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* Result Screen */
            <div className="space-y-6 text-center py-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                <Award className="w-8 h-8" />
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-stone-500">
                  Kết Quả Đánh Giá Tâm Lý
                </span>
                <h4 className="text-2xl font-bold text-stone-900">
                  Tổng điểm của em: <span className="text-emerald-600">{resultSubmission.totalScore}</span> điểm
                </h4>

                <div>
                  <span
                    className={`inline-block px-4 py-1 rounded-full font-bold text-sm ${
                      resultSubmission.evaluation === 'Bình thường'
                        ? 'bg-emerald-100 text-emerald-800'
                        : resultSubmission.evaluation === 'Cần lưu ý'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    Mức độ: {resultSubmission.evaluation}
                  </span>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200 text-left text-xs sm:text-sm text-stone-700 space-y-2 max-w-lg mx-auto">
                <span className="font-bold text-stone-900 block">Lời khuyên & Định hướng cá nhân:</span>
                <p className="leading-relaxed">{resultSubmission.advice}</p>
              </div>

              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 max-w-lg mx-auto flex items-center gap-2 text-left">
                <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>
                  Điểm số và đánh giá này đã được <strong>tự động lưu vào "Hồ sơ sức khỏe của học sinh"</strong> trên cơ sở dữ liệu chung của nhà trường.
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-stone-200 bg-stone-50 flex items-center justify-between">
          {!resultSubmission ? (
            <>
              <span className="text-xs text-stone-500">
                Đã trả lời {Object.keys(selectedAnswers).length}/{test.questions.length} câu
              </span>
              <button
                type="button"
                onClick={handleSubmit}
                disabled={!isAllAnswered}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white font-bold text-xs shadow-xs"
              >
                Nộp bài & Xem kết quả
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl bg-stone-900 hover:bg-black text-white font-bold text-xs ml-auto shadow-xs"
            >
              Hoàn tất
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
