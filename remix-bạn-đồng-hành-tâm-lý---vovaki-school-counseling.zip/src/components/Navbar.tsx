import React from 'react';
import { useApp } from '../context/AppContext';
import { HeartHandshake, PhoneCall, ShieldAlert, User, LogIn, LogOut, Sparkles, AlertTriangle, Bell, X, Radio } from 'lucide-react';

export const Navbar: React.FC<{ onOpenLogin: () => void }> = ({ onOpenLogin }) => {
  const { state, currentUser, setCurrentUser, setCurrentView, currentView, dismissBroadcastAlert } = useApp();
  const { siteSettings, realtimeSettings } = state;
  const broadcast = realtimeSettings?.broadcastAlert;

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('home');
  };

  const getRoleBadge = (role?: string) => {
    switch (role) {
      case 'admin':
        return <span className="text-xs px-2.5 py-0.5 rounded-full font-medium bg-purple-100 text-purple-800 border border-purple-200">Quản trị viên</span>;
      case 'counselor':
        return <span className="text-xs px-2.5 py-0.5 rounded-full font-medium bg-emerald-100 text-emerald-800 border border-emerald-200">GV Tư vấn Tâm lý</span>;
      case 'homeroom':
        return <span className="text-xs px-2.5 py-0.5 rounded-full font-medium bg-blue-100 text-blue-800 border border-blue-200">GV Chủ nhiệm</span>;
      case 'student':
        return <span className="text-xs px-2.5 py-0.5 rounded-full font-medium bg-amber-100 text-amber-800 border border-amber-200">Học sinh</span>;
      default:
        return null;
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200 shadow-xs">
      {/* Top informational announcement banner */}
      <div className="bg-stone-900 text-stone-200 px-4 py-1.5 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
              <PhoneCall className="w-3.5 h-3.5" />
              Hotline 24/7: {siteSettings.footerInfo.hotline}
            </span>
            <span className="hidden sm:inline text-stone-400">|</span>
            <span className="hidden sm:inline text-stone-300">
              Phòng tư vấn: {siteSettings.footerInfo.phone}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-stone-300 text-xs hidden md:inline">
              Môi trường lắng nghe bảo mật & ẩn danh cho học sinh
            </span>
            {currentUser && (
              <span className="text-xs bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800/60 font-mono">
                Đã đăng nhập: {currentUser.fullName}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Real-time School-wide Broadcast Alert Banner */}
      {broadcast && broadcast.active && (
        <div
          className={`px-4 py-2.5 text-xs text-white transition-all shadow-xs flex items-center justify-between gap-3 ${
            broadcast.level === 'emergency'
              ? 'bg-red-600 border-b border-red-700'
              : broadcast.level === 'warning'
              ? 'bg-amber-600 border-b border-amber-700'
              : 'bg-emerald-600 border-b border-emerald-700'
          }`}
        >
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-black/20 font-bold uppercase tracking-wider text-[10px] shrink-0">
                <Radio className="w-3 h-3 animate-pulse" />
                {broadcast.level === 'emergency'
                  ? 'Phát sóng Khẩn cấp'
                  : broadcast.level === 'warning'
                  ? 'Cảnh báo Trực tiếp'
                  : 'Thông báo Real-time'}
              </span>
              <p className="font-medium truncate text-xs sm:text-sm">
                {broadcast.message}
              </p>
              <span className="text-[10px] opacity-80 hidden md:inline shrink-0">
                ({broadcast.createdAt} - bởi {broadcast.authorName})
              </span>
            </div>

            {currentUser?.role === 'admin' ? (
              <button
                type="button"
                onClick={() => dismissBroadcastAlert()}
                className="px-2.5 py-1 rounded bg-black/20 hover:bg-black/40 text-[11px] font-semibold flex items-center gap-1 shrink-0 transition-colors"
                title="Quản trị viên tắt thông báo này"
              >
                <X className="w-3.5 h-3.5" />
                <span>Gỡ thông báo</span>
              </button>
            ) : null}
          </div>
        </div>
      )}

      {/* Main navigation header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
        {/* Brand logo & site name */}
        <div
          onClick={() => setCurrentView('home')}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-xs transition-transform group-hover:scale-105"
            style={{ backgroundColor: siteSettings.primaryColor }}
          >
            <HeartHandshake className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-bold tracking-tight text-stone-900 leading-tight">
              {siteSettings.siteName}
            </h1>
            <p className="text-xs text-stone-500 font-medium">
              Hệ thống Tham vấn & Chăm sóc Sức khỏe Tinh thần Học đường
            </p>
          </div>
        </div>

        {/* Right action controls */}
        <div className="flex items-center gap-2.5">
          {currentUser ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setCurrentView('dashboard')}
                className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors flex items-center gap-2 ${
                  currentView === 'dashboard'
                    ? 'bg-stone-900 text-white'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-800'
                }`}
              >
                <User className="w-4 h-4" />
                <span className="hidden sm:inline">Bàn làm việc</span>
                {getRoleBadge(currentUser.role)}
              </button>

              <button
                type="button"
                onClick={handleLogout}
                className="p-2 text-stone-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                title="Đăng xuất"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onOpenLogin}
              className="px-4 py-2 text-sm font-semibold rounded-lg text-white shadow-xs transition-all hover:brightness-105 flex items-center gap-2"
              style={{ backgroundColor: siteSettings.primaryColor }}
            >
              <LogIn className="w-4 h-4" />
              <span>Đăng nhập</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
