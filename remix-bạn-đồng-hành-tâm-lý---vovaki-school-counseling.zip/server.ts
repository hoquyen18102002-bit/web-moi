import express from "express";
import path from "path";
import https from "https";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { initialSharedState } from "./src/initialData";
import {
  AppSharedState,
  ChatMessage,
  CounselingBooking,
  EmergencySession,
  PositiveRoomSession,
  TestSubmission,
  SentimentAnalysisResult,
  ExportAuditLog,
  UserAccount,
  Article,
  PsychologicalTest,
  AuthLog,
  RealtimeBroadcastAlert,
} from "./src/types";

// Persistent disk storage path for shared state across restarts and all visitors
const DB_STORAGE_PATH = path.join(process.cwd(), "data", "vovaki_persistent_db.json");

function loadSharedStateFromDisk(): AppSharedState {
  try {
    if (fs.existsSync(DB_STORAGE_PATH)) {
      const raw = fs.readFileSync(DB_STORAGE_PATH, "utf-8");
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === "object") {
        console.log("Loaded persistent database from disk:", DB_STORAGE_PATH);
        return {
          ...JSON.parse(JSON.stringify(initialSharedState)),
          ...parsed,
          dynamicWebsite: parsed.dynamicWebsite || initialSharedState.dynamicWebsite,
        };
      }
    }
  } catch (err) {
    console.warn("Could not load database from disk, using initial state:", err);
  }
  return JSON.parse(JSON.stringify(initialSharedState));
}

function saveSharedStateToDisk() {
  try {
    const dir = path.dirname(DB_STORAGE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DB_STORAGE_PATH, JSON.stringify(sharedState, null, 2), "utf-8");
  } catch (err) {
    console.warn("Failed to persist database to disk:", err);
  }
}

// In-memory shared state synchronized for all clients with disk persistence
let sharedState: AppSharedState = loadSharedStateFromDisk();

function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // CORS middleware for iframe preview and cross-origin API access
  app.use((_req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization, x-user-role, x-user-id"
    );
    if (_req.method === "OPTIONS") {
      res.sendStatus(200);
      return;
    }
    next();
  });

  app.use(express.json({ limit: "15mb" }));

  // --- API Routes ---

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Get full shared state
  app.get("/api/state", (_req, res) => {
    res.json(sharedState);
  });

  // Update shared state (partial or full)
  app.post("/api/state", (req, res) => {
    try {
      const updates = req.body;
      sharedState = {
        ...sharedState,
        ...updates,
      };
      saveSharedStateToDisk();
      res.json({ success: true, state: sharedState });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to update state" });
    }
  });

  // Reset to initial sample data
  app.post("/api/reset-demo", (_req, res) => {
    sharedState = JSON.parse(JSON.stringify(initialSharedState));
    saveSharedStateToDisk();
    res.json({ success: true, state: sharedState });
  });

  // Export full database as JSON
  app.get("/api/export-db", (_req, res) => {
    res.setHeader("Content-Disposition", 'attachment; filename="vovaki_counseling_db_export.json"');
    res.setHeader("Content-Type", "application/json");
    res.send(JSON.stringify(sharedState, null, 2));
  });

  // --- Admin Account Management Endpoints ---

  // Add / Provision new user
  app.post("/api/admin/users", (req, res) => {
    try {
      const { username, fullName, role, email, phone, classId, studentCode, password, avatar } = req.body;
      if (!username || !fullName || !role) {
        return res.status(400).json({ error: "Vui lòng điền đủ Tên đăng nhập, Họ và Tên và Vai trò" });
      }
      const cleanUsername = username.trim().toLowerCase();
      const existingUser = sharedState.users.find((u) => u.username.toLowerCase() === cleanUsername);
      if (existingUser) {
        return res.status(400).json({ error: `Tên đăng nhập "${cleanUsername}" đã tồn tại trong hệ thống` });
      }

      const newUser: UserAccount = {
        id: `usr-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        username: cleanUsername,
        fullName: fullName.trim(),
        role,
        email: email?.trim() || undefined,
        phone: phone?.trim() || undefined,
        classId: classId?.trim() || undefined,
        studentCode: studentCode?.trim() || (role === 'student' ? `VVK-${Math.floor(10000 + Math.random() * 90000)}` : undefined),
        password: password?.trim() || '123456',
        avatar: avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
        isActive: true,
        createdAt: new Date().toISOString().split('T')[0],
      };

      sharedState.users.unshift(newUser);

      // Audit Log
      const log: AuthLog = {
        id: `auth-${Date.now()}`,
        username: cleanUsername,
        action: 'create_user',
        timestamp: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        ip: req.ip || '127.0.0.1',
        status: 'success',
        details: `Quản trị viên đã cấp tài khoản mới: ${newUser.fullName} (${newUser.role})`,
      };
      sharedState.authLogs = sharedState.authLogs || [];
      sharedState.authLogs.unshift(log);

      res.json({ success: true, user: newUser, users: sharedState.users, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi tạo tài khoản" });
    }
  });

  // Delete user
  app.delete("/api/admin/users/:id", (req, res) => {
    try {
      const { id } = req.params;
      const targetUser = sharedState.users.find((u) => u.id === id);
      if (!targetUser) {
        return res.status(404).json({ error: "Không tìm thấy người dùng cần xóa" });
      }

      sharedState.users = sharedState.users.filter((u) => u.id !== id);

      // Audit Log
      const log: AuthLog = {
        id: `auth-${Date.now()}`,
        username: targetUser.username,
        action: 'delete_user',
        timestamp: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        ip: req.ip || '127.0.0.1',
        status: 'success',
        details: `Đã xóa vĩnh viễn tài khoản: ${targetUser.fullName} (${targetUser.username})`,
      };
      sharedState.authLogs = sharedState.authLogs || [];
      sharedState.authLogs.unshift(log);

      res.json({ success: true, deletedId: id, users: sharedState.users, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi xóa tài khoản" });
    }
  });

  // Update / Patch user (Edit profile, change role, toggle active/lock, reset password)
  app.patch("/api/admin/users/:id", (req, res) => {
    try {
      const { id } = req.params;
      const user = sharedState.users.find((u) => u.id === id);
      if (!user) {
        return res.status(404).json({ error: "Không tìm thấy người dùng" });
      }

      const { fullName, role, email, phone, classId, studentCode, password, isActive, avatar } = req.body;
      if (fullName !== undefined) user.fullName = fullName;
      if (role !== undefined) user.role = role;
      if (email !== undefined) user.email = email;
      if (phone !== undefined) user.phone = phone;
      if (classId !== undefined) user.classId = classId;
      if (studentCode !== undefined) user.studentCode = studentCode;
      if (avatar !== undefined) user.avatar = avatar;
      if (password !== undefined) user.password = password;
      if (isActive !== undefined) user.isActive = isActive;

      // Audit Log
      const log: AuthLog = {
        id: `auth-${Date.now()}`,
        username: user.username,
        action: password !== undefined ? 'reset_password' : isActive !== undefined ? 'toggle_lock' : 'change_role',
        timestamp: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        ip: req.ip || '127.0.0.1',
        status: 'success',
        details: `Quản trị viên cập nhật tài khoản: ${user.fullName} (isActive: ${user.isActive ?? true})`,
      };
      sharedState.authLogs = sharedState.authLogs || [];
      sharedState.authLogs.unshift(log);

      res.json({ success: true, user, users: sharedState.users, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi cập nhật tài khoản" });
    }
  });

  // --- Front-end Content Management: Articles CRUD ---
  // Read all articles
  app.get("/api/articles", (_req, res) => {
    res.json(sharedState.articles);
  });

  // Create article (accessible for counselors and admins)
  const handleCreateArticle = (req: express.Request, res: express.Response) => {
    try {
      const article: Article = {
        ...req.body,
        id: req.body.id || `art-${Date.now()}`,
        date: req.body.date || new Date().toISOString().split('T')[0],
      };
      sharedState.articles.unshift(article);
      saveSharedStateToDisk();
      res.json({ success: true, article, articles: sharedState.articles, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi thêm bài viết" });
    }
  };
  app.post("/api/admin/articles", handleCreateArticle);
  app.post("/api/articles", handleCreateArticle);

  // Update article
  const handleUpdateArticle = (req: express.Request, res: express.Response) => {
    try {
      const { id } = req.params;
      const idx = sharedState.articles.findIndex((a) => a.id === id);
      if (idx === -1) {
        return res.status(404).json({ error: "Không tìm thấy bài viết" });
      }
      sharedState.articles[idx] = { ...sharedState.articles[idx], ...req.body };
      saveSharedStateToDisk();
      res.json({ success: true, article: sharedState.articles[idx], articles: sharedState.articles, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi cập nhật bài viết" });
    }
  };
  app.put("/api/admin/articles/:id", handleUpdateArticle);
  app.put("/api/articles/:id", handleUpdateArticle);

  // Delete article
  const handleDeleteArticle = (req: express.Request, res: express.Response) => {
    try {
      const { id } = req.params;
      sharedState.articles = sharedState.articles.filter((a) => a.id !== id);
      saveSharedStateToDisk();
      res.json({ success: true, deletedId: id, articles: sharedState.articles, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi xóa bài viết" });
    }
  };
  app.delete("/api/admin/articles/:id", handleDeleteArticle);
  app.delete("/api/articles/:id", handleDeleteArticle);

  // --- Front-end Content Management: Psychological Tests CRUD ---
  app.post("/api/admin/tests", (req, res) => {
    try {
      const newTest: PsychologicalTest = {
        ...req.body,
        id: req.body.id || `test-${Date.now()}`,
        createdAt: new Date().toISOString().split('T')[0],
        isActive: true,
      };
      sharedState.psychologicalTests.unshift(newTest);
      res.json({ success: true, test: newTest, tests: sharedState.psychologicalTests, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi thêm bài test" });
    }
  });

  app.delete("/api/admin/tests/:id", (req, res) => {
    try {
      const { id } = req.params;
      sharedState.psychologicalTests = sharedState.psychologicalTests.filter((t) => t.id !== id);
      res.json({ success: true, deletedId: id, tests: sharedState.psychologicalTests, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi xóa bài test" });
    }
  });

  // --- Back-end & Database Direct Table Operations ---
  // Clear any table safely
  app.post("/api/admin/database/clear-table", (req, res) => {
    try {
      const { tableName } = req.body;
      const validTables = [
        'bookings',
        'emergencySessions',
        'positiveRoomSessions',
        'testSubmissions',
        'studentRecords',
        'sentimentAnalyses',
        'articles',
        'exportAuditLogs',
        'authLogs',
      ];
      if (!validTables.includes(tableName)) {
        return res.status(400).json({ error: `Bảng "${tableName}" không hợp lệ hoặc được bảo vệ nghiêm ngặt.` });
      }
      (sharedState as any)[tableName] = [];
      res.json({ success: true, tableName, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi xóa dữ liệu bảng" });
    }
  });

  // Delete row from any table
  app.post("/api/admin/database/delete-row", (req, res) => {
    try {
      const { tableName, rowId } = req.body;
      if (!Array.isArray((sharedState as any)[tableName])) {
        return res.status(400).json({ error: `Bảng "${tableName}" không tồn tại` });
      }
      (sharedState as any)[tableName] = (sharedState as any)[tableName].filter((row: any) => row.id !== rowId);
      res.json({ success: true, tableName, rowId, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi xóa bản ghi" });
    }
  });

  // Add row to any table
  app.post("/api/admin/database/add-row", (req, res) => {
    try {
      const { tableName, rowData } = req.body;
      if (!Array.isArray((sharedState as any)[tableName])) {
        return res.status(400).json({ error: `Bảng "${tableName}" không tồn tại` });
      }
      const newRow = {
        id: rowData.id || `row-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        ...rowData,
      };
      (sharedState as any)[tableName].unshift(newRow);
      res.json({ success: true, tableName, newRow, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi thêm bản ghi vào cơ sở dữ liệu" });
    }
  });

  // Restore entire database from JSON
  app.post("/api/admin/database/restore", (req, res) => {
    try {
      const importedState = req.body;
      if (!importedState || typeof importedState !== 'object') {
        return res.status(400).json({ error: "Dữ liệu phục hồi không hợp lệ" });
      }
      const dataToRestore = importedState.database || importedState;
      sharedState = {
        ...sharedState,
        ...dataToRestore,
      };
      res.json({ success: true, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi phục hồi cơ sở dữ liệu" });
    }
  });

  // --- Real-time Management Endpoints ---
  app.post("/api/admin/realtime/broadcast", (req, res) => {
    try {
      const { message, level = 'info', active = true, authorName = 'Quản trị viên' } = req.body;
      sharedState.realtimeSettings = sharedState.realtimeSettings || {
        pollingIntervalMs: 3000,
        serverStatus: 'connected',
        lastPingMs: 20,
        activeConnectionsCount: 15,
      };
      if (active && message) {
        sharedState.realtimeSettings.broadcastAlert = {
          id: `alert-${Date.now()}`,
          message,
          level,
          active: true,
          createdAt: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
          authorName,
        };
      } else {
        sharedState.realtimeSettings.broadcastAlert = null;
      }
      res.json({ success: true, realtimeSettings: sharedState.realtimeSettings, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi phát sóng thông báo khẩn cấp" });
    }
  });

  app.post("/api/admin/realtime/settings", (req, res) => {
    try {
      const { pollingIntervalMs, serverStatus } = req.body;
      sharedState.realtimeSettings = {
        ...(sharedState.realtimeSettings || {
          pollingIntervalMs: 3000,
          serverStatus: 'connected',
          lastPingMs: 22,
          activeConnectionsCount: 16,
        }),
        pollingIntervalMs: pollingIntervalMs ?? sharedState.realtimeSettings?.pollingIntervalMs ?? 3000,
        serverStatus: serverStatus ?? sharedState.realtimeSettings?.serverStatus ?? 'connected',
      };
      res.json({ success: true, realtimeSettings: sharedState.realtimeSettings, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi cấu hình Realtime" });
    }
  });

  // --- Authentication Policy Settings ---
  app.post("/api/admin/auth/settings", (req, res) => {
    try {
      sharedState.authSettings = {
        ...(sharedState.authSettings || {
          minPasswordLength: 6,
          requireSpecialChars: false,
          sessionTimeoutMinutes: 120,
          allowStudentRegistration: true,
          forceAnonymousStudentMode: true,
          maxLoginAttempts: 5,
        }),
        ...req.body,
      };
      res.json({ success: true, authSettings: sharedState.authSettings, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi lưu cấu hình bảo mật" });
    }
  });

  // --- Dynamic Website Builder & Theme System Endpoints ---

  // Get dynamic website configuration
  app.get("/api/admin/website-builder", (_req, res) => {
    try {
      res.json(sharedState.dynamicWebsite);
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi lấy cấu hình website" });
    }
  });

  // Save / Update dynamic website configuration & create version
  app.post("/api/admin/website-builder/publish", (req, res) => {
    try {
      const { dynamicWebsite, changeSummary, authorName, authorRole } = req.body;
      if (!dynamicWebsite) {
        return res.status(400).json({ error: "Dữ liệu cấu hình website không hợp lệ" });
      }

      const currentConfig = sharedState.dynamicWebsite;
      const currentVersions = currentConfig?.versions || [];
      const newVerNumber = (currentVersions[0]?.versionNumber || currentVersions.length) + 1;

      const newVersion = {
        id: `ver-${Date.now()}`,
        versionNumber: newVerNumber,
        createdAt: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        createdByName: authorName || 'Quản trị viên Hệ thống',
        createdByRole: authorRole || 'Super Admin',
        changeSummary: changeSummary || `Xuất bản phiên bản #${newVerNumber}`,
        snapshot: {
          theme: dynamicWebsite.theme,
          header: dynamicWebsite.header,
          footer: dynamicWebsite.footer,
          menu: dynamicWebsite.menu,
          pages: dynamicWebsite.pages,
        },
      };

      const updatedVersions = [newVersion, ...currentVersions.slice(0, 19)]; // Keep up to 20 versions

      sharedState.dynamicWebsite = {
        ...dynamicWebsite,
        versions: updatedVersions,
      };

      // Keep siteSettings in sync with theme if modified
      if (dynamicWebsite.theme?.primaryColor) {
        sharedState.siteSettings.primaryColor = dynamicWebsite.theme.primaryColor;
      }
      if (dynamicWebsite.theme?.fontFamily) {
        sharedState.siteSettings.fontFamily = dynamicWebsite.theme.fontFamily;
      }
      if (dynamicWebsite.header?.logoText) {
        sharedState.siteSettings.siteName = dynamicWebsite.header.logoText;
      }

      saveSharedStateToDisk();

      res.json({
        success: true,
        dynamicWebsite: sharedState.dynamicWebsite,
        newVersion,
        state: sharedState,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi xuất bản cấu hình website" });
    }
  });

  // Rollback to specific version
  app.post("/api/admin/website-builder/rollback", (req, res) => {
    try {
      const { versionId } = req.body;
      const versions = sharedState.dynamicWebsite?.versions || [];
      const targetVersion = versions.find((v) => v.id === versionId);
      if (!targetVersion) {
        return res.status(404).json({ error: "Không tìm thấy phiên bản lịch sử cần khôi phục" });
      }

      const snapshot = targetVersion.snapshot;
      const rollbackVersion = {
        id: `ver-${Date.now()}`,
        versionNumber: (versions[0]?.versionNumber || versions.length) + 1,
        createdAt: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        createdByName: 'Quản trị viên Hệ thống',
        createdByRole: 'Super Admin',
        changeSummary: `Khôi phục về phiên bản #${targetVersion.versionNumber} (${targetVersion.createdAt})`,
        snapshot: JSON.parse(JSON.stringify(snapshot)),
      };

      sharedState.dynamicWebsite = {
        ...(sharedState.dynamicWebsite || {}),
        ...JSON.parse(JSON.stringify(snapshot)),
        activePageId: sharedState.dynamicWebsite?.activePageId || 'page-home',
        versions: [rollbackVersion, ...versions.slice(0, 19)],
      };

      // Sync siteSettings
      if (snapshot.theme?.primaryColor) {
        sharedState.siteSettings.primaryColor = snapshot.theme.primaryColor;
      }
      if (snapshot.theme?.fontFamily) {
        sharedState.siteSettings.fontFamily = snapshot.theme.fontFamily;
      }
      if (snapshot.header?.logoText) {
        sharedState.siteSettings.siteName = snapshot.header.logoText;
      }

      saveSharedStateToDisk();

      res.json({
        success: true,
        dynamicWebsite: sharedState.dynamicWebsite,
        restoredVersion: targetVersion,
        state: sharedState,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi khôi phục phiên bản" });
    }
  });

  // Update theme only
  app.post("/api/admin/website-builder/theme", (req, res) => {
    try {
      const theme = req.body;
      if (sharedState.dynamicWebsite) {
        sharedState.dynamicWebsite.theme = {
          ...sharedState.dynamicWebsite.theme,
          ...theme,
        };
        if (theme.primaryColor) sharedState.siteSettings.primaryColor = theme.primaryColor;
        if (theme.fontFamily) sharedState.siteSettings.fontFamily = theme.fontFamily;
      }
      res.json({ success: true, theme: sharedState.dynamicWebsite?.theme, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi lưu cấu hình Theme" });
    }
  });

  // Toggle Live Editor Mode
  app.post("/api/admin/website-builder/live-editor", (req, res) => {
    try {
      const { active } = req.body;
      if (sharedState.dynamicWebsite) {
        sharedState.dynamicWebsite.liveEditorActive = !!active;
      }
      res.json({ success: true, liveEditorActive: sharedState.dynamicWebsite?.liveEditorActive, state: sharedState });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi khi chuyển đổi chế độ Live Editor" });
    }
  });

  // User login verification endpoint
  app.post("/api/auth/login", (req, res) => {
    try {
      const { username, password } = req.body;
      const user = sharedState.users.find((u) => u.username.toLowerCase() === username?.trim().toLowerCase());
      if (!user) {
        return res.status(401).json({ error: "Tên đăng nhập không tồn tại trong hệ thống." });
      }
      if (user.isActive === false) {
        return res.status(403).json({ error: "Tài khoản của bạn đang bị Quản trị viên tạm khóa. Vui lòng liên hệ nhà trường để được hỗ trợ." });
      }
      if (user.password && password && user.password !== password) {
        return res.status(401).json({ error: "Mật khẩu không chính xác. Vui lòng kiểm tra lại." });
      }

      user.lastLogin = new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });

      // Log login
      const log: AuthLog = {
        id: `auth-${Date.now()}`,
        username: user.username,
        action: 'login',
        timestamp: user.lastLogin,
        ip: req.ip || '127.0.0.1',
        status: 'success',
        details: `Đăng nhập thành công với vai trò: ${user.role}`,
      };
      sharedState.authLogs = sharedState.authLogs || [];
      sharedState.authLogs.unshift(log);

      res.json({ success: true, user });
    } catch (err: any) {
      res.status(500).json({ error: err.message || "Lỗi đăng nhập" });
    }
  });

  // Add or update booking
  app.post("/api/bookings", (req, res) => {
    const booking: CounselingBooking = req.body;
    const existingIndex = sharedState.bookings.findIndex((b) => b.id === booking.id);
    if (existingIndex >= 0) {
      sharedState.bookings[existingIndex] = booking;
    } else {
      sharedState.bookings.unshift(booking);
    }
    res.json({ success: true, booking, bookings: sharedState.bookings });
  });

  // Add message to booking chat
  app.post("/api/bookings/:id/message", (req, res) => {
    const { id } = req.params;
    const message: ChatMessage = req.body;
    const booking = sharedState.bookings.find((b) => b.id === id);
    if (!booking) {
      return res.status(404).json({ error: "Booking not found" });
    }
    booking.messages = booking.messages || [];
    booking.messages.push(message);
    res.json({ success: true, booking });
  });

  // Emergency session messages & status
  app.post("/api/emergency", (req, res) => {
    const session: EmergencySession = req.body;
    const existingIndex = sharedState.emergencySessions.findIndex((s) => s.id === session.id);
    if (existingIndex >= 0) {
      sharedState.emergencySessions[existingIndex] = session;
    } else {
      sharedState.emergencySessions.unshift(session);
    }
    res.json({ success: true, session, emergencySessions: sharedState.emergencySessions });
  });

  app.post("/api/emergency/:id/message", (req, res) => {
    const { id } = req.params;
    const message: ChatMessage = req.body;
    const session = sharedState.emergencySessions.find((s) => s.id === id);
    if (!session) {
      return res.status(404).json({ error: "Emergency session not found" });
    }
    session.messages = session.messages || [];
    session.messages.push(message);
    res.json({ success: true, session });
  });

  // Positive room session
  app.post("/api/positive-room/session", (req, res) => {
    const session: PositiveRoomSession = req.body;
    const existingIndex = sharedState.positiveRoomSessions.findIndex((s) => s.id === session.id);
    if (existingIndex >= 0) {
      sharedState.positiveRoomSessions[existingIndex] = session;
    } else {
      sharedState.positiveRoomSessions.unshift(session);
    }
    res.json({ success: true, session, positiveRoomSessions: sharedState.positiveRoomSessions });
  });

  // Counselor remote guidance / intervention for positive room
  app.post("/api/positive-room/:id/steer", (req, res) => {
    const { id } = req.params;
    const { counselorGuidancePrompt, counselorLiveNotes, overrideResponse } = req.body;
    const session = sharedState.positiveRoomSessions.find((s) => s.id === id);
    if (!session) {
      return res.status(404).json({ error: "Session not found" });
    }
    if (counselorGuidancePrompt !== undefined) session.counselorGuidancePrompt = counselorGuidancePrompt;
    if (counselorLiveNotes !== undefined) session.counselorLiveNotes = counselorLiveNotes;
    if (overrideResponse) {
      session.messages.push({
        id: `counselor-ovr-${Date.now()}`,
        sender: 'vovakier_ai',
        senderName: 'Phòng tích cực - Vovakier (Giáo viên định hướng)',
        text: overrideResponse,
        timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        isCounselorIntervention: true,
      });
    }
    res.json({ success: true, session });
  });

  // Submit psychological test
  app.post("/api/tests/submit", (req, res) => {
    const submission: TestSubmission = req.body;
    sharedState.testSubmissions.unshift(submission);

    // Update or insert student health record
    const existingRecord = sharedState.studentRecords.find(
      (r) => r.studentId === submission.studentId || r.studentCode === submission.studentCode
    );

    if (existingRecord) {
      existingRecord.latestScore = submission.totalScore;
      existingRecord.status = submission.evaluation;
      existingRecord.lastUpdatedMonth = submission.month;
      existingRecord.scoreHistory.push({
        month: submission.month,
        score: submission.totalScore,
        evaluation: submission.evaluation,
      });
      if (submission.evaluation === 'Cần đặc biệt lưu ý') {
        existingRecord.specialAttentionFlag = true;
      }
    } else {
      sharedState.studentRecords.push({
        id: `rec-${Date.now()}`,
        studentId: submission.studentId,
        studentName: submission.studentName,
        studentCode: submission.studentCode,
        classId: submission.classId,
        grade: submission.grade,
        latestScore: submission.totalScore,
        status: submission.evaluation,
        lastUpdatedMonth: submission.month,
        scoreHistory: [
          {
            month: submission.month,
            score: submission.totalScore,
            evaluation: submission.evaluation,
          },
        ],
        counselorNotes: 'Mới hoàn thành khảo sát tâm lý.',
        homeroomNotes: '',
        specialAttentionFlag: submission.evaluation === 'Cần đặc biệt lưu ý',
      });
    }

    res.json({ success: true, submission, studentRecords: sharedState.studentRecords });
  });

  // Helper function to fetch a single TTS audio chunk in Vietnamese
  function fetchSingleVietnameseTTSChunk(sentence: string): Promise<Buffer | null> {
    return new Promise((resolve) => {
      try {
        const encoded = encodeURIComponent(sentence);
        const url = `https://translate.google.com/translate_tts?ie=UTF-8&tl=vi&client=gtx&q=${encoded}`;
        const req = https.get(
          url,
          {
            headers: {
              'User-Agent':
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
              Referer: 'https://translate.google.com/',
              Accept: 'audio/mpeg, audio/*',
            },
            timeout: 6000,
          },
          (res) => {
            if (res.statusCode !== 200) {
              return resolve(null);
            }
            const chunks: Buffer[] = [];
            res.on('data', (c) => chunks.push(c));
            res.on('end', () => {
              const buffer = Buffer.concat(chunks);
              if (buffer.length > 200) {
                resolve(buffer);
              } else {
                resolve(null);
              }
            });
          }
        );

        req.on('error', () => resolve(null));
        req.on('timeout', () => {
          req.destroy();
          resolve(null);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

  // Fetch authentic Vietnamese speech audio (100% Native Vietnamese pronunciation, no extra noise)
  async function fetchVietnameseTTSAudio(text: string): Promise<string | null> {
    try {
      const cleanText = text
        .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
        .replace(/\([^\)]*\)/g, '')
        .replace(/\[[^\]]*\]/g, '')
        .replace(/[*#_`~]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
      if (!cleanText) return null;

      // Extract caring sentences for speech (2-3 sentences, max ~260 chars)
      const rawSentences = cleanText.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [cleanText];
      const trimmed = rawSentences.map((s) => s.trim()).filter(Boolean);
      const chosenText = (trimmed.slice(0, 3).join(' ') || cleanText).slice(0, 260).trim();
      if (!chosenText) return null;

      // Break into chunks of max 140 chars
      const chunksToFetch: string[] = [];
      if (chosenText.length <= 140) {
        chunksToFetch.push(chosenText);
      } else {
        const subParts = chosenText.match(/.{1,130}(\s|$)/g) || [chosenText];
        for (const sp of subParts) {
          if (sp.trim()) chunksToFetch.push(sp.trim());
        }
      }

      // At most 3 chunks for natural and complete emotional dialogue
      const selectedChunks = chunksToFetch.slice(0, 3);
      const audioBuffers: Buffer[] = [];

      for (const chunk of selectedChunks) {
        const buf = await fetchSingleVietnameseTTSChunk(chunk);
        if (buf) {
          audioBuffers.push(buf);
        }
      }

      if (audioBuffers.length > 0) {
        const fullAudio = Buffer.concat(audioBuffers);
        return `data:audio/mp3;base64,${fullAudio.toString('base64')}`;
      }
      return null;
    } catch (e) {
      console.warn("Notice: Error compiling Vietnamese TTS audio:", e);
      return null;
    }
  }

  // Dedicated Vietnamese Text-To-Speech Endpoint (Phát âm thanh Tiếng Việt chuẩn)
  app.post("/api/gemini/tts", async (req, res) => {
    const { text } = req.body;
    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: "Thiếu nội dung văn bản để đọc" });
    }
    const audioDataUrl = await fetchVietnameseTTSAudio(text);
    res.json({ success: !!audioDataUrl, audioDataUrl, text });
  });

  // AI Chat for "Phòng tích cực - Vovakier" with real-time sync & Vietnamese speech reading
  app.post("/api/gemini/vovakier-chat", async (req, res) => {
    const { message, sessionId, chatHistory, studentNickname, studentId } = req.body;

    // Resolve or find active session
    let session = sessionId ? sharedState.positiveRoomSessions.find((s) => s.id === sessionId) : null;
    if (!session && sharedState.positiveRoomSessions.length > 0) {
      session = sharedState.positiveRoomSessions[0];
    }
    if (!session) {
      const newSession: PositiveRoomSession = {
        id: sessionId || `pos-${Date.now()}`,
        studentId: studentId || 'usr-student-1',
        studentAnonymousCode: 'HS-VOVA-' + Math.floor(1000 + Math.random() * 9000),
        studentNickname: studentNickname || 'Học sinh',
        status: 'active',
        startedAt:
          new Date().toLocaleDateString('vi-VN') +
          ' ' +
          new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        audioActive: true,
        messages: [],
      };
      sharedState.positiveRoomSessions.unshift(newSession);
      session = newSession;
    }

    const timeNow = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });

    // Record incoming student message in real-time if not already logged
    if (message && typeof message === 'string' && message.trim()) {
      const alreadyLogged = session.messages.some(
        (m) => m.text === message.trim() && m.sender === 'student'
      );
      if (!alreadyLogged) {
        session.messages.push({
          id: `pmsg-${Date.now()}`,
          sender: 'student',
          senderName: studentNickname || session.studentNickname || 'Học sinh',
          text: message.trim(),
          timestamp: timeNow,
        });
      }
    }

    // Check for counselor intervention/guidance prompt
    const counselorPrompt = session.counselorGuidancePrompt || "";

    const ai = getGeminiClient();
    let replyText = "";
    
    // Normalize text without diacritics for infallible skip command detection
    const normalizedMsg = message
      .trim()
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd');

    const isSkipCommandOnly = /^(thoi\s+)?bo\s+(qua|wa|di)(\s+(di|nhe|nha|a|nay|chuyen\s+nay|di\s+ban))?[.!?]*$/i.test(normalizedMsg);

    if (!ai) {
      if (isSkipCommandOnly) {
        replyText = `Được rồi bạn, mình chuyển sang chủ đề khác ngay nhé. Bạn muốn chúng mình trò chuyện hoặc cần lời khuyên thực tế về điều gì tiếp theo nào?`;
      } else {
        const fallbackResponses = [
          `Chào ${studentNickname || session.studentNickname || 'bạn'}, mình đã lắng nghe và phân tích tình huống của bạn. Để giải quyết vấn đề này một cách thực tế nhất, bạn hãy dành mười phút nghỉ ngơi và chia nhỏ công việc thành từng bước cụ thể nhé. Bạn muốn chúng mình cùng bắt đầu từ bước nào?`,
          `Mình rất trân trọng khi bạn chia sẻ thật lòng. Mọi áp lực đều có cách giải quyết thực tế khi chúng ta nhìn nhận rõ nguyên nhân; bạn hãy uống một ngụm nước ấm và cùng mình gỡ rối từng phần nhé.`,
          `Mình luôn ở đây lắng nghe, phân tích kỹ càng và đưa ra lời khuyên thực tế cho bạn. Bạn cảm thấy phần nào đang cần được hỗ trợ nhất lúc này?`,
        ];
        replyText = fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
      }
    } else {
      try {
        if (isSkipCommandOnly) {
          replyText = `Được rồi bạn, mình chuyển sang chủ đề khác ngay nhé. Bạn muốn chúng mình trò chuyện hoặc cần lời khuyên thực tế về điều gì tiếp theo nào?`;
        } else {
          let systemInstruction = `Bạn là Vovakier - Chuyên viên tư vấn tâm lý học đường tại "Phòng tích cực - Vovakier" (Trường THPT VoVaKi).
NGUYÊN TẮC BẮT BUỘC:
1. LẮNG NGHE, PHÂN TÍCH VÀ ĐƯA RA LỜI KHUYÊN THỰC TẾ:
   - Lắng nghe thật kỹ tâm sự của học sinh, phân tích đúng bản chất nguyên nhân gây ra áp lực (học tập, thi cử, bạn bè, thầy cô, cha mẹ).
   - Đưa ra lời khuyên THỰC TẾ, RÕ RÀNG, CÓ THỂ LÀM ĐƯỢC NGAY (ví dụ: cách chia nhỏ thời gian ôn tập, kỹ thuật hít thở 4-7-8, cách đối thoại bình tĩnh với bố mẹ).
2. CHUẨN MỰC SƯ PHẠM, TUYỆT ĐỐI KHÔNG NÓI BỪA, KHÔNG NÓI BẬY:
   - Nghiêm cấm bịa đặt thông tin, không đưa lời khuyên bừa bãi thiếu căn cứ.
   - Tuyệt đối không dùng từ ngữ thô tục, tiếng lóng xấu hay phát ngôn thiếu văn minh. Luôn giữ thái độ nhân ái, chuẩn mực, tôn trọng và nâng đỡ tinh thần học sinh.
   - DỪNG ÁP ĐẶT CÁC CUỘC TRÒ CHUYỆN LÀ SAI LẦM CỦA HỌC SINH: Tuyệt đối không phán xét, không quy chụp hoặc ám chỉ học sinh có lỗi, sai lầm hay yếu kém. Học sinh đến để chia sẻ cảm xúc, tìm kiếm sự thấu hiểu và giải pháp thực tế, không phải để nhận định tội hay bị dạy đời. Hãy luôn công nhận cảm xúc và cùng học sinh tìm hướng đi tích cực.
3. TỰ ĐỘNG PHÁT HIỆN TỪ KHÓA "BỎ QUA" VÀ CHUYỂN HƯỚNG CÂU CHUYỆN:
   - Khi người nói dùng từ khóa "bỏ qua", "thôi bỏ qua", "bỏ qua đi", "chuyển chủ đề":
     ĐÂY CHÍNH LÀ THAO TÁC NGẮT LỜI. Bạn PHẢI DỪNG HẲN CHỦ ĐỀ CŨ, KHÔNG nhắc lại, KHÔNG hỏi lý do tại sao bỏ qua.
     LẬP TỨC CHUYỂN HƯỚNG CÂU CHUYỆN theo nội dung yêu cầu mới của người nói, phân tích và đưa ra lời khuyên thực tế cho chủ đề mới.
4. QUY TẮC ÂM THANH VÀ GIỌNG ĐỌC:
   - ĐỘ DÀI: Từ 2 đến 3 câu ngắn gọn, ấm áp (khoảng 35 đến 55 từ) để hệ thống đọc thành âm thanh rõ ràng, tự nhiên.
   - 100% TIẾNG VIỆT: Không dùng tiếng Anh, không dùng ký hiệu lạ (*, #, _), không dùng emoji.
   - TUYỆT ĐỐI KHÔNG DÙNG TỪ "BỎ QUA" TRONG CÂU TRẢ LỜI CỦA BẠN (để tránh hệ thống âm thanh hiểu nhầm là khẩu lệnh). Hãy dùng: "mình chuyển sang", "chúng ta cùng trao đổi về", "mình hiểu rồi",...
   - Xưng hô thân mật: "mình" và "${studentNickname || session.studentNickname || 'bạn'}".`;

          if (counselorPrompt) {
            systemInstruction += `\n[ĐẶC BIỆT - CHỈ ĐẠO TỪ XA CỦA GIÁO VIÊN TƯ VẤN TÂM LÝ]: Hãy lồng ghép chỉ đạo sau vào phản hồi của bạn cho học sinh một cách khéo léo: "${counselorPrompt}"`;
          }

          const contents: any[] = [];
          if (Array.isArray(chatHistory)) {
            chatHistory.slice(-6).forEach((item: any) => {
              contents.push({
                role: item.sender === 'student' ? 'user' : 'model',
                parts: [{ text: item.text }],
              });
            });
          }
          contents.push({
            role: 'user',
            parts: [{ text: message || 'Xin chào' }],
          });

          // Use gemini-3.1-flash-lite or gemini-3.8-flash
          let genResponse: any = null;
          try {
            genResponse = await ai.models.generateContent({
              model: 'gemini-3.1-flash-lite',
              contents,
              config: {
                systemInstruction,
                temperature: 0.7,
              },
            });
          } catch (liteErr) {
            genResponse = await ai.models.generateContent({
              model: 'gemini-3.8-flash',
              contents,
              config: {
                systemInstruction,
                temperature: 0.7,
              },
            });
          }

          replyText = genResponse?.text?.trim() || "Vovakier luôn ở đây và lắng nghe bạn. Bạn có muốn chia sẻ thêm không?";
        }
      } catch (error: any) {
        console.warn("Gemini vovakier-chat notice:", error?.message || error);
        replyText = `Vovakier đã lắng nghe bạn rồi. Mình luôn ở đây để sẻ chia cùng bạn, hãy cùng mình hít thở thật sâu nhé.`;
      }
    }

    // Always record AI reply into session messages in real-time
    const aiMessage = {
      id: `vova-${Date.now()}`,
      sender: 'vovakier_ai' as const,
      senderName: 'Phòng tích cực - Vovakier',
      text: replyText,
      timestamp: timeNow,
    };
    session.messages.push(aiMessage);

    // Generate authentic Vietnamese speech audio
    let audioDataUrl: string | null = null;
    try {
      audioDataUrl = await fetchVietnameseTTSAudio(replyText);
    } catch (ttsErr) {
      console.warn("Notice: Vietnamese TTS audio error:", ttsErr);
    }

    res.json({
      text: replyText,
      audioDataUrl,
      messages: session.messages,
      session,
      sessionId: session.id,
      success: true,
    });
  });

  // AI Analysis of School-Wide Student Health Records
  app.post("/api/gemini/analyze-health", async (req, res) => {
    const ai = getGeminiClient();

    // Prepare data summary to feed to Gemini
    const totalRecords = sharedState.studentRecords.length;
    const testCount = sharedState.testSubmissions.length;
    const attentionCount = sharedState.studentRecords.filter((r) => r.status === 'Cần lưu ý').length;
    const specialAttentionCount = sharedState.studentRecords.filter((r) => r.status === 'Cần đặc biệt lưu ý').length;

    const dataPayload = {
      totalStudents: totalRecords,
      totalSubmissions: testCount,
      countAttention: attentionCount,
      countSpecialAttention: specialAttentionCount,
      studentRecordsSample: sharedState.studentRecords.map((r) => ({
        code: r.studentCode,
        class: r.classId,
        grade: r.grade,
        score: r.latestScore,
        status: r.status,
        counselorNotes: r.counselorNotes,
        homeroomNotes: r.homeroomNotes,
      })),
      recentChatTopics: sharedState.bookings.map((b) => b.topic),
      emergencyCount: sharedState.emergencySessions.length,
      positiveRoomSessionCount: sharedState.positiveRoomSessions.length,
    };

    if (!ai) {
      // Provide comprehensive structured fallback if no key
      const fallbackAnalysis = {
        generatedAt: new Date().toLocaleString('vi-VN'),
        summary: `Hệ thống ghi nhận ${totalRecords} hồ sơ sức khỏe tâm lý và ${testCount} lượt làm bài test. Có ${specialAttentionCount} học sinh mức 'Cần đặc biệt lưu ý' (nguy cơ trầm cảm/lo âu cao) và ${attentionCount} học sinh mức 'Cần lưu ý'.`,
        potentialPhenomena: [
          {
            title: 'Hội chứng "Sốc chuyển cấp" và lo âu hòa nhập ở khối 10',
            riskLevel: 'Trung bình' as const,
            description: 'Sự thay đổi về tốc độ giảng dạy, khối lượng bài tập lớn và môi trường bạn bè mới tạo nên tâm lý căng thẳng kéo dài.',
            warningSigns: ['Thường xuyên mệt mỏi vào tiết học đầu', 'Ít tham gia hoạt động lớp', 'Điểm số bài kiểm tra đột ngột giảm'],
            prevention: 'Tổ chức chuyên đề phương pháp học tập THPT và các buổi sinh hoạt gắn kết đầu năm.',
          },
          {
            title: 'Áp lực chọn khối và kỳ vọng gia đình ở khối 11-12',
            riskLevel: 'Cao' as const,
            description: 'Học sinh chịu áp lực lớn từ định hướng nghề nghiệp, cạnh tranh điểm số xét tuyển đại học.',
            warningSigns: ['Mất ngủ kéo dài', 'Dễ cáu gắt', 'Thường xuyên tìm kiếm hỗ trợ về lo âu'],
            prevention: 'Tổ chức tọa đàm định hướng nghề nghiệp kết hợp trao đổi với phụ huynh.',
          },
        ],
        commonIssues: [
          {
            issue: 'Căng thẳng thi cử & áp lực điểm số',
            percentage: 45,
            evidenceFromChats: 'Từ khóa "điểm số", "áp lực thi", "sợ bố mẹ trách" chiếm đa số trong các cuộc trò chuyện.',
            affectedGroup: 'Tất cả các khối, đặc biệt là khối 12.',
          },
          {
            issue: 'Khó khăn trong quan hệ bạn bè & cảm giác cô độc',
            percentage: 30,
            evidenceFromChats: 'Học sinh chia sẻ về sự lạc lõng trong lớp và nỗi sợ bị bạn bè tẩy chay thầm lặng.',
            affectedGroup: 'Tập trung chủ yếu ở học sinh lớp 10 và 11.',
          },
          {
            issue: 'Rối loạn giấc ngủ do sử dụng thiết bị khuya và căng thẳng',
            percentage: 25,
            evidenceFromChats: 'Các tin nhắn gửi đến Phòng tích cực vào khung giờ 23h - 2h sáng than phiền mất ngủ.',
            affectedGroup: 'Học sinh cả 3 khối.',
          },
        ],
        depressionRiskStudents: sharedState.studentRecords
          .filter((r) => r.status === 'Cần đặc biệt lưu ý' || r.specialAttentionFlag)
          .map((r) => ({
            studentCode: r.studentCode,
            classId: r.classId,
            riskLevel: r.status as 'Cần đặc biệt lưu ý' | 'Cần lưu ý',
            indicators: [
              `Điểm khảo sát: ${r.latestScore}`,
              r.counselorNotes || 'Có biểu hiện căng thẳng cảm xúc',
            ],
            recommendedAction: 'GV Tư vấn chủ động mời tham vấn 1-1, phối hợp bí mật với GVCN để hỗ trợ.',
          })),
        actionPlan: [
          'Thực hiện can thiệp ưu tiên cho các học sinh có mức điểm đặc biệt lưu ý.',
          'Mở thêm khung giờ tư vấn tâm lý trực tuyến vào buổi tối trước tuần thi học kỳ.',
          'Mở khóa hồ sơ tâm lý cho GVCN các lớp cần theo dõi để cùng phối hợp chăm sóc.',
          'Đẩy mạnh hoạt động của AI Phòng tích cực Vovakier với các bài tập hít thở và thả lỏng.',
        ],
      };

      sharedState.latestAiAnalysis = fallbackAnalysis;
      return res.json({ success: true, analysis: fallbackAnalysis });
    }

    try {
      const prompt = `Bạn là Chuyên gia Tâm lý Học đường Cao cấp của Trường THPT VoVaKi.
Hãy phân tích bộ dữ liệu sức khỏe tâm lý học sinh toàn trường dưới đây để trích xuất báo cáo chuyên sâu:
${JSON.stringify(dataPayload)}

Yêu cầu phân tích:
1. Các hiện tượng tâm lý học sinh toàn trường có thể gặp (Cảnh báo xu hướng).
2. Các vấn đề tâm lý học sinh hay gặp (dựa trên dữ liệu cuộc trò chuyện và bài test).
3. Cảnh báo mức độ trầm cảm ở từng học sinh nguy cơ cao (danh sách học sinh cần can thiệp khẩn cấp).
4. Kế hoạch hành động cụ thể cho Nhà trường và Tổ Tư vấn Tâm lý.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING },
              potentialPhenomena: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    riskLevel: { type: Type.STRING },
                    description: { type: Type.STRING },
                    warningSigns: { type: Type.ARRAY, items: { type: Type.STRING } },
                    prevention: { type: Type.STRING },
                  },
                  required: ['title', 'riskLevel', 'description', 'warningSigns', 'prevention'],
                },
              },
              commonIssues: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    issue: { type: Type.STRING },
                    percentage: { type: Type.NUMBER },
                    evidenceFromChats: { type: Type.STRING },
                    affectedGroup: { type: Type.STRING },
                  },
                  required: ['issue', 'percentage', 'evidenceFromChats', 'affectedGroup'],
                },
              },
              depressionRiskStudents: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    studentCode: { type: Type.STRING },
                    classId: { type: Type.STRING },
                    riskLevel: { type: Type.STRING },
                    indicators: { type: Type.ARRAY, items: { type: Type.STRING } },
                    recommendedAction: { type: Type.STRING },
                  },
                  required: ['studentCode', 'classId', 'riskLevel', 'indicators', 'recommendedAction'],
                },
              },
              actionPlan: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ['summary', 'potentialPhenomena', 'commonIssues', 'depressionRiskStudents', 'actionPlan'],
          },
        },
      });

      const parsed = JSON.parse(response.text?.trim() || "{}");
      const completeAnalysis = {
        generatedAt: new Date().toLocaleString('vi-VN'),
        summary: (parsed.summary as string) || "Phân tích sức khỏe tâm lý hoàn tất.",
        potentialPhenomena: (parsed.potentialPhenomena || []).map((p: any) => ({
          title: p.title || 'Hiện tượng tâm lý học đường',
          riskLevel: (['Thấp', 'Trung bình', 'Cao'].includes(p.riskLevel) ? p.riskLevel : 'Trung bình') as 'Thấp' | 'Trung bình' | 'Cao',
          description: p.description || '',
          warningSigns: Array.isArray(p.warningSigns) ? p.warningSigns : [],
          prevention: p.prevention || '',
        })),
        commonIssues: (parsed.commonIssues || []).map((c: any) => ({
          issue: c.issue || 'Vấn đề học đường',
          percentage: Number(c.percentage) || 0,
          evidenceFromChats: c.evidenceFromChats || '',
          affectedGroup: c.affectedGroup || 'Toàn trường',
        })),
        depressionRiskStudents: (parsed.depressionRiskStudents || []).map((d: any) => ({
          studentCode: d.studentCode || 'N/A',
          classId: d.classId || 'N/A',
          riskLevel: (d.riskLevel === 'Cần đặc biệt lưu ý' ? 'Cần đặc biệt lưu ý' : 'Cần lưu ý') as 'Cần đặc biệt lưu ý' | 'Cần lưu ý',
          indicators: Array.isArray(d.indicators) ? d.indicators : [],
          recommendedAction: d.recommendedAction || 'Tham vấn 1-1 với GV Tư vấn.',
        })),
        actionPlan: Array.isArray(parsed.actionPlan) ? parsed.actionPlan : [],
      };

      sharedState.latestAiAnalysis = completeAnalysis;
      res.json({ success: true, analysis: completeAnalysis });
    } catch (error: any) {
      console.error("Gemini analyze-health error:", error);
      res.status(500).json({ error: error.message || "Failed to analyze health" });
    }
  });

  // --- AI-Powered Sentiment Analysis Module ---

  // Heuristic sentiment engine fallback for offline / unconfigured API keys
  function heuristicAnalyzeSentiment(
    transcriptText: string,
    studentIdentifier: string,
    targetType: string
  ): SentimentAnalysisResult {
    const textLower = transcriptText.toLowerCase();

    // High distress keywords
    const highDistressKeywords = [
      'hoảng loạn', 'không thở được', 'khó thở', 'tuyệt vọng', 'bế tắc', 'muốn biến mất',
      'tự hại', 'chết', 'không chịu nổi', 'hoảng sợ', 'ngất', 'tim đập nhanh', 'kinh khủng'
    ];
    // Moderate negative keywords
    const modNegativeKeywords = [
      'áp lực', 'sợ', 'lo lắng', 'mệt mỏi', 'chán nản', 'thất vọng', 'tự trách',
      'điểm kém', 'bị mắng', 'cô đơn', 'lạc lõng', 'mất ngủ', 'bỏ rơi', 'bất công',
      'khóc', 'căng thẳng', 'buồn', 'không ai hiểu', 'bất lực', 'tủi thân'
    ];
    // Positive keywords
    const positiveKeywords = [
      'cảm ơn', 'nhẹ nhõm', 'vui', 'tự tin', 'yên tâm', 'hy vọng', 'thoải mái',
      'ổn hơn', 'hết sợ', 'tiến bộ', 'cố gắng', 'thấu hiểu', 'bình tĩnh', 'lạc quan',
      'yêu đời', 'tin tưởng', 'biết ơn', 'thả lỏng', 'dễ chịu'
    ];

    const detectedDistress: string[] = [];
    const detectedKeyPhrases: string[] = [];

    let distressScore = 0;
    let positiveScore = 0;

    highDistressKeywords.forEach((kw) => {
      if (textLower.includes(kw)) {
        distressScore += 3;
        detectedDistress.push(`Dấu hiệu khẩn: "${kw}"`);
        detectedKeyPhrases.push(kw);
      }
    });

    modNegativeKeywords.forEach((kw) => {
      if (textLower.includes(kw)) {
        distressScore += 1;
        if (!detectedDistress.includes(`Dấu hiệu căng thẳng: "${kw}"`)) {
          detectedDistress.push(`Dấu hiệu căng thẳng: "${kw}"`);
        }
        detectedKeyPhrases.push(kw);
      }
    });

    positiveKeywords.forEach((kw) => {
      if (textLower.includes(kw)) {
        positiveScore += 1.5;
        detectedKeyPhrases.push(kw);
      }
    });

    let sentiment: 'positive' | 'negative' | 'neutral' = 'neutral';
    let sentimentLabel: 'Tích cực' | 'Tiêu cực' | 'Trung tính' = 'Trung tính';
    let score = 0; // -1.0 to 1.0
    let emotionalState = 'Trung tính & Thăm dò';
    let urgencyLevel: 'Bình thường' | 'Cần chú ý' | 'Báo động khẩn cấp' = 'Bình thường';
    let positivePct = 30;
    let negativePct = 30;
    let neutralPct = 40;

    if (distressScore >= 5 || targetType === 'emergency_session') {
      sentiment = 'negative';
      sentimentLabel = 'Tiêu cực';
      score = -0.75 - Math.min(0.24, distressScore * 0.03);
      urgencyLevel = 'Báo động khẩn cấp';
      emotionalState = 'Lo âu & Hoảng loạn';
      negativePct = 85;
      positivePct = 5;
      neutralPct = 10;
    } else if (distressScore > positiveScore && distressScore >= 2) {
      sentiment = 'negative';
      sentimentLabel = 'Tiêu cực';
      score = -0.35 - Math.min(0.35, distressScore * 0.05);
      urgencyLevel = 'Cần chú ý';
      emotionalState = textLower.includes('điểm') || textLower.includes('áp lực') ? 'Căng thẳng & Áp lực' : 'Buồn bã & Bế tắc';
      negativePct = 65;
      positivePct = 15;
      neutralPct = 20;
    } else if (positiveScore > distressScore && positiveScore >= 2) {
      sentiment = 'positive';
      sentimentLabel = 'Tích cực';
      score = 0.45 + Math.min(0.5, positiveScore * 0.08);
      urgencyLevel = 'Bình thường';
      emotionalState = textLower.includes('nhẹ nhõm') || textLower.includes('thở') ? 'Bình yên & Cân bằng' : 'Hy vọng & Tiếp thu';
      positivePct = 75;
      negativePct = 10;
      neutralPct = 15;
    } else {
      sentiment = 'neutral';
      sentimentLabel = 'Trung tính';
      score = 0.05;
      urgencyLevel = 'Bình thường';
      emotionalState = 'Trung tính & Thăm dò';
      positivePct = 35;
      negativePct = 25;
      neutralPct = 40;
    }

    const normalizedScore = Math.max(0, Math.min(100, Math.round((score + 1) * 50)));

    let summary = `Học sinh ${studentIdentifier} bộc lộ trạng thái [${emotionalState}], mức độ cảm xúc ghi nhận là ${sentimentLabel.toLowerCase()} (điểm số ${score.toFixed(2)}/1.0).`;
    if (urgencyLevel === 'Báo động khẩn cấp') {
      summary += ' Phát hiện các biểu hiện căng thẳng cấp tính hoặc rối loạn lo âu cần hỗ trợ trực tiếp khẩn trương.';
    } else if (urgencyLevel === 'Cần chú ý') {
      summary += ' Học sinh chịu áp lực học tập hoặc tâm lý kéo dài, khuyến nghị duy trì theo dõi và đồng hành.';
    } else {
      summary += ' Tâm lý học sinh ở mức ổn định, có khả năng tiếp nhận định hướng và cân bằng cảm xúc tốt.';
    }

    const clinicalRecommendations: string[] = [];
    if (urgencyLevel === 'Báo động khẩn cấp') {
      clinicalRecommendations.push('Kích hoạt quy trình tham vấn khủng hoảng, kết nối ngay lập tức với chuyên viên tâm lý.');
      clinicalRecommendations.push('Hướng dẫn điều hòa hơi thở đối giao cảm (Kỹ thuật thở 4-7-8 hoặc đếm nhịp chạm đất 5-4-3-2-1).');
      clinicalRecommendations.push('Thông báo bảo mật cho GVCN để tránh gây áp lực thêm trong buổi học kế tiếp.');
    } else if (urgencyLevel === 'Cần chú ý') {
      clinicalRecommendations.push('Xếp lịch tư vấn định kỳ 1-1 để đào sâu nguồn gốc áp lực học đường.');
      clinicalRecommendations.push('Hướng dẫn kỹ năng quản lý thời gian và tái cấu trúc nhận thức tích cực.');
      clinicalRecommendations.push('Tạo cơ hội giải tỏa thông qua các bài tập thư giãn tại Phòng tích cực Vovakier.');
    } else {
      clinicalRecommendations.push('Khích lệ học sinh duy trì thói quen tự chăm sóc bản thân và ngủ đủ giấc.');
      clinicalRecommendations.push('Tuyên dương tinh thần chủ động sẻ chia và kết nối tích cực với bạn bè.');
    }

    return {
      id: `sent-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      targetId: '',
      targetType: targetType as any,
      studentIdentifier,
      sentiment,
      sentimentLabel,
      score: Number(score.toFixed(2)),
      normalizedScore,
      confidence: 0.93,
      emotionalState,
      emotionsBreakdown: {
        positive: positivePct,
        negative: negativePct,
        neutral: neutralPct,
      },
      urgencyLevel,
      keyPhrases: detectedKeyPhrases.slice(0, 5),
      distressSignals: detectedDistress.slice(0, 4),
      summary,
      clinicalRecommendations,
      analyzedAt: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
    };
  }

  // API: Analyze sentiment for a chat session or custom text
  app.post("/api/gemini/analyze-sentiment", async (req, res) => {
    try {
      const { targetId, targetType, messages, customText, studentIdentifier } = req.body;

      // Extract text from chat log or custom input
      let transcriptText = "";
      if (Array.isArray(messages) && messages.length > 0) {
        transcriptText = messages
          .map((m: any) => `[${m.senderName || m.sender}]: ${m.text}`)
          .join("\n");
      } else if (customText) {
        transcriptText = customText;
      } else if (targetId) {
        // Look up from shared state
        if (targetType === 'counselor_booking') {
          const booking = sharedState.bookings.find((b) => b.id === targetId);
          if (booking && booking.messages) {
            transcriptText = booking.messages.map((m) => `[${m.senderName}]: ${m.text}`).join("\n");
          }
        } else if (targetType === 'emergency_session') {
          const session = sharedState.emergencySessions.find((s) => s.id === targetId);
          if (session && session.messages) {
            transcriptText = session.messages.map((m) => `[${m.senderName}]: ${m.text}`).join("\n");
          }
        } else if (targetType === 'positive_room') {
          const session = sharedState.positiveRoomSessions.find((s) => s.id === targetId);
          if (session && session.messages) {
            transcriptText = session.messages.map((m) => `[${m.senderName}]: ${m.text}`).join("\n");
          }
        }
      }

      const identifier = studentIdentifier || 'Học sinh ẩn danh';
      const ai = getGeminiClient();

      let result: SentimentAnalysisResult;

      if (!ai || !transcriptText.trim()) {
        result = heuristicAnalyzeSentiment(transcriptText || "Em cảm thấy mệt mỏi và áp lực bài tập", identifier, targetType || 'counselor_booking');
      } else {
        try {
          const prompt = `Bạn là Chuyên gia Tâm lý Học đường và Giám sát Cảm xúc AI của Hệ thống Tư vấn Tâm lý VoVaKi.
Hãy phân tích nội dung cuộc trò chuyện tư vấn tâm lý của học sinh dưới đây để xác định chính xác trạng thái cảm xúc, mức độ căng thẳng/trầm cảm và đưa ra đề xuất can thiệp cho chuyên viên tâm lý.

Đối tượng học sinh: ${identifier}
Loại hình phiên: ${targetType}
Nội dung nhật ký cuộc trò chuyện:
${transcriptText}

Hãy phân tích kỹ lưỡng và trả về cấu trúc JSON đúng định dạng:
- sentiment: "positive" | "negative" | "neutral"
- sentimentLabel: "Tích cực" | "Tiêu cực" | "Trung tính"
- score: số thực từ -1.0 (cực kỳ tiêu cực/khủng hoảng) đến +1.0 (cực kỳ tích cực/hân hoan), 0.0 là trung tính
- normalizedScore: số nguyên từ 0 (khủng hoảng nhất) đến 100 (tích cực nhất)
- confidence: số thực từ 0.0 đến 1.0 (độ tin cậy của mô hình)
- emotionalState: một trong các trạng thái cảm xúc chi tiết: "Tích cực & Lạc quan", "Bình yên & Cân bằng", "Căng thẳng & Áp lực", "Lo âu & Hoảng loạn", "Buồn bã & Bế tắc", "Cô đơn & Tách biệt", "Tức giận & Bất an", "Trung tính & Thăm dò", "Hy vọng & Tiếp thu" (hoặc miêu tả sắc thái cảm xúc chi tiết tương đương)
- emotionsBreakdown: { positive: % (0-100), negative: % (0-100), neutral: % (0-100) } (tổng = 100)
- urgencyLevel: "Bình thường" | "Cần chú ý" | "Báo động khẩn cấp"
- keyPhrases: mảng các câu trích dẫn hoặc từ ngữ bộc lộ cảm xúc then chốt của học sinh (tối đa 5 câu)
- distressSignals: mảng các dấu hiệu nguy cơ / tín hiệu tâm lý đáng lưu tâm (ví dụ: áp lực thi cử, mất ngủ, sợ bị đánh giá, suy nghĩ bế tắc...)
- summary: tóm tắt diễn biến cảm xúc và tâm lý cốt lõi của học sinh (2-4 câu chuyên môn tâm lý)
- clinicalRecommendations: mảng 2-4 khuyến nghị chuyên môn cụ thể dành cho Giáo viên Tư vấn tâm lý hoặc GVCN để hỗ trợ học sinh`;

          const geminiRes = await ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: prompt,
            config: {
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  sentiment: { type: Type.STRING },
                  sentimentLabel: { type: Type.STRING },
                  score: { type: Type.NUMBER },
                  normalizedScore: { type: Type.INTEGER },
                  confidence: { type: Type.NUMBER },
                  emotionalState: { type: Type.STRING },
                  emotionsBreakdown: {
                    type: Type.OBJECT,
                    properties: {
                      positive: { type: Type.NUMBER },
                      negative: { type: Type.NUMBER },
                      neutral: { type: Type.NUMBER },
                    },
                    required: ['positive', 'negative', 'neutral'],
                  },
                  urgencyLevel: { type: Type.STRING },
                  keyPhrases: { type: Type.ARRAY, items: { type: Type.STRING } },
                  distressSignals: { type: Type.ARRAY, items: { type: Type.STRING } },
                  summary: { type: Type.STRING },
                  clinicalRecommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: [
                  'sentiment',
                  'sentimentLabel',
                  'score',
                  'normalizedScore',
                  'confidence',
                  'emotionalState',
                  'emotionsBreakdown',
                  'urgencyLevel',
                  'keyPhrases',
                  'distressSignals',
                  'summary',
                  'clinicalRecommendations',
                ],
              },
            },
          });

          const parsed = JSON.parse(geminiRes.text?.trim() || "{}");
          result = {
            id: `sent-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            targetId: targetId || '',
            targetType: targetType || 'counselor_booking',
            studentIdentifier: identifier,
            sentiment: (parsed.sentiment === 'positive' || parsed.sentiment === 'negative' ? parsed.sentiment : 'neutral') as any,
            sentimentLabel: (parsed.sentimentLabel === 'Tích cực' || parsed.sentimentLabel === 'Tiêu cực' ? parsed.sentimentLabel : 'Trung tính') as any,
            score: Number(parsed.score) || 0,
            normalizedScore: Math.max(0, Math.min(100, Math.round(Number(parsed.normalizedScore) || 50))),
            confidence: Number(parsed.confidence) || 0.92,
            emotionalState: parsed.emotionalState || 'Trung tính & Thăm dò',
            emotionsBreakdown: {
              positive: Math.round(Number(parsed.emotionsBreakdown?.positive) || 30),
              negative: Math.round(Number(parsed.emotionsBreakdown?.negative) || 30),
              neutral: Math.round(Number(parsed.emotionsBreakdown?.neutral) || 40),
            },
            urgencyLevel: (['Bình thường', 'Cần chú ý', 'Báo động khẩn cấp'].includes(parsed.urgencyLevel) ? parsed.urgencyLevel : 'Bình thường') as any,
            keyPhrases: Array.isArray(parsed.keyPhrases) ? parsed.keyPhrases : [],
            distressSignals: Array.isArray(parsed.distressSignals) ? parsed.distressSignals : [],
            summary: parsed.summary || 'Phân tích hoàn tất.',
            clinicalRecommendations: Array.isArray(parsed.clinicalRecommendations) ? parsed.clinicalRecommendations : [],
            analyzedAt: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
          };
        } catch (apiErr) {
          console.error("Gemini sentiment error, falling back:", apiErr);
          result = heuristicAnalyzeSentiment(transcriptText, identifier, targetType || 'counselor_booking');
        }
      }

      result.targetId = targetId || result.id;

      // Associate with target session in sharedState
      if (targetType === 'counselor_booking' && targetId) {
        const booking = sharedState.bookings.find((b) => b.id === targetId);
        if (booking) {
          booking.sentimentAnalysis = result;
        }
      } else if (targetType === 'emergency_session' && targetId) {
        const session = sharedState.emergencySessions.find((s) => s.id === targetId);
        if (session) {
          session.sentimentAnalysis = result;
        }
      } else if (targetType === 'positive_room' && targetId) {
        const session = sharedState.positiveRoomSessions.find((s) => s.id === targetId);
        if (session) {
          session.sentimentAnalysis = result;
        }
      }

      // Add to sentimentAnalyses list
      sharedState.sentimentAnalyses = sharedState.sentimentAnalyses || [];
      const existingSentIdx = sharedState.sentimentAnalyses.findIndex((s) => s.targetId === targetId && targetId);
      if (existingSentIdx >= 0) {
        sharedState.sentimentAnalyses[existingSentIdx] = result;
      } else {
        sharedState.sentimentAnalyses.unshift(result);
      }

      res.json({ success: true, sentimentAnalysis: result, state: sharedState });
    } catch (error: any) {
      console.error("Sentiment analysis endpoint error:", error);
      res.status(500).json({ error: error.message || "Failed to analyze sentiment" });
    }
  });

  // API: Batch analyze all unanalyzed chat sessions
  app.post("/api/gemini/batch-analyze-sentiments", async (_req, res) => {
    try {
      const results: SentimentAnalysisResult[] = [];

      // 1. Check bookings
      for (const booking of sharedState.bookings) {
        if (!booking.sentimentAnalysis && booking.messages && booking.messages.length > 0) {
          const transcript = booking.messages.map((m) => `[${m.senderName}]: ${m.text}`).join("\n");
          const sent = heuristicAnalyzeSentiment(transcript, `${booking.studentAnonymousCode} (${booking.nickname})`, 'counselor_booking');
          sent.targetId = booking.id;
          booking.sentimentAnalysis = sent;
          results.push(sent);
          sharedState.sentimentAnalyses.unshift(sent);
        }
      }

      // 2. Check emergency sessions
      for (const emg of sharedState.emergencySessions) {
        if (!emg.sentimentAnalysis && emg.messages && emg.messages.length > 0) {
          const transcript = emg.messages.map((m) => `[${m.senderName}]: ${m.text}`).join("\n");
          const sent = heuristicAnalyzeSentiment(transcript, `${emg.studentAnonymousCode} (${emg.studentNickname})`, 'emergency_session');
          sent.targetId = emg.id;
          emg.sentimentAnalysis = sent;
          results.push(sent);
          sharedState.sentimentAnalyses.unshift(sent);
        }
      }

      // 3. Check positive room sessions
      for (const pos of sharedState.positiveRoomSessions) {
        if (!pos.sentimentAnalysis && pos.messages && pos.messages.length > 0) {
          const transcript = pos.messages.map((m) => `[${m.senderName}]: ${m.text}`).join("\n");
          const sent = heuristicAnalyzeSentiment(transcript, `${pos.studentAnonymousCode} (${pos.studentNickname})`, 'positive_room');
          sent.targetId = pos.id;
          pos.sentimentAnalysis = sent;
          results.push(sent);
          sharedState.sentimentAnalyses.unshift(sent);
        }
      }

      res.json({ success: true, processedCount: results.length, results, state: sharedState });
    } catch (error: any) {
      res.status(500).json({ error: error.message || "Failed to run batch sentiment analysis" });
    }
  });

  // --- Secure Admin Data Export with RBAC and Date Range Filtering ---

  function escapeCsvValue(val: any): string {
    if (val === null || val === undefined) return '""';
    let str = typeof val === 'object' ? JSON.stringify(val) : String(val);
    return `"${str.replace(/"/g, '""')}"`;
  }

  function isWithinDateRange(dateStr?: string, dateFrom?: string, dateTo?: string): boolean {
    if (!dateStr) return true;
    if (!dateFrom && !dateTo) return true;
    const datePart = dateStr.slice(0, 10);
    if (dateFrom && datePart < dateFrom) return false;
    if (dateTo && datePart > dateTo) return false;
    return true;
  }

  function getSubsetName(subset: string): string {
    const names: Record<string, string> = {
      all: 'Toàn bộ cơ sở dữ liệu hệ thống',
      student_health_records: 'Hồ sơ sức khỏe tâm lý học sinh',
      counseling_bookings: 'Lịch hẹn & Nhật ký tư vấn ảo 1-1',
      emergency_sessions: 'Phiên tư vấn khẩn cấp',
      positive_room_sessions: 'Nhật ký Phòng tích cực Vovakier',
      test_submissions: 'Kết quả khảo sát / bài test tâm lý',
      sentiment_analyses: 'Báo cáo phân tích cảm xúc AI',
      user_accounts: 'Danh sách người dùng & Phân quyền vai trò',
    };
    return names[subset] || subset;
  }

  // Secure export handler
  app.post("/api/admin/export", (req, res) => {
    try {
      const userRole = req.headers['x-user-role'] || req.body.userRole;
      const adminId = (req.headers['x-user-id'] || req.body.adminId || 'usr-admin-1') as string;
      const adminName = (req.body.adminName || 'Quản trị viên Hệ thống VoVaKi') as string;

      // STRICT RBAC CHECK: Only admin allowed
      if (userRole !== 'admin') {
        return res.status(403).json({
          error: 'Quyền truy cập bị từ chối (403 Forbidden): Tính năng trích xuất cơ sở dữ liệu chứa thông tin cá nhân và hồ sơ bảo mật, chỉ Quản trị viên mới được phép thực hiện.',
        });
      }

      const { format = 'json', subset = 'all', dateFrom, dateTo } = req.body;
      const BOM = '\uFEFF'; // UTF-8 Byte Order Mark for Excel
      const timestampStr = new Date().toISOString().split('T')[0];

      let exportedData: any = {};
      let csvOutput = '';
      let recordCount = 0;

      // Filter data subsets by date range
      const filteredRecords = sharedState.studentRecords.filter((r) => isWithinDateRange(r.lastUpdatedMonth, dateFrom, dateTo));
      const filteredBookings = sharedState.bookings.filter((b) => isWithinDateRange(b.createdAt || b.date, dateFrom, dateTo));
      const filteredEmergency = sharedState.emergencySessions.filter((s) => isWithinDateRange(s.startedAt, dateFrom, dateTo));
      const filteredPositiveRoom = sharedState.positiveRoomSessions.filter((s) => isWithinDateRange(s.startedAt, dateFrom, dateTo));
      const filteredTests = sharedState.testSubmissions.filter((t) => isWithinDateRange(t.submittedAt || t.month, dateFrom, dateTo));
      const filteredSentiments = (sharedState.sentimentAnalyses || []).filter((s) => isWithinDateRange(s.analyzedAt, dateFrom, dateTo));
      const filteredUsers = sharedState.users.filter((u) => isWithinDateRange(u.createdAt, dateFrom, dateTo));

      if (subset === 'student_health_records') {
        recordCount = filteredRecords.length;
        exportedData = filteredRecords;

        // Generate CSV
        const headers = [
          'Mã HS', 'Họ và Tên', 'Lớp', 'Khối', 'Điểm khảo sát gần nhất',
          'Đánh giá trạng thái', 'Cần đặc biệt lưu ý', 'Tháng cập nhật',
          'Ghi chú GV Tư vấn', 'Ghi chú GVCN'
        ];
        csvOutput = BOM + headers.map(escapeCsvValue).join(',') + '\n';
        filteredRecords.forEach((r) => {
          csvOutput += [
            escapeCsvValue(r.studentCode),
            escapeCsvValue(r.studentName),
            escapeCsvValue(r.classId),
            escapeCsvValue(r.grade),
            escapeCsvValue(r.latestScore),
            escapeCsvValue(r.status),
            escapeCsvValue(r.specialAttentionFlag ? 'CÓ' : 'KHÔNG'),
            escapeCsvValue(r.lastUpdatedMonth),
            escapeCsvValue(r.counselorNotes),
            escapeCsvValue(r.homeroomNotes),
          ].join(',') + '\n';
        });
      } else if (subset === 'counseling_bookings') {
        recordCount = filteredBookings.length;
        exportedData = filteredBookings;

        const headers = [
          'Mã cuộc hẹn', 'Ngày hẹn', 'Khung giờ', 'Mã ẩn danh HS', 'Biệt danh HS',
          'Chủ đề tư vấn', 'Loại hình', 'Trạng thái', 'Số tin nhắn',
          'Cảm xúc AI', 'Điểm cảm xúc', 'Sắc thái cảm xúc', 'Mức độ khẩn cấp', 'Ngày tạo'
        ];
        csvOutput = BOM + headers.map(escapeCsvValue).join(',') + '\n';
        filteredBookings.forEach((b) => {
          csvOutput += [
            escapeCsvValue(b.id),
            escapeCsvValue(b.date),
            escapeCsvValue(b.timeSlot),
            escapeCsvValue(b.studentAnonymousCode),
            escapeCsvValue(b.nickname),
            escapeCsvValue(b.topic),
            escapeCsvValue(b.type === 'counselor' ? 'Tư vấn Chuyên viên 1-1' : 'Phòng tích cực AI'),
            escapeCsvValue(b.status),
            escapeCsvValue(b.messages?.length || 0),
            escapeCsvValue(b.sentimentAnalysis?.sentimentLabel || 'Chưa phân tích'),
            escapeCsvValue(b.sentimentAnalysis?.score ?? 'N/A'),
            escapeCsvValue(b.sentimentAnalysis?.emotionalState || 'N/A'),
            escapeCsvValue(b.sentimentAnalysis?.urgencyLevel || 'N/A'),
            escapeCsvValue(b.createdAt),
          ].join(',') + '\n';
        });
      } else if (subset === 'emergency_sessions') {
        recordCount = filteredEmergency.length;
        exportedData = filteredEmergency;

        const headers = [
          'Mã phiên khẩn cấp', 'Thời gian bắt đầu', 'Mã ẩn danh HS', 'Biệt danh HS',
          'Trạng thái', 'Ghi chú GV Tư vấn', 'Số tin nhắn', 'Cảm xúc AI',
          'Điểm cảm xúc', 'Mức độ khẩn cấp', 'Dấu hiệu nguy cơ'
        ];
        csvOutput = BOM + headers.map(escapeCsvValue).join(',') + '\n';
        filteredEmergency.forEach((s) => {
          csvOutput += [
            escapeCsvValue(s.id),
            escapeCsvValue(s.startedAt),
            escapeCsvValue(s.studentAnonymousCode),
            escapeCsvValue(s.studentNickname),
            escapeCsvValue(s.status),
            escapeCsvValue(s.counselorNotes || ''),
            escapeCsvValue(s.messages?.length || 0),
            escapeCsvValue(s.sentimentAnalysis?.sentimentLabel || 'N/A'),
            escapeCsvValue(s.sentimentAnalysis?.score ?? 'N/A'),
            escapeCsvValue(s.sentimentAnalysis?.urgencyLevel || 'N/A'),
            escapeCsvValue((s.sentimentAnalysis?.distressSignals || []).join('; ')),
          ].join(',') + '\n';
        });
      } else if (subset === 'positive_room_sessions') {
        recordCount = filteredPositiveRoom.length;
        exportedData = filteredPositiveRoom;

        const headers = [
          'Mã phiên', 'Thời gian bắt đầu', 'Mã ẩn danh HS', 'Biệt danh HS',
          'Trạng thái', 'Chỉ đạo từ xa của GV', 'Ghi chú trực tiếp của GV',
          'Số tin nhắn', 'Cảm xúc AI', 'Điểm cảm xúc', 'Trạng thái cảm xúc'
        ];
        csvOutput = BOM + headers.map(escapeCsvValue).join(',') + '\n';
        filteredPositiveRoom.forEach((p) => {
          csvOutput += [
            escapeCsvValue(p.id),
            escapeCsvValue(p.startedAt),
            escapeCsvValue(p.studentAnonymousCode),
            escapeCsvValue(p.studentNickname),
            escapeCsvValue(p.status),
            escapeCsvValue(p.counselorGuidancePrompt || ''),
            escapeCsvValue(p.counselorLiveNotes || ''),
            escapeCsvValue(p.messages?.length || 0),
            escapeCsvValue(p.sentimentAnalysis?.sentimentLabel || 'N/A'),
            escapeCsvValue(p.sentimentAnalysis?.score ?? 'N/A'),
            escapeCsvValue(p.sentimentAnalysis?.emotionalState || 'N/A'),
          ].join(',') + '\n';
        });
      } else if (subset === 'test_submissions') {
        recordCount = filteredTests.length;
        exportedData = filteredTests;

        const headers = [
          'Mã nộp bài', 'Tên bài test', 'Mã HS', 'Họ và Tên', 'Lớp', 'Khối',
          'Tháng khảo sát', 'Tổng điểm', 'Đánh giá xếp loại', 'Lời khuyên chuyên môn', 'Thời gian nộp'
        ];
        csvOutput = BOM + headers.map(escapeCsvValue).join(',') + '\n';
        filteredTests.forEach((t) => {
          csvOutput += [
            escapeCsvValue(t.id),
            escapeCsvValue(t.testTitle || 'Khảo sát tâm lý định kỳ'),
            escapeCsvValue(t.studentCode),
            escapeCsvValue(t.studentName),
            escapeCsvValue(t.classId),
            escapeCsvValue(t.grade),
            escapeCsvValue(t.month),
            escapeCsvValue(t.totalScore),
            escapeCsvValue(t.evaluation),
            escapeCsvValue(t.advice || ''),
            escapeCsvValue(t.submittedAt),
          ].join(',') + '\n';
        });
      } else if (subset === 'sentiment_analyses') {
        recordCount = filteredSentiments.length;
        exportedData = filteredSentiments;

        const headers = [
          'Mã phân tích', 'Mã đối tượng', 'Loại hình phiên', 'Định danh học sinh',
          'Nhãn cảm xúc', 'Điểm số (-1 đến +1)', 'Điểm chuẩn hóa (0-100)',
          'Độ tin cậy', 'Trạng thái cảm xúc chi tiết', '% Tích cực', '% Tiêu cực', '% Trung tính',
          'Mức độ khẩn cấp', 'Từ khóa then chốt', 'Dấu hiệu nguy cơ', 'Tóm tắt tâm lý',
          'Khuyến nghị chuyên môn', 'Thời gian phân tích'
        ];
        csvOutput = BOM + headers.map(escapeCsvValue).join(',') + '\n';
        filteredSentiments.forEach((s) => {
          csvOutput += [
            escapeCsvValue(s.id),
            escapeCsvValue(s.targetId),
            escapeCsvValue(s.targetType),
            escapeCsvValue(s.studentIdentifier),
            escapeCsvValue(s.sentimentLabel),
            escapeCsvValue(s.score),
            escapeCsvValue(s.normalizedScore),
            escapeCsvValue(s.confidence),
            escapeCsvValue(s.emotionalState),
            escapeCsvValue(s.emotionsBreakdown.positive),
            escapeCsvValue(s.emotionsBreakdown.negative),
            escapeCsvValue(s.emotionsBreakdown.neutral),
            escapeCsvValue(s.urgencyLevel),
            escapeCsvValue((s.keyPhrases || []).join('; ')),
            escapeCsvValue((s.distressSignals || []).join('; ')),
            escapeCsvValue(s.summary),
            escapeCsvValue((s.clinicalRecommendations || []).join('; ')),
            escapeCsvValue(s.analyzedAt),
          ].join(',') + '\n';
        });
      } else if (subset === 'user_accounts') {
        recordCount = filteredUsers.length;
        exportedData = filteredUsers;

        const headers = ['Mã người dùng', 'Tên đăng nhập', 'Họ và Tên', 'Vai trò', 'Lớp', 'Mã HS', 'Email', 'Số điện thoại', 'Ngày tạo'];
        csvOutput = BOM + headers.map(escapeCsvValue).join(',') + '\n';
        filteredUsers.forEach((u) => {
          csvOutput += [
            escapeCsvValue(u.id),
            escapeCsvValue(u.username),
            escapeCsvValue(u.fullName),
            escapeCsvValue(u.role),
            escapeCsvValue(u.classId || ''),
            escapeCsvValue(u.studentCode || ''),
            escapeCsvValue(u.email || ''),
            escapeCsvValue(u.phone || ''),
            escapeCsvValue(u.createdAt),
          ].join(',') + '\n';
        });
      } else {
        // 'all': Entire Database
        recordCount =
          filteredRecords.length +
          filteredBookings.length +
          filteredEmergency.length +
          filteredPositiveRoom.length +
          filteredTests.length +
          filteredSentiments.length +
          filteredUsers.length;

        exportedData = {
          metadata: {
            systemName: sharedState.siteSettings.siteName,
            exportedAt: new Date().toISOString(),
            exportedBy: adminName,
            adminId,
            filterDateRange: { from: dateFrom || 'Toàn bộ', to: dateTo || 'Hiện tại' },
            totalRecords: recordCount,
          },
          database: {
            users: filteredUsers,
            classes: sharedState.classes,
            classAccess: sharedState.classAccess,
            siteSettings: sharedState.siteSettings,
            articles: sharedState.articles,
            studentRecords: filteredRecords,
            bookings: filteredBookings,
            emergencySessions: filteredEmergency,
            positiveRoomSessions: filteredPositiveRoom,
            psychologicalTests: sharedState.psychologicalTests,
            testSubmissions: filteredTests,
            sentimentAnalyses: filteredSentiments,
            latestAiAnalysis: sharedState.latestAiAnalysis,
          },
        };

        // For CSV when exporting all, we generate a consolidated summary sheet
        const headers = ['Bảng dữ liệu', 'Mô tả nội dung', 'Số bản ghi thỏa mãn bộ lọc'];
        csvOutput = BOM + headers.map(escapeCsvValue).join(',') + '\n';
        csvOutput += [escapeCsvValue('Hồ sơ sức khỏe tâm lý'), escapeCsvValue('Điểm khảo sát & đánh giá học sinh'), escapeCsvValue(filteredRecords.length)].join(',') + '\n';
        csvOutput += [escapeCsvValue('Lịch hẹn tư vấn 1-1'), escapeCsvValue('Lịch và nhật ký tư vấn chuyên viên'), escapeCsvValue(filteredBookings.length)].join(',') + '\n';
        csvOutput += [escapeCsvValue('Phiên tư vấn khẩn cấp'), escapeCsvValue('Nhật ký can thiệp hoảng loạn'), escapeCsvValue(filteredEmergency.length)].join(',') + '\n';
        csvOutput += [escapeCsvValue('Phòng tích cực Vovakier'), escapeCsvValue('Nhật ký đối thoại AI & giám sát từ xa'), escapeCsvValue(filteredPositiveRoom.length)].join(',') + '\n';
        csvOutput += [escapeCsvValue('Kết quả bài test tâm lý'), escapeCsvValue('Dữ liệu làm bài khảo sát định kỳ'), escapeCsvValue(filteredTests.length)].join(',') + '\n';
        csvOutput += [escapeCsvValue('Báo cáo phân tích cảm xúc AI'), escapeCsvValue('Điểm số và phân loại sắc thái cảm xúc'), escapeCsvValue(filteredSentiments.length)].join(',') + '\n';
        csvOutput += [escapeCsvValue('Tài khoản người dùng'), escapeCsvValue('Danh sách nhân sự và học sinh'), escapeCsvValue(filteredUsers.length)].join(',') + '\n';
      }

      // Record Audit Log
      const auditLog: ExportAuditLog = {
        id: `audit-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        adminId,
        adminName,
        exportFormat: format === 'csv' ? 'csv' : 'json',
        dataSubset: subset,
        subsetName: getSubsetName(subset),
        recordCount,
        dateRange: { from: dateFrom, to: dateTo },
        timestamp: new Date().toLocaleDateString('vi-VN') + ' ' + new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
        ipAddress: req.ip || req.socket.remoteAddress || '127.0.0.1',
        status: 'success',
      };

      sharedState.exportAuditLogs = sharedState.exportAuditLogs || [];
      sharedState.exportAuditLogs.unshift(auditLog);

      const filename = `vovaki_${subset}_export_${timestampStr}.${format}`;
      const dataString = format === 'csv' ? csvOutput : JSON.stringify(exportedData, null, 2);
      const mimeType = format === 'csv' ? 'text/csv;charset=utf-8;' : 'application/json;charset=utf-8;';

      res.json({
        success: true,
        filename,
        mimeType,
        format,
        subset,
        subsetName: getSubsetName(subset),
        recordCount,
        dataString,
        auditLog,
        state: sharedState,
      });
    } catch (error: any) {
      console.error("Secure export error:", error);
      res.status(500).json({ error: error.message || "Failed to export data securely" });
    }
  });

  // API: Get export audit logs
  app.get("/api/admin/export/audit-logs", (req, res) => {
    const userRole = req.headers['x-user-role'] || req.query.userRole;
    if (userRole !== 'admin') {
      return res.status(403).json({ error: 'Quyền truy cập bị từ chối' });
    }
    res.json({ success: true, auditLogs: sharedState.exportAuditLogs || [] });
  });

  // Vite middleware for dev / static for prod
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
